/**
 * <p>项目名称：oms_0.1.1<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2015-1-8</li>
 * <li>3、开发时间：上午10:28:53</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.oms.fastdfs</li>
 * <li>6、文件名称：UpdateBookFileTest.java</li>
 * </ul>
 */
package com.chinabank.oms.fastdfs;

import java.util.HashMap;
import java.util.Map;

import com.chinabank.operationmanagesystem.book.bean.BookFileDTO;
import com.chinabank.operationmanagesystem.book.bean.Request;
import com.chinabank.operationmanagesystem.book.bean.Response;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.wangyin.operation.enums.FileStatusEnum;
import com.wangyin.operation.utils.GsonUtil;
import com.wangyin.operation.utils.HttpUtils;
import com.wangyin.operation.utils.MD5Util;

/**
 * <ul>
 * <li>1、开发日期：2015-1-8</li>
 * <li>2、开发时间：上午10:28:53</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：UpdateBookFileTest</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */

public class UpdateBookFileTest {
	
	/**  
	 * Title: UpdateBookFileTest.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @throws Exception 
	 * @history:
	 */
	public static void main(String[] args) throws Exception {
		
		BookFileDTO bookFileDTO = new BookFileDTO();
		bookFileDTO.setAppCode("abc");
		bookFileDTO.setOwner("def");
		bookFileDTO.setFileDir("/dddd/");
		bookFileDTO.setFileName("abc.txt");
		//更新预约文件状态为处理中
		bookFileDTO.setStatus(FileStatusEnum.DONE);
		Gson gson = GsonUtil.getInstanceWithDateFormat();
		String param = gson.toJson(bookFileDTO);
		Request request = new Request(); 
		request.setAppCode("10000");
		request.setParam(param);
		request.setSign(MD5Util.MD5(request.getAppCode() + request.getParam() + "123456789abcdefgh"));
		Map<String, Object> params = new HashMap<String, Object>();
		params.put("req", gson.toJson(request));
		String result = HttpUtils.doPost("http://127.0.0.1:9099/billfile/updateFile.do", params);
		Response<BookFileDTO> response = gson.fromJson(result, new TypeToken<Response<BookFileDTO>>(){}.getType());
		if(response.isSuccessful()) {
			System.out.println("更新成功");
		} else {
			System.out.println("更新预约文件失败："+response.getMessage());
		}
	}
}
