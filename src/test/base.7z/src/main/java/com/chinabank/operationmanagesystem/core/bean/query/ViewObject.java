/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-1-8</li>
 * <li>3、开发时间：下午3:01:25</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.bean.query</li>
 * <li>6、文件名称：SelectObject.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.bean.query;

import java.io.Serializable;

/**
 * <ul>
 * <li>1、开发日期：2014-1-8</li>
 * <li>2、开发时间：下午3:01:25</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：SelectObject</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class ViewObject implements Serializable{

	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：SelectObject.java</li>
	 * </ul>
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 页面结构
	 */
	private String html ="";
	/**
	 * ready之外的js函数
	 */
	private String function="";
	/**
	 * jquery中，ready中的js函数
	 */
	private String ready="";
	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2014-1-8</li>
	 * <li>2、开发时间：下午3:01:25</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 */
	public ViewObject() {
		// TODO Auto-generated constructor stub
	}
	
	public ViewObject(String html, String function, String ready) {
		super();
		this.html = html;
		this.function = function;
		this.ready = ready;
	}

	/**  
	 * Title: SelectObject.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	public String getHtml() {
		return html;
	}
	public void setHtml(String html) {
		this.html = html;
	}
	public String getFunction() {
		return function;
	}
	public void setFunction(String function) {
		this.function = function;
	}

	public String getReady() {
		return ready;
	}

	public void setReady(String ready) {
		this.ready = ready;
	}
	
}
