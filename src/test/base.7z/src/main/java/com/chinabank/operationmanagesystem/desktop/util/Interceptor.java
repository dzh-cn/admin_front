/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-2-10</li>
 * <li>3、开发时间：上午9:26:14</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.desktop.util</li>
 * <li>6、文件名称：Interceptor.java</li>
 * </ul>
 *//*
package com.chinabank.operationmanagesystem.desktop.util;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONArray;

import org.apache.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;
import org.springframework.web.servlet.support.RequestContextUtils;

import com.chinabank.log.core.bean.LogBean;
import com.chinabank.log.core.task.RecvTask;
import com.wangyin.ssoclient.sso.model.Configuration;
import com.wangyin.ssoclient.sso.model.User;
import com.wangyin.ssoclient.sso.service.LoginService;

*//**
 * <ul>
 * <li>1、开发日期：2014-2-10</li>
 * <li>2、开发时间：上午9:26:14</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：Interceptor</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 *//*
public class Interceptor extends HandlerInterceptorAdapter {
	private static final Logger logger = Logger.getLogger(Interceptor.class);
	*//**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2014-2-10</li>
	 * <li>2、开发时间：上午9:26:14</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 *//*
	public Interceptor() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean preHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler) throws Exception {
		// TODO Auto-generated method stub
		HttpSession session = request.getSession();
		Map<?, ?> map = request.getParameterMap();
		User user = (User)session.getAttribute(Configuration.userSession);
		String url = request.getServletPath();
		if(null != user) {
			JSONArray jsonArray = JSONArray.fromObject(map);
			logger.info("User:"+user.getUsername()+",Url:"+url+",Params:"+jsonArray.toString());
			//write log
			return true;
		} else {
			String loginUrl = LoginService.buildLoginUrl(request, session.getId());
			logger.info("用户未登录，返回登陆页面："+loginUrl);
			response.sendRedirect(loginUrl);
		}
		return false;
	}

	@Override
	public void postHandle(HttpServletRequest request,
			HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		Map<String,Object> map = null;
		if(null != modelAndView) {
			map = modelAndView.getModel();
		} else {
			ResponseWrapper wrapper = new ResponseWrapper(response);

		}
		HttpSession session = request.getSession();
		User user = (User)session.getAttribute(Configuration.userSession);
		String url = request.getServletPath();
		ApplicationContext ac = RequestContextUtils.getWebApplicationContext(request);
		ThreadPoolTaskExecutor taskExecutor = (ThreadPoolTaskExecutor) ac.getBean("taskExecutor");
		if(null != user) {
			JSONArray jsonArray = JSONArray.fromObject(map);
			logger.info("User:"+user.getUsername()+",IP:"+ request.getRemoteAddr() +",Url:"+url+",returnParams:"+jsonArray.toString());
			LogBean logBean = new LogBean();
			logBean.setUserName(user.getUsername());
			taskExecutor.execute(RecvTask.getInstance(logBean));
			//write log
		} else {
			String loginUrl = LoginService.buildLoginUrl(request, session.getId());
			logger.info("用户未登录，返回登陆页面："+loginUrl);
			response.sendRedirect(loginUrl);
		}
	}

	@Override
	public void afterCompletion(HttpServletRequest request,
			HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
		// TODO Auto-generated method stub
		super.afterCompletion(request, response, handler, ex);
	}

	*//**  
	 * Title: Interceptor.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 *//*

}
*/