/** 
 * Copyright: Copyright (c)2011
 * Company: 网银在线(ChinaPay) 
 */
package com.chinabank.operationmanagesystem.desktop.dao;

import java.util.List;
import java.util.Map;

import com.chinabank.operationmanagesystem.desktop.annotation.SqlMapper;
import com.chinabank.operationmanagesystem.desktop.bean.MenuBean;

/**  
 * Title: DesktopDao.java
 * Description: TODO(用一句话描述该文件做什么)
 * @author: wywangjiaqi 
 * @version V1.0
 * @history:
 */
@SqlMapper
public interface DesktopDao {
	public List<MenuBean> queryFirstMenu();
	public List<MenuBean> querySecondMenu(Map<String,Object> map);
	public List<MenuBean> queryThirdMenu(Map<String,Object> map);
	public void updateMenu(Map<String,Object> map);
}
