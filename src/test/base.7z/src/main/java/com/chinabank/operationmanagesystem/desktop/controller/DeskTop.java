package com.chinabank.operationmanagesystem.desktop.controller;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringEscapeUtils;

import com.chinabank.operationmanagesystem.book.bean.BookFileDTO;
import com.chinabank.operationmanagesystem.core.bean.ModelAndView;
import com.chinabank.operationmanagesystem.core.bean.UploadFile;
import com.chinabank.operationmanagesystem.desktop.bean.Menu;
import com.chinabank.operationmanagesystem.desktop.bean.UploadObject;
import com.chinabank.operationmanagesystem.desktop.util.ConfigUtil;
import com.chinabank.operationmanagesystem.desktop.util.ReadMenu;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.commons.util.StringUtil;
import com.wangyin.ssoclient.sso.model.Configuration;
import com.wangyin.ssoclient.sso.model.User;

public class DeskTop {
	private static final Logger logger = LoggerFactory.getLogger(DeskTop.class);
	private String ssoUrl;
	
	public void setSsoUrl(String ssoUrl) {
		this.ssoUrl = ssoUrl;
	}
	public Map<String,Object> mainView(Map<String,String> map,User user){
		String title = map.get("title");
		String url = map.get("url");
		Map<String,Object> resultMap=new HashMap<String,Object>();
		resultMap.put("title", StringEscapeUtils.escapeJavaScript(StringEscapeUtils.escapeHtml(title)));
		resultMap.put("url", StringEscapeUtils.escapeJavaScript(StringEscapeUtils.escapeHtml(url)));
		/*HttpServletRequest request = (HttpServletRequest) map.get("request");*/
		String json = "[]";
		if(null != user) {
			String username = user.getUsername();
			String realname = user.getRealname();
			resultMap.put("username", username);
			resultMap.put("realname", realname);
			resultMap.put("clientIndexUrl", Configuration.clientIndexUrl);
			resultMap.put("ssoUrl", ssoUrl);
			json = user.getTreeJson();
		}
		List<Menu> list = ReadMenu.read(json);
		resultMap.put("menuList", list);
		resultMap.put("oldUrl", ConfigUtil.getString("sys.old.main.url"));
/*		String username=(String)map.get("username");
		Map<String, Object> queryMap = new HashMap<String, Object>();
		List<MenuBean> menuList = desktopDao.queryFirstMenu();
		for(MenuBean menuBean : menuList) {
			queryMap.put("first", menuBean.getIndex1());
			List<MenuBean> secondList = desktopDao.querySecondMenu(queryMap);
			for(MenuBean secondMenuBean: secondList) {
				queryMap.put("first", secondMenuBean.getIndex1());
				queryMap.put("second", secondMenuBean.getIndex2());
				List<MenuBean> thirdList = desktopDao.queryThirdMenu(queryMap);
				secondMenuBean.setList(thirdList);
			}
			menuBean.setList(secondList);
		}
		resultMap.put("menuList",menuList);
		resultMap.put("username",username);*/
		
		return resultMap;
	}
	
	public Map<String, Object> branchModelBiz(Map<String, String> map, HttpServletRequest request,User user) {
		Map<String, Object> result = new HashMap<String, Object>();
		String branch = map.get("branch");
		result.put("branch", branch);
		String sessionId = request.getSession().getId();
		String userName = user != null ? user.getUsername() : "";
		logger.info("username:"+userName + ",sessionId:"+sessionId+",分支模式:"+branch);
		request.getSession().setAttribute("branch", branch);
		return result;
	}
	
	public Map<String,Object> testView(Map<String,String> map) {
		Map<String,Object> resultMap=new HashMap<String,Object>();
		/*try {
			UnZipUtils.unZipPlugin("worklist", "worklist_1.zip");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
		return resultMap;
	}
	
	public UploadObject testUpload(Map<String,Object> map,UploadObject uploadObject) {
		uploadObject.setVersion("2.0");
		List<UploadFile> list = uploadObject.getFileList();
		int i = 0;
		for (UploadFile uploadFile : list) {
			uploadFile.setTemp(true);
			uploadFile.setPath("/desktop/testfile/");
			uploadFile.setName("abc"+i++);
		}
		//String username = MapUtil.getParameter(map, "username");
		return uploadObject;
	}
	
	public String testCallback(UploadObject uploadObject,Map<String,Object> params) {
		if(uploadObject.isSuccess()) {
			System.out.println("上传成功:" + uploadObject.getUploadFiles());
		}
		return null;
	}
	
	public UploadFile testDownload(Map<String,String> map){
		String version = map.get("version");
		String strTemp = map.get("temp");
		logger.info("version:"+version+"strTemp:"+strTemp);
		boolean isTemp = Boolean.parseBoolean(strTemp);
		if(StringUtil.isBlank(version)) {
			version = "1.0";
		}
		UploadFile uploadfile = new UploadFile();
		uploadfile.setVersion(version);
		if("1.0".equals(version)) {
			uploadfile.setPathname("testfile/abc.jpg");
		} else if("2.0".equals(version)) {
			uploadfile.setTemp(isTemp);
			uploadfile.setPathname("testfile/abc.jpg");
		}
		uploadfile.setOriginalName("图片.jpg");
		return uploadfile;
	}
	
	public UploadFile downloadDownload(Map<String,String> map,HttpServletRequest request) throws Exception{
		String referer = request.getHeader("referer");
		String appCode = "";
		String owner = "";
		String fileDir = map.get("fileDir");
		String fileName = map.get("fileName");
		try {
			URL url = new URL(referer);
			String path = url.getPath();
			if(null!= path) {
				String[] splits = path.split("/");
				if(splits.length == 5) {
					appCode = splits[2];
					owner = splits[3];
				} else {
					throw new IllegalArgumentException("path不正确："+path);
				}
			} else {
				throw new NullPointerException("url路径为null");
			}
		} catch (MalformedURLException e) {
			throw new Exception("URL:"+referer+"解析错误",e);
		}
		BookFileDTO bookFileDTO = new BookFileDTO();
		bookFileDTO.setAppCode(appCode);
		bookFileDTO.setOwner(owner);
		bookFileDTO.setFileDir(fileDir);
		bookFileDTO.setFileName(fileName);
		UploadFile uploadfile = new UploadFile();
		BookFileDTO result = DeskTopController.queryBookFile(bookFileDTO);
		if(null != result) {
			uploadfile.setVersion("2.0");
			uploadfile.setTemp(false);
			uploadfile.setPathname(fileDir+"/"+fileName);
		} else {
			throw new Exception("文件不存在:"+bookFileDTO.toString());
		}
		return uploadfile;
	}
	
	/**
	 * <ul>
	 * <li>1、开发日期：2014-1-8</li>
	 * <li>2、开发时间：上午11:51:23</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see com.chinabank.operationmanagesystem.desktop.biz.DeskTopBiz#templateView(java.util.Map)
	 */
/*	public Map<String, Object> templateView(Map<String, Object> map) {
*/	public ModelAndView templateView(Map<String, Object> map) {
		Map<String, Object> result = new HashMap<String, Object>();
	/*	List<Action> actions = new ArrayList<Action>();
		Action action = new Action();
		action.setUrl("/certification/certificate/verify.biz");
		action.setFixedParam("type=1");
		action.setParams(new String[]{"customer"});
		action.setText("审核");
		actions.add(action);
		Renderer renderer = new Renderer();
		renderer.setActions(actions);
		List<ColModel> colModels = new ArrayList<ColModel>();
		colModels.add(new ColModel("商户号", "customer"));
		colModels.add(new ColModel("客户名称", "customerName"));
		colModels.add(new ColModel("注册时间", "registerDate"));
		colModels.add(new ColModel("法人姓名", "legalName"));
		colModels.add(new ColModel("手机号", "phone"));
		colModels.add(new ColModel("email", "email"));
		colModels.add(new ColModel("域名", "domain"));
		colModels.add(new ColModel("类型", "type"));
		colModels.add(new ColModel("行业", "industry"));
		colModels.add(new ColModel("认证等级", "level"));
		colModels.add(new ColModel("来源", "source"));
		colModels.add(new ColModel("状态", "status"));
		colModels.add(new ColModel("操作",100,renderer));
		Grid grid = new Grid();
		grid.setColModels(colModels);
		grid.setSingleSelect(false);*/
		/*grid.setDataSource("/certification/certificate/certificate.biz");*/
		/*result.put("grid", GridUtil.getGrid(grid));
		
		List<Option> optionList = new ArrayList<Option>();
		optionList.add(new Option("0001","北京市"));
		optionList.add(new Option("0002","天津市"));
		String url = "/operationmanagesystem/desktop/query.biz";
		Select select = new Select("详细地址","provinceCode","/operationmanagesystem/desktop/province.biz");
		select.setId("province");
		Select child = new Select("","cityCode",url,"province");
		child.setId("city");
		child.setShowDefault(false);
		
		List<QueryData> queryDataList = new ArrayList<QueryData>();
		queryDataList.add(new TextField("商户名","companyName"));
		queryDataList.add(new TextField("商户类型","customerType"));
		queryDataList.add(select);
		queryDataList.add(child);
		queryDataList.add(new DatePairs("签约日期","startTime","endTime",new Date(),new Date()));
		queryDataList.add(new SubmitButton("查询"));*/
		
		/*QueryForm queryForm = new QueryForm("/operationmanagesystem/desktop/template.biz",3,queryDataList);*/
		/*ViewObject viewObject = QueryFormUtil.getQueryForm(queryForm);*/
		/*String jsonStr = "{'title':'审核管理','viewDatas':[{'type':'queryForm','data':{'url':'/certification/certificate/certificate.biz','numPerLine':3,'queryDatas':[{'type':'textfield','data':{'label':'商户号','name':'customer'}},{'type':'textfield','data':{'label':'商户类型','name':'type'}},{'type':'placeholder'},{'type':'ajax','data':[{'label':'省','name':'provinceCode','url':'/operationmanagesystem/desktop/province.biz'},{'label':'市','name':'cityCode','url':'/operationmanagesystem/desktop/query.biz'}]},{'type':'select','data':{'label':'银行','name':'bankCode','url':'/operationmanagesystem/desktop/query.biz','queryValue':'0001'}},{'type':'select','data':{'label':'银行2','name':'bankCode','optionList':[{'text':'广发银行','value':'0001'},{'text':'招商银行','value':'0002'}]}},{'type':'hidden','data':{'name':'customerId','defaultValue':'010101'}},{'type':'datepairs','data':{'label':'查询时间'}},{'type':'submit'}]}},{'type':'grid','data':{'singleSelect':'false','colModels':[{'header':'商户号','name':'customer'},{'header':'客户名称','name':'customerName'},{'header':'法人姓名','name':'legalName'},{'header':'操作','name':'operation','width':100,'renderer':{'actions':[{'text':'审核','url':'/certification/certificate/verify.view','fixedParam':'type=1','params':['customer']}]}}]}}]}";
		View view = JSONParseUtil.getView(jsonStr);
		ViewObject viewObject1 = null;
		viewObject1 = ViewUtil.getView(view);
		result.put("html", viewObject1.getHtml());
		result.put("function", viewObject1.getFunction());
		result.put("ready", viewObject1.getReady());*/
		/*String jsonStr2 = "{\"title\":\"白条分账 > 还款分账\",\"elements\":[{\"code\":\"A\",\"type\":\"text\",\"label\":\"商户号\",\"name\":\"merchantNo\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"B\",\"type\":\"datePairs\",\"label\":\"结算时间\",\"name\":\"settlementDate\",\"rule\":\"required\",\"value\":2},{\"code\":\"C\",\"type\":\"text\",\"label\":\"订单金额\",\"name\":\"orderAmount\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"D\",\"type\":\"text\",\"label\":\"还款本金\",\"name\":\"capitalAmount\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"E\",\"type\":\"text\",\"label\":\"滞纳金\",\"name\":\"overAmount\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"F\",\"type\":\"text\",\"label\":\"手续费\",\"name\":\"fee\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"G\",\"type\":\"button\",\"label\":\"查询\",\"name\":\"submitButton\",\"rule\":\"required\",\"value\":\"QUERY\"},{\"code\":\"H\",\"type\":\"link\",\"label\":\"商户号\",\"name\":\"merchantNo\",\"rule\":\"required\",\"value\":\"/certification/certificate/verify.view?type=1\"}],\"viewDatas\":[{\"type\":\"queryForm\",\"data\":{\"url\":\"/http/boss/credit/queryRepayCredits.biz\",\"queryDatas\":[\"A\",\"B\",\"G\"]}},{\"type\":\"grid\",\"data\":{\"colModels\":[\"H\",\"B\",\"C\",\"D\",\"E\",\"F\"],\"singleSelect\":\"true\",\"autoFit\":\"true\",\"query\":\"false\"}}]}";*/
		String jsonStr2 = "{\"title\":\"白条分账 > 退款分账\",\"elements\":[{\"code\":\"A\",\"type\":\"text\",\"label\":\"商户号\",\"name\":\"merchantNo\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"B\",\"type\":\"datePairs\",\"label\":\"结算时间\",\"name\":\"settlementDate\",\"rule\":\"required\",\"value\":2},{\"code\":\"C\",\"type\":\"text\",\"label\":\"清算时间\",\"name\":\"clearingDate\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"D\",\"type\":\"text\",\"label\":\"清算状态\",\"name\":\"status\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"E\",\"type\":\"text\",\"label\":\"收银台退款订单号\",\"name\":\"cashierRefundNo\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"F\",\"type\":\"text\",\"label\":\"退款订单总金额\",\"name\":\"accountTotal\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"G\",\"type\":\"text\",\"label\":\"退款入账户本金\",\"name\":\"accountAmount\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"H\",\"type\":\"text\",\"label\":\"退款入账户利息\",\"name\":\"accountOverdueFee\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"I\",\"type\":\"text\",\"label\":\"退款入账户手续费\",\"name\":\"accountServiceFee\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"J\",\"type\":\"text\",\"label\":\"京东消费订单号\",\"name\":\"jdOrderNo\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"K\",\"type\":\"text\",\"label\":\"京东ID\",\"name\":\"jdPin\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"L\",\"type\":\"text\",\"label\":\"订单生成日期\",\"name\":\"orderTime\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"M\",\"type\":\"button\",\"label\":\"查询\",\"name\":\"submitButton\",\"rule\":\"required\",\"value\":\"QUERY\"},{\"code\":\"N\",\"type\":\"multiConfirm\",\"label\":\"审核\",\"name\":\"content\",\"rule\":\"\",\"value\":\"/operationmanagesystem/desktop/template.biz\"}],\"viewDatas\":[{\"type\":\"queryForm\",\"data\":{\"url\":\"/dict/dict/queryTest.biz\",\"queryDatas\":[\"A\",\"B\",\"M\"]}},{\"type\":\"grid\",\"data\":{\"colModels\":[\"C\",\"D\",\"E\",\"F\",\"G\",\"H\",\"I\",\"J\",\"K\",\"L\",\"N\"],\"singleSelect\":\"false\",\"autoFit\":\"true\",\"showIndex\":\"true\",\"query\":\"false\"}}]}";
		/*String jsonStr2 = "{\"title\":\"白条分账\",\"elements\":[{\"code\":\"A\",\"type\":\"text\",\"label\":\"商户号\",\"name\":\"merchantNo\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"B\",\"type\":\"datePairs\",\"label\":\"结算时间\",\"name\":\"settlementDate\",\"rule\":\"required\",\"value\":2},{\"code\":\"C\",\"type\":\"text\",\"label\":\"总打款金额\",\"name\":\"allPayAmount\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"D\",\"type\":\"text\",\"label\":\"总本金\",\"name\":\"allCapitalAmount\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"E\",\"type\":\"text\",\"label\":\"总滞纳金\",\"name\":\"allOverdueAmount\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"F\",\"type\":\"text\",\"label\":\"总手续费\",\"name\":\"allServiceAmount\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"G\",\"type\":\"button\",\"label\":\"查询\",\"name\":\"submitButton\",\"rule\":\"required\",\"value\":\"QUERY\"},{\"code\":\"H\",\"type\":\"link\",\"label\":\"商户号\",\"name\":\"merchantNo\",\"rule\":\"required\",\"value\":\"/certification/certificate/verify.view?type=1\"}],\"viewDatas\":[{\"type\":\"queryForm\",\"data\":{\"url\":\"/http/boss/credit/queryRefundCredits.biz\",\"queryDatas\":[\"A\",\"B\",\"G\"]}},{\"type\":\"grid\",\"data\":{\"colModels\":[\"H\",\"B\",\"C\",\"D\",\"E\",\"F\"],\"singleSelect\":\"true\",\"autoFit\":\"true\",\"query\":\"false\"}}]}";*/
	/*	String jsonStr2 = "{\"title\":\"交易查询\",\"elements\":[{\"code\":\"A\",\"type\":\"dict\",\"label\":\"业务类型\",\"name\":\"bizType\",\"rule\":\"required\",\"value\":\"biz\"},{\"code\":\"B\",\"type\":\"datetimePairs\",\"label\":\"订单提交时间\",\"name\":\"submitDate\",\"rule\":\"required\",\"value\":2},{\"code\":\"C\",\"type\":\"datetime\",\"label\":\"订单处理时间\",\"name\":\"dealDate\",\"rule\":\"required\",\"value\":2},{\"code\":\"D\",\"type\":\"text\",\"label\":\"收单银行\",\"name\":\"acceptBank\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"E\",\"type\":\"text\",\"label\":\"订单号\",\"name\":\"orderNum\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"F\",\"type\":\"text\",\"label\":\"银行订单号\",\"name\":\"bankOrder\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"G\",\"type\":\"text\",\"label\":\"支付银行\",\"name\":\"payBank\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"H\",\"type\":\"text\",\"label\":\"金额\",\"name\":\"money\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"I\",\"type\":\"text\",\"label\":\"卡号后4位\",\"name\":\"card\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"J\",\"type\":\"text\",\"label\":\"商户号\",\"name\":\"merchantNo\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"K\",\"type\":\"text\",\"label\":\"卖家名称\",\"name\":\"salerName\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"L\",\"type\":\"text\",\"label\":\"交易类型\",\"name\":\"dict\",\"rule\":\"required\",\"value\":\"tradeType\"},{\"code\":\"M\",\"type\":\"dict\",\"label\":\"交易状态\",\"name\":\"tradeStatus\",\"rule\":\"required\",\"value\":\"tradeStatus\"},{\"code\":\"N\",\"type\":\"dict\",\"label\":\"支付渠道\",\"name\":\"tradeCanal\",\"rule\":\"required\",\"value\":\"tradeCanal\"},{\"code\":\"O\",\"type\":\"text\",\"label\":\"授权号\",\"name\":\"authNum\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"P\",\"type\":\"dict\",\"label\":\"支付状态\",\"name\":\"payStatus\",\"rule\":\"required\",\"value\":\"payStatus\"},{\"code\":\"Q\",\"type\":\"dict\",\"label\":\"退款状态\",\"name\":\"refundStatus\",\"rule\":\"required\",\"value\":\"refundStatus\"},{\"code\":\"R\",\"type\":\"text\",\"label\":\"币种\",\"name\":\"currency\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"S\",\"type\":\"text\",\"label\":\"说明\",\"name\":\"remark\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"T\",\"type\":\"operation\",\"label\":\"操作\",\"name\":\"operation\",\"rule\":\"required\",\"value\":\"{\\\"actions\\\":[{\\\"text\\\":\\\"查补单\\\",\\\"url\\\":\\\"/trade/trade/queryBill.view\\\",\\\"params\\\":[\\\"merchantNo\\\"],\\\"fixedParam\\\":\\\"\\\"}]}\"},{\"code\":\"U\",\"type\":\"text\",\"label\":\"卡号\",\"name\":\"cardNum\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"V\",\"type\":\"button\",\"label\":\"查询\",\"name\":\"submitButton\",\"rule\":\"required\",\"value\":\"QUERY\"},{\"code\":\"W\",\"type\":\"single\",\"label\":\"审核\",\"name\":\"\",\"rule\":\"item.orderNum == '待审核'\",\"value\":\"/dict/dict/test.biz\"},{\"code\":\"X\",\"type\":\"multi\",\"label\":\"批量审核\",\"name\":\"\",\"rule\":\"\",\"value\":\"/dict/dict/testMulti.biz\"},{\"code\":\"Y\",\"type\":\"view\",\"label\":\"主页\",\"name\":\"\",\"rule\":\"\",\"value\":\"/operationmanagesystem/desktop/main.view\"},{\"code\":\"Z\",\"type\":\"jump\",\"label\":\"百度\",\"name\":\"\",\"rule\":\"\",\"value\":\"http://www.baidu.com/\"},{\"code\":\"A1\",\"type\":\"link\",\"label\":\"订单号\",\"name\":\"orderNum\",\"rule\":\"required\",\"value\":\"/operationmanagesystem/desktop/queryOrder.view\"}],\"viewDatas\":[{\"type\":\"queryForm\",\"data\":{\"url\":\"/dict/dict/queryTest.biz\",\"queryDatas\":[\"A\",\"B\",\"C\",\"D\",\"E\",\"F\",\"G\",\"H\",\"I\",\"J\",\"K\",\"L\",\"M\",\"N\",\"O\",\"P\",\"Q\",\"V\"],\"numPerLine\":3}},{\"type\":\"grid\",\"data\":{\"colModels\":[\"B\",\"C\",\"A1\",\"F\",\"D\",\"G\",\"H\",\"R\",\"U\",\"O\",\"J\",\"K\",\"A\",\"M\",\"P\",\"S\",\"Q\",\"T\",\"W\",\"X\",\"Y\",\"Z\"],\"singleSelect\":\"false\"}}]}";*/
//		String jsonStr2 = "{\"title\":\"交易查询\",\"elements\":[{\"code\":\"A\",\"type\":\"dict\",\"label\":\"业务类型\",\"name\":\"bizType\",\"rule\":\"required\",\"value\":\"biz\"},{\"code\":\"B\",\"type\":\"datePairs\",\"label\":\"订单提交时间\",\"name\":\"submitDate\",\"rule\":\"required\",\"value\":2},{\"code\":\"C\",\"type\":\"datePairs\",\"label\":\"订单处理时间\",\"name\":\"dealDate\",\"rule\":\"required\",\"value\":2},{\"code\":\"D\",\"type\":\"bindtext\",\"label\":\"商户号\",\"name\":\"customer\",\"rule\":\"required;maxlength:10\",\"value\":\"customer\"},{\"code\":\"E\",\"type\":\"bindbutton\",\"label\":\"查询商户\",\"name\":\"\",\"rule\":\"\",\"value\":\"/changeorder/change/queryMerchant.view\"},{\"code\":\"F\",\"type\":\"bindlabel\",\"label\":\"商户名\",\"name\":\"customerName\",\"rule\":\"required\",\"value\":\"customer\"},{\"code\":\"G\",\"type\":\"text\",\"label\":\"支付银行\",\"name\":\"payBank\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"H\",\"type\":\"text\",\"label\":\"金额\",\"name\":\"money\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"I\",\"type\":\"text\",\"label\":\"卡号后4位\",\"name\":\"card\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"J\",\"type\":\"text\",\"label\":\"商户号\",\"name\":\"merchantNo\",\"rule\":\"required;number\",\"value\":\"\"},{\"code\":\"K\",\"type\":\"text\",\"label\":\"卖家名称\",\"name\":\"salerName\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"L\",\"type\":\"text\",\"label\":\"交易类型\",\"name\":\"dict\",\"rule\":\"required\",\"value\":\"tradeType\"},{\"code\":\"M\",\"type\":\"dict\",\"label\":\"交易状态\",\"name\":\"tradeStatus\",\"rule\":\"required\",\"value\":\"tradeStatus\"},{\"code\":\"N\",\"type\":\"dict\",\"label\":\"支付渠道\",\"name\":\"tradeCanal\",\"rule\":\"required\",\"value\":\"tradeCanal\"},{\"code\":\"O\",\"type\":\"text\",\"label\":\"授权号\",\"name\":\"authNum\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"P\",\"type\":\"dict\",\"label\":\"支付状态\",\"name\":\"payStatus\",\"rule\":\"required\",\"value\":\"payStatus\"},{\"code\":\"Q\",\"type\":\"dict\",\"label\":\"退款状态\",\"name\":\"refundStatus\",\"rule\":\"required\",\"value\":\"refundStatus\"},{\"code\":\"R\",\"type\":\"text\",\"label\":\"币种\",\"name\":\"currency\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"S\",\"type\":\"text\",\"label\":\"说明\",\"name\":\"remark\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"T\",\"type\":\"operation\",\"label\":\"操作\",\"name\":\"operation\",\"rule\":\"required\",\"value\":\"{\\\"actions\\\":[{\\\"text\\\":\\\"查补单\\\",\\\"url\\\":\\\"/trade/trade/queryBill.view\\\",\\\"params\\\":[\\\"merchantNo\\\"],\\\"fixedParam\\\":\\\"\\\"}]}\"},{\"code\":\"U\",\"type\":\"text\",\"label\":\"卡号\",\"name\":\"cardNum\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"V\",\"type\":\"button\",\"label\":\"查询\",\"name\":\"submitButton\",\"rule\":\"required\",\"value\":\"QUERY\"},{\"code\":\"W\",\"type\":\"ajax\",\"label\":\"ajax提交\",\"name\":\"\",\"rule\":\"required\",\"value\":\"/operationmanagesystem/desktop/main.view\"},{\"code\":\"X\",\"type\":\"view\",\"label\":\"form提交\",\"name\":\"\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"Y\",\"type\":\"jump\",\"label\":\"跳转\",\"name\":\"\",\"rule\":\"required\",\"value\":\"http://www.baidu.com\"}],\"viewDatas\":[{\"type\":\"form\",\"data\":{\"url\":\"/dict/dict/queryTest.biz\",\"queryDatas\":[\"A\",\"B\",\"C\",\"D\",\"E\",\"F\",\"G\",\"H\",\"I\",\"J\",\"K\",\"L\",\"M\",\"N\",\"O\",\"P\",\"Q\",\"V\",\"W\",\"X\",\"Y\"]}}]}";
		/*String jsonStr2 = "{\"title\":\"交易查询\",\"elements\":[{\"code\":\"A\",\"type\":\"dict\",\"label\":\"变更项\",\"name\":\"changeType\",\"rule\":\"required\",\"value\":\"biz\"},{\"code\":\"B\",\"type\":\"text\",\"label\":\"申请人\",\"name\":\"proposer\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"C\",\"type\":\"text\",\"label\":\"商户名\",\"name\":\"customerName\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"D\",\"type\":\"dict\",\"label\":\"状态\",\"name\":\"state\",\"rule\":\"required\",\"value\":\"biz\"},{\"code\":\"E\",\"type\":\"text\",\"label\":\"商户号\",\"name\":\"customer\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"F\",\"type\":\"text\",\"label\":\"变更单号\",\"name\":\"id\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"G\",\"type\":\"text\",\"label\":\"申请时间\",\"name\":\"date\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"H\",\"type\":\"link\",\"label\":\"商户号\",\"name\":\"customer\",\"rule\":\"required\",\"value\":\"/certification/certificate/verify.view?type=1\"},{\"code\":\"I\",\"type\":\"button\",\"label\":\"查询\",\"name\":\"submitButton\",\"rule\":\"required\",\"value\":\"QUERY\"},{\"code\":\"J\",\"type\":\"jump\",\"label\":\"新建变更单\",\"name\":\"\",\"rule\":\"\",\"value\":\"/changeorder/change/changeOrder.view\"}],\"viewDatas\":[{\"type\":\"queryForm\",\"data\":{\"url\":\"/dict/dict/queryTest.biz\",\"queryDatas\":[\"A\",\"B\",\"C\",\"D\",\"E\",\"I\"],\"numPerLine\":3}},{\"type\":\"grid\",\"data\":{\"colModels\":[\"F\",\"A\",\"B\",\"G\",\"H\",\"C\",\"D\",\"J\"],\"singleSelect\":\"false\"}}]}";*/
		/*String jsonStr2 = "{\"title\":\"新增公告\",\"elements\":[{\"code\":\"A\",\"type\":\"text\",\"label\":\"商户号\",\"name\":\"merchantid\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"B\",\"type\":\"text\",\"label\":\"商户范围\",\"name\":\"merchantid\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"C\",\"type\":\"datetime\",\"label\":\"注册时间\",\"name\":\"registerDate\",\"rule\":\"required\",\"value\":0},{\"code\":\"D\",\"type\":\"dict\",\"label\":\"商户性质\",\"name\":\"dealDate\",\"rule\":\"required\",\"value\":\"biz\"},{\"code\":\"E\",\"type\":\"dict\",\"label\":\"商户认证等级\",\"name\":\"dealDate\",\"rule\":\"required\",\"value\":\"biz\"},{\"code\":\"F\",\"type\":\"text\",\"label\":\"标题\",\"name\":\"title\",\"rule\":\"required\",\"value\":\"\"},{\"code\":\"G\",\"type\":\"remark\",\"label\":\"内容\",\"name\":\"context\",\"rule\":\"required\",\"value\":\"请输入公告...\"},{\"code\":\"H\",\"type\":\"datetime\",\"label\":\"生效时间\",\"name\":\"bankOrder\",\"rule\":\"required\",\"value\":0},{\"code\":\"I\",\"type\":\"datetime\",\"label\":\"失效时间\",\"name\":\"bankOrder\",\"rule\":\"required\",\"value\":1},{\"code\":\"J\",\"type\":\"button\",\"label\":\"发布\",\"name\":\"submitButton\",\"rule\":\"required\",\"value\":\"QUERY\"},{\"code\":\"K\",\"type\":\"button\",\"label\":\"保存\",\"name\":\"submitButton\",\"rule\":\"required\",\"value\":\"QUERY\"},{\"code\":\"L\",\"type\":\"placeholder\",\"label\":\"\",\"name\":\"\",\"rule\":\"\",\"value\":\"\"}],\"viewDatas\":[{\"type\":\"form\",\"data\":{\"url\":\"/dict/dict/queryTest.biz\",\"queryDatas\":[\"A\",\"B\",\"C\",\"D\",\"E\",\"F\",\"I\",\"J\",\"H\",\"L\",\"G\",\"K\"],\"numPerLine\":1}}]}";*/
		result.put("merchantNo", "123");
		result.put("settlementDateStart", "2014-06-07");
		return new ModelAndView(jsonStr2,result);
		/*return result;*/
	}

	public ModelAndView bindView(Map<String, Object> map) {
		String jsonStr = "";
		return new ModelAndView(jsonStr,null);
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-1-8</li>
	 * <li>2、开发时间：上午11:51:23</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see com.chinabank.operationmanagesystem.desktop.biz.DeskTopBiz#templateBiz(java.util.Map)
	 */
	public Map<String, Object> templateBiz(Map<String, Object> map) {
		return null;
		/*Map<String, Object> result = new HashMap<String, Object>();
		List<Info> list = new ArrayList<Info>();
		Info info = new Info();
		info.setCustomer("22315664");
		info.setCustomerName("网银在线");
		info.setDomain("http://www.wangyin.com");
		info.setEmail("wangyin@wangyin.com");
		info.setIndustry("金融");
		info.setLegalName("张三");
		info.setLevel("实名认证");
		info.setPhone("188888888888");
		info.setRegisterDate("2013-12-30");
		info.setSource("POP商户");
		info.setStatus("审核完成");
		info.setType("企业");
		list.add(info);
		result.put("rows", list);
		result.put("total", 1);
		return result;*/
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-1-8</li>
	 * <li>2、开发时间：下午6:26:25</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see com.chinabank.operationmanagesystem.desktop.biz.DeskTopBiz#queryBiz(java.util.Map)
	 */
	/*public Map<String, Object> queryBiz(Map<String, Object> map) {
		Map<String, Object> result = new HashMap<String,Object>();
		String provinceCode = (String) map.get("code");
		ManagerInfoDataEntity mide = new ManagerInfoDataEntity();
		List<ManagerInfoDataEntity> list = new ArrayList<ManagerInfoDataEntity>();
		if(provinceCode.equals("0001")) {
			mide.setDictId("0003");
			mide.setDict("朝阳区");
			list.add(mide);
		} else if(provinceCode.equals("0002")){
			mide.setDictId("0004");
			mide.setDict("武清区武清区武清区武清区武清区武清区武清区武清区");
			list.add(mide);
		}
		List<Option> opList = new ArrayList<Option>();
		for (ManagerInfoDataEntity managerInfoDataEntity : list) {
			Option option = new Option();
			option.setValue(managerInfoDataEntity.getDictId());
			option.setText(managerInfoDataEntity.getDict());
			opList.add(option);
		}
		result.put("list", opList);
		return result;
	}
	
	public Map<String, Object> provinceBiz() {
		Map<String, Object> result = new HashMap<String,Object>();
		List<Option> list = new ArrayList<Option>();
		Option option = new Option("0001","北京市");
		list.add(option);
		option = new Option("0002","天津市");
		list.add(option);
		result.put("list", list);
		return result;
	}
	*/
	
	public String querySuggestionBiz(Map<String, Object> map) {
		String callBackName = String.valueOf(map.get("callback"));
		String json = "[\"中国\",\"美国\",\"德国\",\"英国\"]";
		String result = callBackName+"("+json+")";
		return result;
	}
	
	
	/**
	 * <ul>
	 * <li>1、开发日期：2014年6月17日</li>
	 * <li>2、开发时间：上午10:54:43</li>
	 * <li>3、作          者：wychangxiangwei</li>
	 * <li>4、返回类型：Map<String,Object></li>
	 * <li>5、方法含义：</li>
	 * <li>6、方法说明：进入到上传的主界面</li>
	 * </ul>
	 * @param map
	 * @return
	 */
	public Map<String,Object> toPublishMainView(Map<String,String> map) {
		Map<String,Object> resultMap=new HashMap<String,Object>();
		return resultMap;
	}
	
	/**
	 * <ul>
	 * <li>1、开发日期：2014年6月17日</li>
	 * <li>2、开发时间：上午10:55:34</li>
	 * <li>3、作          者：wychangxiangwei</li>
	 * <li>4、返回类型：UploadObject</li>
	 * <li>5、方法含义：</li>
	 * <li>6、方法说明：上传文件，确定文件版本保存到文件名中</li>
	 * </ul>
	 * @param map
	 * @param uploadObject
	 * @return
	 */
	/*public UploadObject onlineUpload(Map<String,Object> map,UploadObject uploadObject) {
		List<UploadFile> list = uploadObject.getFileList();
		Integer version = 0;
		//根据前台传入的systemId，确定存放二级目录路径，并根据文件现存版本号生成文件版本号。
		for (UploadFile uploadFile : list) {
			String systemName = uploadObject.getParams().get("systemName")+"";
			try {
				version = UnZipUtils.getMaxVersion(systemName);
			} catch (Exception e) {
				e.printStackTrace();
			}
			uploadFile.setPath("plugins/zip/"+systemName);
			uploadFile.setName(systemName+"_"+version);
		}
		return uploadObject;
	}*/
	
	/**
	 * <ul>
	 * <li>1、开发日期：2014年6月17日</li>
	 * <li>2、开发时间：上午10:55:39</li>
	 * <li>3、作          者：wychangxiangwei</li>
	 * <li>4、返回类型：String</li>
	 * <li>5、方法含义：</li>
	 * <li>6、方法说明：上传成功后的回调函数</li>
	 * </ul>
	 * @param uploadObject
	 * @return
	 */
	/*public String onlineCallback(UploadObject uploadObject) {//appCdoe、sign、uploadObject、user
		boolean isSuccess = true;
		String message = "上传成功";
		if(uploadObject.getFileList().size() <= 0) {
			isSuccess = false;
			message = "请选择待上传的zip包！";
		}else {
			UploadFile uploadFile = uploadObject.getFileList().get(0);
			String systemName = uploadObject.getParams().get("systemName")+"";
			String originalName = uploadFile.getOriginalName();
			if(originalName.equals(systemName + ".zip")) {
				String name = uploadFile.getName();
				try {
					UnZipUtils.unZipPlugin(systemName, name );
				} catch (IOException e) {
					logger.error(e.getMessage(),e.fillInStackTrace());
					isSuccess = false;
					message = e.getMessage();
				}
			} else {
				isSuccess = false;
				message = "升级失败，所传zip包与升级系统不符，请检查后再试！";
			}
			
		}
		//return "{\"success\":true,\"message\":\"上传成功\"}";
		return "{\"success\":" + isSuccess + ",\"message\":\"" + message + "\"}";
	}*/

}
