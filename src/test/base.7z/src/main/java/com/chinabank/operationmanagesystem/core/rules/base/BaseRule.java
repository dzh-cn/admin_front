/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-5-8</li>
 * <li>3、开发时间：上午11:51:34</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.rules</li>
 * <li>6、文件名称：BaseRule.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.rules.base;

import java.io.Serializable;

/**
 * <ul>
 * <li>1、开发日期：2014-5-8</li>
 * <li>2、开发时间：上午11:51:34</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：BaseRule</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class BaseRule implements Serializable{
	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：BaseRule.java</li>
	 * <li>3、字段含义：</li>
	 * </ul>
	 */
	private static final long serialVersionUID = 5024822571624745999L;
	/**  
	 * Title: BaseRule.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	private String type;
	private String name;
	private String message;
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：上午11:51:52</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“name”的值
	 */
	public String getName() {
		return name;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：上午11:51:52</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“name”的值将赋给字段“name”
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：上午11:56:03</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“message”的值
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：上午11:56:03</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“message”的值将赋给字段“message”
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午1:09:32</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“type”的值
	 */
	public String getType() {
		return type;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午1:09:32</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“type”的值将赋给字段“type”
	 */
	public void setType(String type) {
		this.type = type;
	}
	
}
