/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-1-8</li>
 * <li>3、开发时间：下午1:51:43</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.bean.query</li>
 * <li>6、文件名称：Select.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.bean.query;

import java.util.List;

/**
 * <ul>
 * <li>1、开发日期：2014-1-8</li>
 * <li>2、开发时间：下午1:51:43</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：Select</li>
 * <li>5、类型意图：表单中Select的实体，分为两种情况
 * 		一、固定值：必填name和optionList
 * 		二、ajax联动菜单：父菜单-除label、id和explain选填，其他必填
 * 					子菜单-只需填写name</li>
 * 
 * </ul>
 *
 */
public class Select extends QueryData {

	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：Select.java</li>
	 * </ul>
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * ajax联动菜单必填，post时的url
	 */
	private String url;
	/**
	 * ajax联动菜单，post时，发送的参数名称
	 * @Default "code"
	 */
	private String queryParamName = "code";
	/**
	 * ajax发送post时，发送的参数值，非ajax可不填
	 */
	private String queryValue;
	/**
	 * ajax联动菜单必填，ajax返回数据时text的参数名
	 * @Default "text"
	 */
	private String jsonTextName = "text";
	/**
	 * ajax联动菜单必填，ajax返回数据时value的参数名
	 * @Default "value"
	 */
	private String jsonValueName = "value";
	/**
	 * 是否显示初始option，例如显示 “全部”
	 */
	private boolean showDefault = true;
	/**
	 * 默认option的text
	 * @Default "==请选择=="
	 */
	private String defaultText="==请选择==";
	/**
	 * 默认option的value
	 * @Default ""
	 */
	private String defaultValue="";
	/**
	 * select的option值
	 */
	private List<Option> optionList;
	/*private List<ExtraData> extraList;*/
	/**
	 * ajax联动菜单必填，联动菜单关联的子菜单
	 */
	/*private Select child;*/
	/**
	 * 联动时的父ID，内部使用
	 */
	private String parentId;

	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2014-1-8</li>
	 * <li>2、开发时间：下午1:51:43</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 */
	public Select() {
		// TODO Auto-generated constructor stub
	}
	
	public Select(String label, String name, List<Option> optionList) {
		super(label, name);
		this.optionList = optionList;
	}


	public Select(String label, String name, List<Option> optionList,
			String defaultText, String defaultValue) {
		super(label, name);
		this.optionList = optionList;
		this.defaultText = defaultText;
		this.defaultValue = defaultValue;
	}

	public Select(String label, String name, List<Option> optionList,
			boolean showDefault) {
		super(label, name);
		this.optionList = optionList;
		this.showDefault = showDefault;
	}

	public Select(String label, String name, List<Option> optionList,
			String url, String queryParamName, String jsonTextName,
			String jsonValueName, String parentId) {
		super(label, name);
		this.optionList = optionList;
		this.url = url;
		this.queryParamName = queryParamName;
		this.jsonTextName = jsonTextName;
		this.jsonValueName = jsonValueName;
		this.parentId = parentId;
	}

	public Select(String label, String name) {
		super(label, name);
	}
	
	public Select(String label, String name, String url, String parentId) {
		super(label, name);
		this.url = url;
		this.parentId = parentId;
	}
	
	public Select(String label, String name, String url) {
		super(label, name);
		this.url = url;
	}

	
	/**  
	 * Title: Select.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public List<Option> getOptionList() {
		return optionList;
	}
	public void setOptionList(List<Option> optionList) {
		this.optionList = optionList;
	}
/*	public List<ExtraData> getExtraList() {
		return extraList;
	}
	public void setExtraList(List<ExtraData> extraList) {
		this.extraList = extraList;
	}*/
/*	public Select getChild() {
		return child;
	}
	public void setChild(Select child) {
		this.child = child;
	}*/
	public String getJsonTextName() {
		return jsonTextName;
	}
	public void setJsonTextName(String jsonTextName) {
		this.jsonTextName = jsonTextName;
	}
	public String getJsonValueName() {
		return jsonValueName;
	}
	public void setJsonValueName(String jsonValueName) {
		this.jsonValueName = jsonValueName;
	}
	public String getQueryParamName() {
		return queryParamName;
	}
	public void setQueryParamName(String queryParamName) {
		this.queryParamName = queryParamName;
	}
	public String getDefaultText() {
		return defaultText;
	}
	public void setDefaultText(String defaultText) {
		this.defaultText = defaultText;
	}
	public String getDefaultValue() {
		return defaultValue;
	}
	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}
	public boolean isShowDefault() {
		return showDefault;
	}
	public void setShowDefault(boolean showDefault) {
		this.showDefault = showDefault;
	}

	public String getParentId() {
		return parentId;
	}

	public void setParentId(String parentId) {
		this.parentId = parentId;
	}

	public String getQueryValue() {
		return queryValue;
	}

	public void setQueryValue(String queryValue) {
		this.queryValue = queryValue;
	}
	
}
