/**
 * <p>项目名称：certification<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2013-12-30</li>
 * <li>3、开发时间：上午11:39:09</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.certification.vo</li>
 * <li>6、文件名称：Info.java</li>
 * </ul>
 */
package com.chinabank.certification.vo;

import java.io.Serializable;

/**
 * <ul>
 * <li>1、开发日期：2013-12-30</li>
 * <li>2、开发时间：上午11:39:09</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：Info</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class Info implements Serializable{

	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：Info.java</li>
	 * </ul>
	 */
	private static final long serialVersionUID = 1L;
	private String customer;//商户号
	private String customerName;//客户名称
	private String registerDate;//注册时间
	private String legalName;//法人姓名
	private String phone;//手机号
	private String email;//email
	private String domain;//域名
	private String type;//类型
	private String industry;//行业
	private String level;//认证等级
	private String source;//来源
	private String status;//状态（待审核）
	private String submitDate;//提交审核时间
	private String count;//提交审核次数
	private String operator;//审核人
	private String audiDate;//审核时间

	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2013-12-30</li>
	 * <li>2、开发时间：上午11:39:09</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 */
	public Info() {
		// TODO Auto-generated constructor stub
	}
	/**  
	 * Title: Info.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */

	public String getCustomer() {
		return customer;
	}

	public void setCustomer(String customer) {
		this.customer = customer;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getRegisterDate() {
		return registerDate;
	}

	public void setRegisterDate(String registerDate) {
		this.registerDate = registerDate;
	}

	public String getLegalName() {
		return legalName;
	}

	public void setLegalName(String legalName) {
		this.legalName = legalName;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getIndustry() {
		return industry;
	}

	public void setIndustry(String industry) {
		this.industry = industry;
	}

	public String getLevel() {
		return level;
	}

	public void setLevel(String level) {
		this.level = level;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-29</li>
	 * <li>2、开发时间：下午12:06:09</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“submitDate”的值
	 */
	public String getSubmitDate() {
		return submitDate;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-29</li>
	 * <li>2、开发时间：下午12:06:09</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“submitDate”的值将赋给字段“submitDate”
	 */
	public void setSubmitDate(String submitDate) {
		this.submitDate = submitDate;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-29</li>
	 * <li>2、开发时间：下午12:06:09</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“count”的值
	 */
	public String getCount() {
		return count;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-29</li>
	 * <li>2、开发时间：下午12:06:09</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“count”的值将赋给字段“count”
	 */
	public void setCount(String count) {
		this.count = count;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-29</li>
	 * <li>2、开发时间：下午12:06:09</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“operator”的值
	 */
	public String getOperator() {
		return operator;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-29</li>
	 * <li>2、开发时间：下午12:06:09</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“operator”的值将赋给字段“operator”
	 */
	public void setOperator(String operator) {
		this.operator = operator;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-29</li>
	 * <li>2、开发时间：下午12:06:09</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“audiDate”的值
	 */
	public String getAudiDate() {
		return audiDate;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-29</li>
	 * <li>2、开发时间：下午12:06:09</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“audiDate”的值将赋给字段“audiDate”
	 */
	public void setAudiDate(String audiDate) {
		this.audiDate = audiDate;
	}
	
	
}
