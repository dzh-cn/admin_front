/** 
 * Copyright: Copyright (c)2013
 * Company: 网银在线(ChinaBank) 
 */
package com.chinabank.operationmanagesystem.desktop.util;

import java.io.InputStream;
import java.io.OutputStream;

import com.chinabank.operationmanagesystem.core.bean.UploadFile;

/**  
 * Title: DownloadUtil.java
 * Description: 下载接口
 * @author: wywangjiaqi 
 * @version V1.0
 * @history:
 */

public interface DownloadUtil {
	public boolean upload(InputStream local, UploadFile uploadfile,String uniqueID);
	public boolean download(OutputStream local, UploadFile uploadfile,String uniqueID);
}
