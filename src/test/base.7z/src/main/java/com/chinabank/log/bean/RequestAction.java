/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-2-14</li>
 * <li>3、开发时间：下午3:54:58</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.log.core.bean</li>
 * <li>6、文件名称：RequestAction.java</li>
 * </ul>
 */
package com.chinabank.log.bean;

import java.io.Serializable;

/**
 * <ul>
 * <li>1、开发日期：2014-2-14</li>
 * <li>2、开发时间：下午3:54:58</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：RequestAction</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class RequestAction implements Serializable{

	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：RequestAction.java</li>
	 * </ul>
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 属性:请求要访问的类<br>
	 * 含义:请求要访问的类。<br>
	 */
	private String reqClass = null;
	/**
	 * 属性:请求要访问的方法<br>
	 * 含义:请求要访问的方法。<br>
	 */
	private String reqMethod = null;
	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2014-2-14</li>
	 * <li>2、开发时间：下午3:54:58</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 */
	public RequestAction() {
		// TODO Auto-generated constructor stub
	}
	
	public RequestAction(String reqClass, String reqMethod) {
		super();
		this.reqClass = reqClass;
		this.reqMethod = reqMethod;
	}
	
	public String getReqClass() {
		return reqClass;
	}
	public void setReqClass(String reqClass) {
		this.reqClass = reqClass;
	}
	public String getReqMethod() {
		return reqMethod;
	}
	public void setReqMethod(String reqMethod) {
		this.reqMethod = reqMethod;
	}


	/**  
	 * Title: RequestAction.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */

}
