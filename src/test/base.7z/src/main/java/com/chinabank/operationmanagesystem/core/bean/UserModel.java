/**
 * <p>项目名称：oms-0.0.5<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-6-25</li>
 * <li>3、开发时间：上午10:27:22</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.desktop.bean</li>
 * <li>6、文件名称：User.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.bean;

import java.io.Serializable;

import com.chinabank.operationmanagesystem.core.sso.URLCollection;

/**
 * <ul>
 * <li>1、开发日期：2014-6-25</li>
 * <li>2、开发时间：上午10:27:22</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：User</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class UserModel implements Serializable {
	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：User.java</li>
	 * <li>3、字段含义：</li>
	 * </ul>
	 */
	private static final long serialVersionUID = 4561291430625861779L;
	/**  
	 * Title: User.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	private String userName;
	private String realName;
	private String tel;
	private String phone;
	private String mail;
	private URLCollection urlCollection;
	/**
	 * <ul>
	 * <li>1、开发日期：2014-6-25</li>
	 * <li>2、开发时间：上午10:28:26</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“userName”的值
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-6-25</li>
	 * <li>2、开发时间：上午10:28:26</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“userName”的值将赋给字段“userName”
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-6-25</li>
	 * <li>2、开发时间：上午10:28:26</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“realName”的值
	 */
	public String getRealName() {
		return realName;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-6-25</li>
	 * <li>2、开发时间：上午10:28:26</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“realName”的值将赋给字段“realName”
	 */
	public void setRealName(String realName) {
		this.realName = realName;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-6-25</li>
	 * <li>2、开发时间：上午10:28:26</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“tel”的值
	 */
	public String getTel() {
		return tel;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-6-25</li>
	 * <li>2、开发时间：上午10:28:26</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“tel”的值将赋给字段“tel”
	 */
	public void setTel(String tel) {
		this.tel = tel;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-6-25</li>
	 * <li>2、开发时间：上午10:28:26</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“phone”的值
	 */
	public String getPhone() {
		return phone;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-6-25</li>
	 * <li>2、开发时间：上午10:28:26</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“phone”的值将赋给字段“phone”
	 */
	public void setPhone(String phone) {
		this.phone = phone;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-6-25</li>
	 * <li>2、开发时间：上午10:28:26</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“mail”的值
	 */
	public String getMail() {
		return mail;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-6-25</li>
	 * <li>2、开发时间：上午10:28:26</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“mail”的值将赋给字段“mail”
	 */
	public void setMail(String mail) {
		this.mail = mail;
	}
	
	public boolean isPermission(String url) {
		return urlCollection.invoke(url);
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-6-30</li>
	 * <li>2、开发时间：上午10:04:06</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "UserModel [userName=" + userName + ", realName=" + realName
				+ ", tel=" + tel + ", phone=" + phone + ", mail=" + mail + "]";
	}
	
}
