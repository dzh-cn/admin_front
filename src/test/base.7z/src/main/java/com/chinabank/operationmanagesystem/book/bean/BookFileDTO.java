/**
 * <p>项目名称：boss-billfile<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-3-20</li>
 * <li>3、开发时间：下午1:15:27</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.wangyin.boss.billfile.dto</li>
 * <li>6、文件名称：BillFileInfo.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.book.bean;

import java.io.Serializable;
import java.util.Date;

import com.wangyin.operation.enums.FileStatusEnum;
import com.wangyin.operation.enums.FileTypeEnum;

/**
 * <ul>
 * <li>1、开发日期：2014-3-20</li>
 * <li>2、开发时间：下午1:15:27</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：BillFileInfo</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class BookFileDTO implements Serializable {

	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：BillFileInfo.java</li>
	 * <li>3、字段含义：</li>
	 * </ul>
	 */
	private static final long serialVersionUID = -3273684430465298141L;
	/**  
	 * Title: BillFileInfo.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	/**
	 * 对账文件所属系统
	 */
	private String appCode;
	/**
	 * 对账文件所有者
	 */
	private String owner;
	/**
	 * 对账文件目录
	 */
	private String fileDir;
	/**
	 * 对账文件名
	 */
	private String fileName;
	/**
	 * 对账文件类型
	 */
	private FileTypeEnum fileType = FileTypeEnum.BOSS;
	/**
	 * 对账文件状态
	 */
	private FileStatusEnum status;
	/**
	 * 日期范围
	 */
	private String dateRange;
	/**
	 * 备注
	 */
	private String common;
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-20</li>
	 * <li>2、开发时间：下午2:00:57</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“appCode”的值
	 */
	public String getAppCode() {
		return appCode;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-20</li>
	 * <li>2、开发时间：下午2:00:57</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“appCode”的值将赋给字段“appCode”
	 */
	public void setAppCode(String appCode) {
		this.appCode = appCode;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-20</li>
	 * <li>2、开发时间：下午2:00:57</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“owner”的值
	 */
	public String getOwner() {
		return owner;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-20</li>
	 * <li>2、开发时间：下午2:00:57</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“owner”的值将赋给字段“owner”
	 */
	public void setOwner(String owner) {
		this.owner = owner;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-20</li>
	 * <li>2、开发时间：下午2:00:57</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“fileDir”的值
	 */
	public String getFileDir() {
		return fileDir;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-20</li>
	 * <li>2、开发时间：下午2:00:57</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“fileDir”的值将赋给字段“fileDir”
	 */
	public void setFileDir(String fileDir) {
		this.fileDir = fileDir;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-20</li>
	 * <li>2、开发时间：下午2:00:57</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“fileName”的值
	 */
	public String getFileName() {
		return fileName;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-20</li>
	 * <li>2、开发时间：下午2:00:57</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“fileName”的值将赋给字段“fileName”
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-20</li>
	 * <li>2、开发时间：下午2:00:57</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“fileType”的值
	 */
	public FileTypeEnum getFileType() {
		return fileType;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-20</li>
	 * <li>2、开发时间：下午2:00:57</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“fileType”的值将赋给字段“fileType”
	 */
	public void setFileType(FileTypeEnum fileType) {
		this.fileType = fileType;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-20</li>
	 * <li>2、开发时间：下午2:00:57</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“status”的值
	 */
	public FileStatusEnum getStatus() {
		return status;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-20</li>
	 * <li>2、开发时间：下午2:00:57</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“status”的值将赋给字段“status”
	 */
	public void setStatus(FileStatusEnum status) {
		this.status = status;
	}
	
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-14</li>
	 * <li>2、开发时间：上午10:51:32</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“dateRange”的值
	 */
	public String getDateRange() {
		return dateRange;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-14</li>
	 * <li>2、开发时间：上午10:51:32</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“dateRange”的值将赋给字段“dateRange”
	 */
	public void setDateRange(String dateRange) {
		this.dateRange = dateRange;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-20</li>
	 * <li>2、开发时间：下午2:00:57</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“common”的值
	 */
	public String getCommon() {
		return common;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-20</li>
	 * <li>2、开发时间：下午2:00:57</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“common”的值将赋给字段“common”
	 */
	public void setCommon(String common) {
		this.common = common;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2015-3-2</li>
	 * <li>2、开发时间：下午5:33:30</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "BookFileDTO [appCode=" + appCode + ", owner=" + owner
				+ ", fileDir=" + fileDir + ", fileName=" + fileName
				+ ", fileType=" + fileType + ", status=" + status
				+ ", dateRange=" + dateRange + ", common=" + common + "]";
	}
	
	
}
