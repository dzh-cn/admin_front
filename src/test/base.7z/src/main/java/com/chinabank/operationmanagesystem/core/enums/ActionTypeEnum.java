/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-1-10</li>
 * <li>3、开发时间：下午4:00:56</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.enums</li>
 * <li>6、文件名称：FormType.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.enums;

/**
 * <ul>
 * <li>1、开发日期：2014-1-10</li>
 * <li>2、开发时间：下午4:00:56</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：FormType</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public enum ActionTypeEnum {
	JUMP(0,"J","jump","跳转动作"),
	VIEW(1,"V","view","页面动作"),
	SINGLE_AJAX(2,"S","single","单条ajax动作"),
	MULTI_AJAX(3,"M","multi","多条ajax动作"),
	SINGLE_CONFIRM(4,"S_C","singleConfirm","单条再次确认按钮"),
	SINGLE_MESSAGE(5,"S_MSG","singleMessage","单条信息按钮"),
	MULTI_CONFIRM(6,"M_C","multiConfirm","多条再次确认按钮"),
	MULTI_MESSAGE(7,"M_MSG","multiMessage","多条信息按钮"),
	SINGLE_DIALOG(8,"S_DLG","singleDialog","单条弹窗"),
	MULTI_DIALOG(9,"M_DLG","multiDialog","多条弹窗"),
	DIALOG(10,"DLG","dialog","无条件弹窗");
	
	private int order;
	private String code;
	private String name;
	private String desc;
	private ActionTypeEnum(int order,String code,String name,String desc) {
		this.order = order;
		this.code = code;
		this.name = name;
		this.desc = desc;
	}
	/**
	 * 
	 * <ul>
	 * <li>1、开发日期：2014-1-8</li>
	 * <li>2、开发时间：上午9:39:30</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、返回类型：AlignEnum</li>
	 * <li>5、方法含义：根据code找到对应枚举类型</li>
	 * <li>6、方法说明：找不到时返回null</li>
	 * </ul>
	 * @param code
	 * @return
	 */
	public static ActionTypeEnum getByCode(String code) {
		ActionTypeEnum formTypeenum = null;
		for(ActionTypeEnum ele : ActionTypeEnum.values()) {
			if(ele.getCode().equals(code)) {
				formTypeenum = ele;
				break;
			}
		}
		return formTypeenum;
	}
	public int getOrder() {
		return order;
	}
	public void setOrder(int order) {
		this.order = order;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
}
