/**
 * <p>项目名称：oms-0.0.5<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-6-25</li>
 * <li>3、开发时间：下午7:15:34</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.dubbo.beans</li>
 * <li>6、文件名称：QueryBean.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.dubbo.beans;

import java.io.Serializable;

/**
 * <ul>
 * <li>1、开发日期：2014-6-25</li>
 * <li>2、开发时间：下午7:15:34</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：QueryBean</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class QueryBean implements Serializable{
	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：QueryBean.java</li>
	 * <li>3、字段含义：</li>
	 * </ul>
	 */
	private static final long serialVersionUID = -5608005229196008098L;
	/**  
	 * Title: QueryBean.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	private String customer;
	private String accountDate;
	/**
	 * <ul>
	 * <li>1、开发日期：2014-6-25</li>
	 * <li>2、开发时间：下午7:16:11</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“customer”的值
	 */
	public String getCustomer() {
		return customer;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-6-25</li>
	 * <li>2、开发时间：下午7:16:11</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“customer”的值将赋给字段“customer”
	 */
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-6-25</li>
	 * <li>2、开发时间：下午7:16:11</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“accountDate”的值
	 */
	public String getAccountDate() {
		return accountDate;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-6-25</li>
	 * <li>2、开发时间：下午7:16:11</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“accountDate”的值将赋给字段“accountDate”
	 */
	public void setAccountDate(String accountDate) {
		this.accountDate = accountDate;
	}
	
}
