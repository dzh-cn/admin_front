/** 
 * Copyright: Copyright (c)2011
 * Company: 网银在线(ChinaPay) 
 */
package com.chinabank.operationmanagesystem.desktop.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

/**  
 * Title: UniqueID.java
 * Description: 生成记录log4j日志唯一编号
 * @author: wywangjiaqi 
 * @version V1.0
 * @history:
 */

public class UniqueID {

	/**    
	 * 创建一个新的实例 UniqueID.    
	 *        
	 */
	public UniqueID() {
		// TODO Auto-generated constructor stub
	}
	
	public static String randomUID() {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");
		Random r = new Random();
		return sdf.format(date) + String.valueOf(r.nextInt(1000));
	}
	
	/**  
	 * Title: UniqueID.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wywangjiaqi 
	 * @version V1.0
	 * @history:
	 */
}
