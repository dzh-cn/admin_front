/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-3-27</li>
 * <li>3、开发时间：下午4:18:19</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.dict.bean</li>
 * <li>6、文件名称：TestVO.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.dict.bean;

/**
 * <ul>
 * <li>1、开发日期：2014-3-27</li>
 * <li>2、开发时间：下午4:18:19</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：TestVO</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class TestVO {
	private String submitDate;
	private String dealDate;
	private String orderNum;
	private String bankOrder;
	private String acceptBank;
	private String payBank;
	private String money;
	private String currency;
	private String cardNum;
	private String authNum;
	private String merchantNo;
	private String salerName;
	private String bizType;
	private String tradeStatus;
	private String payStatus;
	private String remark;
	private String refundStatus;
	
	public TestVO(){}
	
	public TestVO(String submitDate, String dealDate, String orderNum,
			String bankOrder, String acceptBank, String payBank, String money,
			String currency, String cardNum, String authNum, String merchantNo,
			String salerName, String bizType, String tradeStatus,
			String payStatus, String remark, String refundStatus) {
		super();
		this.submitDate = submitDate;
		this.dealDate = dealDate;
		this.orderNum = orderNum;
		this.bankOrder = bankOrder;
		this.acceptBank = acceptBank;
		this.payBank = payBank;
		this.money = money;
		this.currency = currency;
		this.cardNum = cardNum;
		this.authNum = authNum;
		this.merchantNo = merchantNo;
		this.salerName = salerName;
		this.bizType = bizType;
		this.tradeStatus = tradeStatus;
		this.payStatus = payStatus;
		this.remark = remark;
		this.refundStatus = refundStatus;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“submitDate”的值
	 */
	public String getSubmitDate() {
		return submitDate;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“submitDate”的值将赋给字段“submitDate”
	 */
	public void setSubmitDate(String submitDate) {
		this.submitDate = submitDate;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“dealDate”的值
	 */
	public String getDealDate() {
		return dealDate;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“dealDate”的值将赋给字段“dealDate”
	 */
	public void setDealDate(String dealDate) {
		this.dealDate = dealDate;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“orderNum”的值
	 */
	public String getOrderNum() {
		return orderNum;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“orderNum”的值将赋给字段“orderNum”
	 */
	public void setOrderNum(String orderNum) {
		this.orderNum = orderNum;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“bankOrder”的值
	 */
	public String getBankOrder() {
		return bankOrder;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“bankOrder”的值将赋给字段“bankOrder”
	 */
	public void setBankOrder(String bankOrder) {
		this.bankOrder = bankOrder;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“acceptBank”的值
	 */
	public String getAcceptBank() {
		return acceptBank;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“acceptBank”的值将赋给字段“acceptBank”
	 */
	public void setAcceptBank(String acceptBank) {
		this.acceptBank = acceptBank;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“payBank”的值
	 */
	public String getPayBank() {
		return payBank;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“payBank”的值将赋给字段“payBank”
	 */
	public void setPayBank(String payBank) {
		this.payBank = payBank;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“money”的值
	 */
	public String getMoney() {
		return money;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“money”的值将赋给字段“money”
	 */
	public void setMoney(String money) {
		this.money = money;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“currency”的值
	 */
	public String getCurrency() {
		return currency;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“currency”的值将赋给字段“currency”
	 */
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“cardNum”的值
	 */
	public String getCardNum() {
		return cardNum;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“cardNum”的值将赋给字段“cardNum”
	 */
	public void setCardNum(String cardNum) {
		this.cardNum = cardNum;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“authNum”的值
	 */
	public String getAuthNum() {
		return authNum;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“authNum”的值将赋给字段“authNum”
	 */
	public void setAuthNum(String authNum) {
		this.authNum = authNum;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“merchantNo”的值
	 */
	public String getMerchantNo() {
		return merchantNo;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“merchantNo”的值将赋给字段“merchantNo”
	 */
	public void setMerchantNo(String merchantNo) {
		this.merchantNo = merchantNo;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“salerName”的值
	 */
	public String getSalerName() {
		return salerName;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“salerName”的值将赋给字段“salerName”
	 */
	public void setSalerName(String salerName) {
		this.salerName = salerName;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“bizType”的值
	 */
	public String getBizType() {
		return bizType;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“bizType”的值将赋给字段“bizType”
	 */
	public void setBizType(String bizType) {
		this.bizType = bizType;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“tradeStatus”的值
	 */
	public String getTradeStatus() {
		return tradeStatus;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“tradeStatus”的值将赋给字段“tradeStatus”
	 */
	public void setTradeStatus(String tradeStatus) {
		this.tradeStatus = tradeStatus;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“payStatus”的值
	 */
	public String getPayStatus() {
		return payStatus;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“payStatus”的值将赋给字段“payStatus”
	 */
	public void setPayStatus(String payStatus) {
		this.payStatus = payStatus;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“remark”的值
	 */
	public String getRemark() {
		return remark;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“remark”的值将赋给字段“remark”
	 */
	public void setRemark(String remark) {
		this.remark = remark;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“refundStatus”的值
	 */
	public String getRefundStatus() {
		return refundStatus;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午4:20:15</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“refundStatus”的值将赋给字段“refundStatus”
	 */
	public void setRefundStatus(String refundStatus) {
		this.refundStatus = refundStatus;
	}
	
	/**  
	 * Title: TestVO.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	
}
