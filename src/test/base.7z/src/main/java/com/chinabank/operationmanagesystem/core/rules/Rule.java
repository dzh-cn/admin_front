/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-5-8</li>
 * <li>3、开发时间：上午11:51:34</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.rules</li>
 * <li>6、文件名称：BaseRule.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.rules;

import java.io.Serializable;

/**
 * <ul>
 * <li>1、开发日期：2014-5-8</li>
 * <li>2、开发时间：上午11:51:34</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：BaseRule</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class Rule implements Serializable{
	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：BaseRule.java</li>
	 * <li>3、字段含义：</li>
	 * </ul>
	 */
	private static final long serialVersionUID = 5024822571624745999L;
	/**  
	 * Title: BaseRule.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	private boolean required = false;
	private int min = -1;
	private int max = -1;
	private int minlength = -1;
	private int maxlength = -1;
	private boolean email = false;
	private boolean url = false;
	private boolean date = false;
	private boolean number = false;
	private int[] rangelength = null;
	private int[] range = null;
	private String accept = null;
	private String equalTo = null;
	private boolean digits = false;
	private String rule;
	private String message;
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“required”的值
	 */
	public boolean isRequired() {
		return required;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“required”的值将赋给字段“required”
	 */
	public void setRequired(boolean required) {
		this.required = required;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“min”的值
	 */
	public int getMin() {
		return min;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“min”的值将赋给字段“min”
	 */
	public void setMin(int min) {
		this.min = min;
	}
	public void setMin(String min) {
		this.min = Integer.valueOf(min);
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“max”的值
	 */
	public int getMax() {
		return max;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“max”的值将赋给字段“max”
	 */
	public void setMax(int max) {
		this.max = max;
	}
	public void setMax(String max) {
		this.max = Integer.valueOf(max);
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“minlength”的值
	 */
	public int getMinlength() {
		return minlength;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“minlength”的值将赋给字段“minlength”
	 */
	public void setMinlength(int minlength) {
		this.minlength = minlength;
	}
	public void setMinlength(String minlength) {
		this.minlength = Integer.valueOf(minlength);
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“maxlength”的值
	 */
	public int getMaxlength() {
		return maxlength;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“maxlength”的值将赋给字段“maxlength”
	 */
	public void setMaxlength(int maxlength) {
		this.maxlength = maxlength;
	}
	public void setMaxlength(String maxlength) {
		this.maxlength = Integer.valueOf(maxlength);
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“email”的值
	 */
	public boolean isEmail() {
		return email;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“email”的值将赋给字段“email”
	 */
	public void setEmail(boolean email) {
		this.email = email;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“url”的值
	 */
	public boolean isUrl() {
		return url;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“url”的值将赋给字段“url”
	 */
	public void setUrl(boolean url) {
		this.url = url;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“date”的值
	 */
	public boolean isDate() {
		return date;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“date”的值将赋给字段“date”
	 */
	public void setDate(boolean date) {
		this.date = date;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“number”的值
	 */
	public boolean isNumber() {
		return number;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“number”的值将赋给字段“number”
	 */
	public void setNumber(boolean number) {
		this.number = number;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“rangelength”的值
	 */
	public int[] getRangelength() {
		return rangelength;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“rangelength”的值将赋给字段“rangelength”
	 */
	public void setRangelength(int[] rangelength) {
		this.rangelength = rangelength;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“range”的值
	 */
	public int[] getRange() {
		return range;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“range”的值将赋给字段“range”
	 */
	public void setRange(int[] range) {
		this.range = range;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“accept”的值
	 */
	public String getAccept() {
		return accept;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“accept”的值将赋给字段“accept”
	 */
	public void setAccept(String accept) {
		this.accept = accept;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“equalTo”的值
	 */
	public String getEqualTo() {
		return equalTo;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“equalTo”的值将赋给字段“equalTo”
	 */
	public void setEqualTo(String equalTo) {
		this.equalTo = equalTo;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“digits”的值
	 */
	public boolean isDigits() {
		return digits;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-8</li>
	 * <li>2、开发时间：下午8:49:59</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“digits”的值将赋给字段“digits”
	 */
	public void setDigits(boolean digits) {
		this.digits = digits;
	}
	
	public void buildRule() {
		StringBuilder ruleSB = new StringBuilder();
		if(required) {
			ruleSB.append("required:true,");
		}
		if(-1 != min) {
			ruleSB.append("min: ").append(min).append(",");
		}
		if(-1 != max) {
			ruleSB.append("max: ").append(max).append(",");
		}
		if(-1 != minlength) {
			ruleSB.append("minlength: ").append(minlength).append(",");
		}
		if(-1 != maxlength) {
			ruleSB.append("maxlength: ").append(maxlength).append(",");
		}
		if(email) {
			ruleSB.append("email:true,");
		}
		if(url) {
			ruleSB.append("url:true,");
		}
		if(date) {
			ruleSB.append("date:true,");
		}
		if(number) {
			ruleSB.append("number:true,");
		}
		if(null != rangelength) {
			if(rangelength.length == 2) {
				ruleSB.append("rangelength:[").append(rangelength[0]).append(",").append(rangelength[1]).append("],");
			}
		}
		if(null != range) {
			if(range.length == 2) {
				ruleSB.append("range:[").append(range[0]).append(",").append(range[1]).append("],");
			}
		}
		if(null != accept) {
			ruleSB.append("accept:'").append(accept).append("',");
		}
		if(null != equalTo) {
			ruleSB.append("equalTo:'input[name=").append(equalTo).append("]',");
		}
		if(digits) {
			ruleSB.append("digits:true,");
		}
		String rule = ruleSB.toString();
		if(!"".equals(rule)) {
			rule.substring(rule.length() - 1, rule.length());
		}
		this.rule = rule;
	}
	
	public void buildMessage(String name) {
		StringBuilder messageSB = new StringBuilder();
		if(required) {
			messageSB.append("required:'${name}不能为空！',");
		}
		if(-1 != min) {
			messageSB.append("min: $.validator.format('${name}的数值必须大于{0}。'),");
		}
		if(-1 != max) {
			messageSB.append("max: $.validator.format('${name}的数值必须小于{0}。'),");
		}
		if(-1 != minlength) {
			messageSB.append("minlength: $.validator.format('${name}的长度不能小于{0}位。'),");
		}
		if(-1 != maxlength) {
			messageSB.append("maxlength: $.validator.format('${name}的长度不能大于{0}位。'),");
		}
		if(email) {
			messageSB.append("email:'${name}必须为电子邮箱格式！',");
		}
		if(url) {
			messageSB.append("url:'${name}必须为URL！',");
		}
		if(date) {
			messageSB.append("date:'${name}必须为日期格式！',");
		}
		if(number) {
			messageSB.append("number:'${name}必须是数字！',");
		}
		if(null != rangelength) {
			if(rangelength.length == 2) {
				messageSB.append("rangelength:$.validator.format('${name}的长度必须在{0}到{1}之间。'),");
			}
		}
		if(null != range) {
			if(range.length == 2) {
				messageSB.append("range:$.validator.format('${name}的数值必须在{0}到{1}之间。'),");
			}
		}
		if(null != accept) {
			messageSB.append("accept:'${name}可接受的类型为：").append(accept).append("。',");
		}
		if(null != equalTo) {
			messageSB.append("equalTo:'${name}必须与").append(equalTo).append("相同！',");
		}
		if(digits) {
			messageSB.append("digits:'${name}必须输入数字！',");
		}
		String message = messageSB.toString();
		if(!"".equals(message)) {
			message.substring(message.length() - 1, message.length());
		}
		message = message.replaceAll("\\$\\{name\\}", name);
		this.message = message;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-14</li>
	 * <li>2、开发时间：上午11:59:49</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“rule”的值
	 */
	public String getRule() {
		return rule;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-14</li>
	 * <li>2、开发时间：上午11:59:49</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“rule”的值将赋给字段“rule”
	 */
	public void setRule(String rule) {
		this.rule = rule;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-14</li>
	 * <li>2、开发时间：上午11:59:49</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“message”的值
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-14</li>
	 * <li>2、开发时间：上午11:59:49</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“message”的值将赋给字段“message”
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	
}
