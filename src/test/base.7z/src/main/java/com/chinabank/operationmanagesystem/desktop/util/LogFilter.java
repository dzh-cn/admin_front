/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-1-15</li>
 * <li>3、开发时间：下午3:03:48</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.desktop.util</li>
 * <li>6、文件名称：MyFilter.java</li>
 * </ul>
 *//*
package com.chinabank.operationmanagesystem.desktop.util;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import net.sf.json.JSONObject;

import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.WebApplicationContext;

import com.chinabank.log.bean.RequestAction;
import com.chinabank.log.core.bean.LogBean;
import com.chinabank.log.core.threadpool.ThreadPool;
import com.chinabank.log.core.util.LogConfig;
import com.wangyin.ssoclient.sso.model.Configuration;
import com.wangyin.ssoclient.sso.model.User;


*//**
 * <ul>
 * <li>1、开发日期：2014-1-15</li>
 * <li>2、开发时间：下午3:03:48</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：MyFilter</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 *//*
public class LogFilter implements Filter{

	*//**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2014-1-15</li>
	 * <li>2、开发时间：下午3:03:48</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 *//*
	public LogFilter() {
		// TODO Auto-generated constructor stub
	}
	*//**  
	 * Title: MyFilter.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 *//*

	*//**
	 * <ul>
	 * <li>1、开发日期：2014-1-15</li>
	 * <li>2、开发时间：下午3:04:04</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see javax.servlet.Filter#destroy()
	 *//*
	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		
	}

	*//**
	 * <ul>
	 * <li>1、开发日期：2014-1-15</li>
	 * <li>2、开发时间：下午3:04:04</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest, javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 *//*
	@Override
	public void doFilter(ServletRequest arg0, ServletResponse arg1,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) arg0;
		HttpServletResponse response = (HttpServletResponse) arg1;
		if(!LogConfig.logSwitch) {//如果没开日志服务
			chain.doFilter(request, response);
			return;
		}
		String servletPath = request.getServletPath();
		if(!isQuery(servletPath)) {
			ResponseWrapper wrapper = new ResponseWrapper(response);
			holdResponse(chain, request, response, wrapper);
		} else {
			sendWithoutReturn(chain, request, response);
		}
	}

	*//**
	 * <ul>
	 * <li>1、开发日期：2014-2-19</li>
	 * <li>2、开发时间：下午2:23:24</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、返回类型：String</li>
	 * <li>5、方法含义：</li>
	 * <li>6、方法说明：</li>
	 * </ul>
	 * @param chain
	 * @param request
	 * @param response
	 * @param wrapper
	 * @return
	 * @throws IOException
	 * @throws ServletException
	 *//*
	private void holdResponse(FilterChain chain, HttpServletRequest request,
			HttpServletResponse response, ResponseWrapper wrapper)
			throws IOException, ServletException {
		LogBean logBean = LogFilter.getLog(request);
		Date startTime = new Date();//记录开始时间
		chain.doFilter(request, wrapper);
		Date endTime = new Date();//结束时间
		String result = wrapper.getResult();//返回结果
		PrintWriter out = response.getWriter();
		out.write(result);// 向Servlet输出最终的结果
		logBean.setReqStartTime(startTime);
		logBean.setReqEndTime(endTime);
		logBean.setReturnContext(result);
		ThreadPool.log(logBean);
	}
	
	private void sendWithoutReturn(FilterChain chain, HttpServletRequest request,
			HttpServletResponse response) throws IOException, ServletException {
		LogBean logBean = LogFilter.getLog(request);
		Date startTime = new Date();//记录开始时间
		chain.doFilter(request, response);
		Date endTime = new Date();//结束时间
		logBean.setReqStartTime(startTime);
		logBean.setReqEndTime(endTime);
		logBean.setReturnContext("查询");
		ThreadPool.log(logBean);
	}

	*//**
	 * <ul>
	 * <li>1、开发日期：2014-1-15</li>
	 * <li>2、开发时间：下午3:04:04</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 *//*
	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub
		
	}
	
	public static boolean isQuery(String contextPath) {
		Pattern p = Pattern.compile("([^/]+)$");
		Matcher matcher = p.matcher(contextPath);
		if(matcher.find()) {
			String action = matcher.group();
			if(action.matches("^query.+")) {
				return true;
			}
		}
		return false;
	}
	
	private static LogBean getLog(HttpServletRequest request) {
		HttpSession session = request.getSession();
		Map<?, ?> map = request.getParameterMap();
		User user = (User)session.getAttribute(Configuration.userSession);
		String servletPath = request.getServletPath();
		RequestAction requestAction = LogFilter.parsePath(servletPath,request);
		
		LogBean logBean = new LogBean();
		logBean.setClientReqURL(servletPath);
		if(null != user) {
			logBean.setUserCode(user.getUsername());
			logBean.setUserName(user.getRealname());
		}
		logBean.setServerAddr(request.getLocalAddr());
		logBean.setClientAddr(request.getRemoteAddr());
		if(null != requestAction) {
			logBean.setReqClass(requestAction.getReqClass());
			logBean.setReqMethod(requestAction.getReqMethod());
		} else {
			//throw new Exception();
		}
		String str = JSONObject.fromObject(map).toString();
		logBean.setArgsContext(str);
		logBean.setReqOperateType("99");
		logBean.setFlag("");
		return logBean;
	}
	
	private static RequestAction parsePath(String servletPath,HttpServletRequest request) {
		String[] paths = servletPath.split("/");
		String project = "";
		String module = "";
		String action = "";
		if(paths.length == 4) {
			project = paths[1];
			module = paths[2];
			action = paths[3];
			String beanName =project+"_"+module;
			WebApplicationContext ac = ContextLoaderListener.getCurrentWebApplicationContext();
			if(ac.containsBean(beanName)) {
				Object object = ac.getBean(beanName);
				Class<?> clazz = object.getClass();
				String methodName = LogFilter.getMethodName(action);
				if(null != methodName) {
					return new RequestAction(clazz.getName(),methodName);
				}
			}
		} else if(paths.length == 5) {
			project = paths[2];
			module = paths[3];
			action = LogFilter.getAction(paths[4]);
			String url = ReadProperties.read(action+"_url", "/http/"+project+"/"+module+".properties");
			return new RequestAction(url,action);
		}
		return null;
	}
	
	private static String getMethodName(String actionName) {
		if(actionName.matches("[^.]+[.][^.]+")) {
			String action[] = actionName.split("\\.");
			return action[0] + toUpperCaseFirstOne(action[1]);
		} else {
			return null;
		}
	}
	
	private static String getAction(String actionName) {
		if(actionName.matches("[^.]+[.][^.]+")) {
			String action[] = actionName.split("\\.");
			return action[0];
		} else {
			return null;
		}
	}
	
	// 首字母转小写
	public static String toLowerCaseFirstOne(String s) {
		if (Character.isLowerCase(s.charAt(0))) {
			return s;
		} else {
			return (new StringBuilder()).append(Character.toLowerCase(s.charAt(0)))
					.append(s.substring(1)).toString();
		}
	}

	// 首字母转大写
	public static String toUpperCaseFirstOne(String s) {
		if (Character.isUpperCase(s.charAt(0))) {
			return s;
		} else {
			return (new StringBuilder())
					.append(Character.toUpperCase(s.charAt(0)))
					.append(s.substring(1)).toString();
		}
	}
}
*/