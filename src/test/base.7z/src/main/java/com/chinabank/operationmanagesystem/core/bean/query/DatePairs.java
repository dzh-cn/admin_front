/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-1-9</li>
 * <li>3、开发时间：下午4:18:34</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.bean.query</li>
 * <li>6、文件名称：DatePicker.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.bean.query;

import java.util.Date;

/**
 * <ul>
 * <li>1、开发日期：2014-1-9</li>
 * <li>2、开发时间：下午4:18:34</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：DatePicker</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class DatePairs extends QueryData {

	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：DatePicker.java</li>
	 * </ul>
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 时间区间
	 * @Default 7
	 */
	private int interval = 7;
	/**
	 * 开始日期属性名
	 * @Default "startTime"
	 */
	private String startName = "startTime";
	/**
	 * 结束日期属性名
	 * @Default "endTime"
	 */
	private String endName = "endTime";
	/**
	 * 开始日期
	 */
	private Date startTime = null;
	/**
	 * 结束日期
	 */
	private Date endTime = null;
	/**
	 * 日期差
	 * @Default 0
	 * 例如：30天前，可以设置timeDiff=-30
	 * 30天后，可以设置timeDiff=30
	 */
	private int timeDiff = 0;
	private boolean showTime = false;
	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2014-1-9</li>
	 * <li>2、开发时间：下午4:18:34</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 */
	public DatePairs() {
		// TODO Auto-generated constructor stub
	}
	
	public DatePairs(String label, String startName,
			String endName, Date startTime, Date endTime) {
		super(label, "");
		this.startName = startName;
		this.endName = endName;
		this.startTime = startTime;
		this.endTime = endTime;
	}

	public DatePairs(String label, String explain,
			String startName, String endName, Date startTime, Date endTime) {
		super(label, "", explain);
		this.startName = startName;
		this.endName = endName;
		this.startTime = startTime;
		this.endTime = endTime;
	}

	/**  
	 * Title: DatePicker.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */

	public String getStartName() {
		return startName;
	}

	public void setStartName(String startName) {
		this.startName = startName;
	}

	public String getEndName() {
		return endName;
	}

	public void setEndName(String endName) {
		this.endName = endName;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public int getInterval() {
		return interval;
	}

	public void setInterval(int interval) {
		this.interval = interval;
	}

	public int getTimeDiff() {
		return timeDiff;
	}

	public void setTimeDiff(int timeDiff) {
		this.timeDiff = timeDiff;
	}

	public boolean isShowTime() {
		return showTime;
	}

	public void setShowTime(boolean showTime) {
		this.showTime = showTime;
	}
	
}
