/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-1-17</li>
 * <li>3、开发时间：下午2:59:54</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.desktop.util</li>
 * <li>6、文件名称：MapUtil.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.desktop.util;

import java.util.Map;

/**
 * <ul>
 * <li>1、开发日期：2014-1-17</li>
 * <li>2、开发时间：下午2:59:54</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：MapUtil</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class MapUtil {

	
	Map<String,Object> paramsMap;
	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2014-1-17</li>
	 * <li>2、开发时间：下午2:59:54</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 */
	public MapUtil() {
	}
	
	public MapUtil(Map<String, Object> map) {
		super();
		this.paramsMap = map;
	}

	public Map<String,Object> getMap() {
		return paramsMap;
	}
	public void setMap(Map<String,Object> map) {
		this.paramsMap = map;
	}
	
	/**  
	 * Title: MapUtil.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	
	public Object get(String key) {
		return paramsMap.get(key);
	}
	
	public String getParameter(String key) {
		return ((String[])paramsMap.get(key))[0];
	}
	
	public String getString(String key) {
		return (String) paramsMap.get(key);
	}
	
	public Integer getInt(String key) {
		return Integer.parseInt((String) paramsMap.get(key));
	}
	
	public Long getLong(String key) {
		return Long.parseLong((String) paramsMap.get(key));
	}
	
	public Short getShort(String key) {
		return Short.parseShort((String) paramsMap.get(key));
	}
	public Double Double(String key) {
		return Double.parseDouble((String) paramsMap.get(key));
	}
	public Float getFloat(String key) {
		return Float.parseFloat((String) paramsMap.get(key));
	}
	
	public static Object get(Map<String,Object> map, String key) {
		return map.get(key);
	}
	
	public static String getParameter(Map<String,Object> map,String key) {
		return ((String[])map.get(key))[0];
	}
	
	public static String getString(Map<String,Object> map,String key) {
		return (String) map.get(key);
	}
	
	public static Integer getInt(Map<String,Object> map,String key) {
		return Integer.parseInt((String) map.get(key));
	}
	
	public static Long getLong(Map<String,Object> map,String key) {
		return Long.parseLong((String) map.get(key));
	}
	
	public static Short getShort(Map<String,Object> map,String key) {
		return Short.parseShort((String) map.get(key));
	}
	public static Double Double(Map<String,Object> map,String key) {
		return Double.parseDouble((String) map.get(key));
	}
	public static Float getFloat(Map<String,Object> map,String key) {
		return Float.parseFloat((String) map.get(key));
	}
}
