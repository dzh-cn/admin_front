/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-5-21</li>
 * <li>3、开发时间：下午3:32:16</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.listener</li>
 * <li>6、文件名称：UnzipListener.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.listener;

import java.io.File;
import java.net.MalformedURLException;
import java.util.Iterator;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.apache.catalina.loader.WebappClassLoader;
import org.apache.commons.io.FileUtils;

import com.chinabank.operationmanagesystem.core.util.WarUtils;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;

/**
 * <ul>
 * <li>1、开发日期：2014-5-21</li>
 * <li>2、开发时间：下午3:32:16</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：UnzipListener</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class UnzipListener implements ServletContextListener {
	private static final Logger logger = LoggerFactory.getLogger(UnzipListener.class);
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-21</li>
	 * <li>2、开发时间：下午3:32:16</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see javax.servlet.ServletContextListener#contextDestroyed(javax.servlet.ServletContextEvent)
	 */
	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-21</li>
	 * <li>2、开发时间：下午3:32:16</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see javax.servlet.ServletContextListener#contextInitialized(javax.servlet.ServletContextEvent)
	 */
	@Override
	public void contextInitialized(ServletContextEvent arg0) {
		WebappClassLoader wcl = (WebappClassLoader)Thread.currentThread().getContextClassLoader();
		logger.info("开始释放插件！");
		WarUtils.unzipPlugins("/opt/plugins/", "/opt/tomcat_operation-test/webapps/ROOT/");
		logger.info("插件释放完成！");
		String libDir = "/opt/plugins/jars/";
		Iterator<File> files = FileUtils.iterateFiles(new File(libDir),null, true);
		while(files.hasNext()) {
			File jarFile = files.next();
			try {
				wcl.addRepository(jarFile.toURI().toURL().toString());
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
		}
		/*WebappClassLoader loader = (WebappClassLoader)Thread.currentThread().getContextClassLoader();
		try {
			loader.stop();
		} catch (LifecycleException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			loader.start();
		} catch (LifecycleException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}*/
	}
	
	public static void main(String[] args) {
		System.out.println(System.getProperty("user.dir"));
	}
	/**  
	 * Title: UnzipListener.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
}
