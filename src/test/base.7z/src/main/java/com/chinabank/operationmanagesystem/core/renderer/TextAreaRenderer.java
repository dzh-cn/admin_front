/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-4-23</li>
 * <li>3、开发时间：下午4:33:29</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.renderer</li>
 * <li>6、文件名称：TextAreaRenderer.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.renderer;

import com.chinabank.operationmanagesystem.core.bean.form.TextArea;
import com.chinabank.operationmanagesystem.core.bean.form.renderer.FormRenderer;
import com.chinabank.operationmanagesystem.core.bean.query.QueryData;
import com.chinabank.operationmanagesystem.core.bean.query.ViewObject;
import com.chinabank.operationmanagesystem.core.util.FormUtil;

/**
 * <ul>
 * <li>1、开发日期：2014-4-23</li>
 * <li>2、开发时间：下午4:33:29</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：TextAreaRenderer</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class TextAreaRenderer implements FormRenderer {
	private static final String formTextAreaClass = "ft-normal iconrept";
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-23</li>
	 * <li>2、开发时间：下午4:33:29</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see com.chinabank.operationmanagesystem.core.bean.form.renderer.FormRenderer#renderForm(com.chinabank.operationmanagesystem.core.bean.query.QueryData)
	 */
	@Override
	public ViewObject renderForm(QueryData queryData) {
		TextArea textArea = (TextArea) queryData;
		StringBuilder html = new StringBuilder();
		StringBuilder ready = new StringBuilder();
		StringBuilder function = new StringBuilder();
		html.append(FormUtil.CR).append(FormUtil.INDENT_SIX).append("<label>").append(textArea.getLabel()).append("</label>");
		html.append(FormUtil.CR).append(FormUtil.INDENT_SIX).append("<textarea name='").append(textArea.getName()).append("' placeholder='").append(textArea.getPlaceholder()).append("' rows='").append(textArea.getRows()).append("' cols='' class='").append(formTextAreaClass).append("' style='width:").append(textArea.getWidth()).append("px;vertical-align:top;background-position:0 -200px;padding:2px 5px;border:1px solid #ccc;'></textarea>");
		return new ViewObject(html.toString(),function.toString(),ready.toString());
	}
	/**  
	 * Title: TextAreaRenderer.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
}
