/**
 * <p>项目名称：oms-0.0.5<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-7-10</li>
 * <li>3、开发时间：上午10:06:39</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.desktop.util</li>
 * <li>6、文件名称：JsonParser.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.desktop.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import net.sf.json.JSONArray;
import net.sf.json.JSONNull;
import net.sf.json.JSONObject;

/**
 * <ul>
 * <li>1、开发日期：2014-7-10</li>
 * <li>2、开发时间：上午10:06:39</li>
 * <li>3、作 者：wangjiaqi</li>
 * <li>4、类型名称：JsonParser</li>
 * <li>5、类型意图：</li>
 * </ul>
 * 
 */
public class JsonParser {
	/**
	 * Title: JsonParser.java Description: TODO(用一句话描述该文件做什么)
	 * 
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	public static List<Map<String, Object>> parseJSON2List(String jsonStr) {
		JSONArray jsonArr = JSONArray.fromObject(jsonStr);
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
		Iterator<JSONObject> it = jsonArr.iterator();
		while (it.hasNext()) {
			JSONObject json2 = it.next();
			list.add(parseJSON2Map(json2.toString()));
		}
		return list;
	}

	public static Map<String, Object> parseJSON2Map(String jsonStr) {
		Map<String, Object> map = new HashMap<String, Object>();
		// 最外层解析
		JSONObject json = JSONObject.fromObject(jsonStr);
		for (Object k : json.keySet()) {
			Object v = json.get(k);
			// 如果内层还是数组的话，继续解析
			if (v instanceof JSONArray) {
				List<Map<String, Object>> list = new ArrayList<Map<String, Object>>();
				Iterator<JSONObject> it = ((JSONArray) v).iterator();
				while (it.hasNext()) {
					JSONObject json2 = it.next();
					list.add(parseJSON2Map(json2.toString()));
				}
				map.put(k.toString(), list);
			} else if(v instanceof JSONObject) {
				Map<String,Object> objMap = new HashMap<String,Object>();
				for (Object object : ((JSONObject) v).entrySet()) {
					Entry<String,Object> entry = (Entry<String,Object>) object;
					if(entry.getValue() instanceof JSONArray) {
						objMap.put(entry.getKey(), parseJSON2List(entry.getValue().toString()));
					} else if(entry.getValue() instanceof JSONObject) {
						objMap.put(entry.getKey(), parseJSON2Map(entry.getValue().toString()));
					} else if(entry.getValue() instanceof JSONNull) {
						objMap.put(entry.getKey(),null);
					} else {
						objMap.put(entry.getKey(),entry.getValue());
					}
				}
				map.put(k.toString(), objMap);
			}
		}
		return map;
	}
}
