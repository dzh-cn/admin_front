/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-5-6</li>
 * <li>3、开发时间：下午1:14:54</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.adapter</li>
 * <li>6、文件名称：SingleAjaxActionAdapter.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.adapter;

import com.chinabank.operationmanagesystem.core.bean.Element;
import com.chinabank.operationmanagesystem.core.bean.grid.Action;
import com.chinabank.operationmanagesystem.core.bean.grid.ColModel;
import com.chinabank.operationmanagesystem.core.bean.grid.adapter.GridAdapter;
import com.chinabank.operationmanagesystem.core.enums.ActionTypeEnum;
import com.chinabank.operationmanagesystem.core.enums.ColumnTypeEnum;

/**
 * <ul>
 * <li>1、开发日期：2014-5-6</li>
 * <li>2、开发时间：下午1:14:54</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：SingleAjaxActionAdapter</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class DialogActionAdapter implements GridAdapter {

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-6</li>
	 * <li>2、开发时间：下午1:14:54</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see com.chinabank.operationmanagesystem.core.bean.grid.adapter.GridAdapter#adapter4Grid(com.chinabank.operationmanagesystem.core.bean.Element)
	 */
	@Override
	public ColModel adapter4Grid(Element element) {
		ColModel colModel = new ColModel();
		colModel.setHeader(element.getLabel());
		colModel.setName(element.getName());
		colModel.setColumnTypeEnum(ColumnTypeEnum.ACTION);
		Action action = new Action();
		action.setUrl(element.getValue());
		action.setActionTypeEnum(ActionTypeEnum.DIALOG);
		action.setExpression(TypeAdapterManager.replaceRule(element.getRule()));
		colModel.setAction(action);
		return colModel;
	}
	/**  
	 * Title: SingleAjaxActionAdapter.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
}
