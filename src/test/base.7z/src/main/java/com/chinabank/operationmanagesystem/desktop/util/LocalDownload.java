/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-1-1</li>
 * <li>3、开发时间：下午6:13:43</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.desktop.util</li>
 * <li>6、文件名称：LocalDownload.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.desktop.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;

import javax.servlet.http.HttpServletResponse;

import com.chinabank.operationmanagesystem.core.bean.UploadFile;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;

/**
 * <ul>
 * <li>1、开发日期：2014-1-1</li>
 * <li>2、开发时间：下午6:13:43</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：LocalDownload</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class LocalDownload implements WebFileUtil {

	private Logger logger = LoggerFactory.getLogger(LocalDownload.class);
	private String downloadPath = ConfigUtil.getString("sys.download.basePath");
	private String downloadPath20 = ConfigUtil.getString("sys.download20.basePath");
	private String downloadTemp20 = ConfigUtil.getString("sys.download20.temp");
	private String uploadPath = ConfigUtil.getString("sys.upload.basePath");
	private String uploadPath20 = ConfigUtil.getString("sys.upload20.basePath");
	private String uploadeTemp20 = ConfigUtil.getString("sys.upload20.temp");
	
	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2014-1-1</li>
	 * <li>2、开发时间：下午6:13:43</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 */
	public LocalDownload() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-1-1</li>
	 * <li>2、开发时间：下午6:13:43</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see com.chinabank.operationmanagesystem.desktop.util.DownloadUtil#upload(java.io.InputStream, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public boolean upload(InputStream local, UploadFile uploadfile,
			String uniqueID) {
		String filename = uploadfile.getName();
		String pathname = uploadfile.getPath();
		boolean flag = false;
		File file = null;
		FileOutputStream fos = null;
		BufferedOutputStream bos = null;
		BufferedInputStream bis = null;
		try {
			String dir = "";
			if("1.0".equals(uploadfile.getVersion())) {
				dir = uploadPath + pathname;
			} else if("2.0".equals(uploadfile.getVersion())) {
				if(uploadfile.isTemp()) {
					dir = uploadeTemp20 + pathname;
				} else {
					dir = uploadPath20 + pathname;
				}
			}
			file = new File(dir);
			file.mkdirs();
			String realPathname = dir + "/" + filename;
			uploadfile.setRealPathname(realPathname);
			file = new File(realPathname);
			if(!file.exists()) {
				file.createNewFile();
			} else {
				file.delete();
			}
			fos= new FileOutputStream(file);
			bos = new BufferedOutputStream(fos);
			bis = new BufferedInputStream(local);
			int n;
			byte[] buff = new byte[8192];
			while((n = bis.read(buff)) != -1) {
				bos.write(buff, 0, n);
			}
			bos.flush();
			flag = true;
		} catch (FileNotFoundException e) {
			logger.error("文件"+file == null?"为null":"为："+file.getAbsolutePath(),e.fillInStackTrace());
		} catch (IOException e) {
			logger.error("文件"+file == null?"为null":"为："+file.getAbsolutePath(),e.fillInStackTrace());
		} finally {
				try {
					if(null != bis) {
						bis.close();
					}
					if(null != local) {
						local.close();
					}
					if(null != bos) {
						bos.close();
					}
					if(null != fos) {
						fos.close();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
		return flag;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-1-1</li>
	 * <li>2、开发时间：下午6:13:43</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see com.chinabank.operationmanagesystem.desktop.util.DownloadUtil#download(java.io.OutputStream, java.lang.String, java.lang.String, java.lang.String)
	 */
	@Override
	public boolean download(OutputStream local,  UploadFile uploadfile, String uniqueID) {
		String pathname = uploadfile.getPath();
		String filename = uploadfile.getName();
		boolean flag = false;
		File file;
		FileInputStream fis = null;
		try {
			String realPathname = "";
			if("1.0".equals(uploadfile.getVersion())) {
				realPathname = downloadPath + pathname + "/" +filename;
			} else if("2.0".equals(uploadfile.getVersion())) {
				if(uploadfile.isTemp()) {
					realPathname = downloadTemp20 + pathname + "/" +filename;
				} else {
					realPathname = downloadPath20 + pathname + "/" +filename;
				}
			}
			uploadfile.setRealPathname(realPathname);
			File pluginDir = new File(downloadPath+"/plugin/");
			file = new File(realPathname);
			String absolutePath = file.getAbsolutePath();
			String pluginDirStr = pluginDir.getAbsolutePath();
			if(absolutePath.startsWith(pluginDirStr)) {
				logger.warn("下载地址非法！不允许下载plugin目录下任何文件！");
				return false;
			}
			if(file.exists()) {
				fis = new FileInputStream(file);
				int n;
				byte[] buff = new byte[102400];
				while((n = fis.read(buff)) != -1) {
					local.write(buff, 0, n);
				}
				local.flush();
				flag = true;
			} else {
				logger.info("ID:"+ uniqueID +",文件不存在！");
				return false;
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				if(null != local) {
					local.close();
				}
				if(null != fis) {
					fis.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
		return flag;
	}
	
	public boolean downloadByNginx(HttpServletResponse response, UploadFile uploadfile, String uniqueID) {
		String pathname = uploadfile.getPath();
		String filename = uploadfile.getName();
		File pluginDir = new File(downloadPath+"/plugin/");
		String redirect = "";
		String realPathname = "";
		if("1.0".equals(uploadfile.getVersion())) {
			realPathname = downloadPath + pathname + "/" +filename;
			redirect = "/download/tmp/" + pathname + "/" + filename;
		} else if("2.0".equals(uploadfile.getVersion())) {
			if(uploadfile.isTemp()) {
				redirect = "/download/temp/" + pathname + "/" + filename;
				realPathname = downloadTemp20 + pathname + "/" +filename;
			} else {
				redirect = "/download/oms/" + pathname + "/" + filename;
				realPathname = downloadPath20 + pathname + "/" +filename;
			}
		}
		try {
			redirect = new String(redirect.getBytes(),"ISO-8859-1");//转化nginx识别的iso-8859-1编码
		} catch (UnsupportedEncodingException e) {
			logger.error("文件名转iso-8859-1失败！"+redirect,e);
		}
		File file = new File(realPathname);
		String absolutePath = file.getAbsolutePath();
		String pluginDirStr = pluginDir.getAbsolutePath();
		if(absolutePath.startsWith(pluginDirStr)) {
			logger.warn("下载地址非法！不允许下载plugin目录下任何文件！");
			return false;
		}
		uploadfile.setRealPathname(realPathname);
		if(file.exists()) {
			response.setCharacterEncoding("utf-8");
			//response.setHeader("X-Accel-Limit-Rate", "102400");
			response.setHeader("X-Accel-Buffering", "yes");
			response.setHeader("X-Accel-Redirect", redirect);
			return true;
		} else {
			logger.info("ID:"+ uniqueID +",文件不存在！");
			return false;
		}
	}

}
