/**
 * <p>项目名称：oms-0.0.5<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-7-8</li>
 * <li>3、开发时间：下午4:12:17</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.sso</li>
 * <li>6、文件名称：JavaRegexURL.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.sso;

import java.io.Serializable;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;



/**
 * <ul>
 * <li>1、开发日期：2014-7-8</li>
 * <li>2、开发时间：下午4:12:17</li>
 * <li>3、作 者：wangjiaqi</li>
 * <li>4、类型名称：JavaRegexURL</li>
 * <li>5、类型意图：</li>
 * </ul>
 * 
 */
public class JavaRegexURL implements Serializable {
	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：JavaRegexURL.java</li>
	 * <li>3、字段含义：</li>
	 * </ul>
	 */
	private static final long serialVersionUID = 3999420680133995766L;
	/**
	 * Title: JavaRegexURL.java Description: TODO(用一句话描述该文件做什么)
	 * 
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	private Logger logger;
	private String url;
	private Pattern pattern;
	private boolean isValidPattern;

	public JavaRegexURL(String url, boolean buildRegex) {
		this.logger = LoggerFactory.getLogger(JavaRegexURL.class);

		this.isValidPattern = true;

		this.url = url;

		if (buildRegex)
			try {
				this.pattern = Pattern.compile(this.url);
			} catch (Exception ex) {
				this.isValidPattern = false;
				this.logger.error(ex.getMessage());
			}
	}

	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (super.getClass() != obj.getClass())
			return false;

		JavaRegexURL other = (JavaRegexURL) obj;
		if (!(other.isValidPattern)) {
			return false;
		}

		Matcher matcher = other.pattern.matcher(this.url);

		return (matcher.find());
	}

	public int hashCode() {
		return 0;
	}
}
