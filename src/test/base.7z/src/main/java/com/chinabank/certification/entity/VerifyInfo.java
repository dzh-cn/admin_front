/**
 * <p>项目名称：certification<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2013-12-31</li>
 * <li>3、开发时间：下午12:20:49</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.certification.entity</li>
 * <li>6、文件名称：Entity.java</li>
 * </ul>
 */
package com.chinabank.certification.entity;

import java.util.List;

import com.chinabank.cmcs.authentication.entity.Authentication;
import com.chinabank.cmcs.authentication.entity.Verify;

/**
 * <ul>
 * <li>1、开发日期：2013-12-31</li>
 * <li>2、开发时间：下午12:20:49</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：Entity</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class VerifyInfo {

	private List<Verify> list;
	private List<Authentication> listAuth;
	public List<Verify> getList() {
		return list;
	}

	public void setList(List<Verify> list) {
		this.list = list;
	}

	
	public List<Authentication> getListAuth() {
		return listAuth;
	}

	public void setListAuth(List<Authentication> listAuth) {
		this.listAuth = listAuth;
	}

	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2013-12-31</li>
	 * <li>2、开发时间：下午12:20:49</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 */
	public VerifyInfo() {
		// TODO Auto-generated constructor stub
	}
	/**  
	 * Title: Entity.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
}
