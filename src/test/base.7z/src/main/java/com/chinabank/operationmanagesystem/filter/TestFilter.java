/**
 * <p>项目名称：oms-0.0.7<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-8-14</li>
 * <li>3、开发时间：下午1:54:36</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.filter</li>
 * <li>6、文件名称：TestFilter.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * <ul>
 * <li>1、开发日期：2014-8-14</li>
 * <li>2、开发时间：下午1:54:36</li>
 * <li>3、作 者：wangjiaqi</li>
 * <li>4、类型名称：TestFilter</li>
 * <li>5、类型意图：</li>
 * </ul>
 * 
 */
public class TestFilter implements Filter {

	/**
	 * <ul>
	 * <li>1、开发日期：2014-8-14</li>
	 * <li>2、开发时间：下午1:54:37</li>
	 * <li>3、作 者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * 
	 * @see javax.servlet.Filter#destroy()
	 */
	@Override
	public void destroy() {
		// TODO Auto-generated method stub

	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-8-14</li>
	 * <li>2、开发时间：下午1:54:37</li>
	 * <li>3、作 者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * 
	 * @see javax.servlet.Filter#doFilter(javax.servlet.ServletRequest,
	 *      javax.servlet.ServletResponse, javax.servlet.FilterChain)
	 */
	@Override
	public void doFilter(ServletRequest arg0, ServletResponse arg1,
			FilterChain arg2) throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) arg0;
		HttpServletResponse response = (HttpServletResponse) arg1;
		String url = request.getRequestURI().toString();
		if ("XMLHttpRequest".equals(request.getHeader("X-Requested-With"))) {
			System.out.println("ajax请求");
			response.setStatus(600);
		} else {
			if(!url.equals("/operationmanagesystem/desktop/main.view")) {
				response.sendRedirect("/operationmanagesystem/desktop/main.view");
			} else {
				arg2.doFilter(request, response);
			}
		}
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-8-14</li>
	 * <li>2、开发时间：下午1:54:37</li>
	 * <li>3、作 者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * 
	 * @see javax.servlet.Filter#init(javax.servlet.FilterConfig)
	 */
	@Override
	public void init(FilterConfig arg0) throws ServletException {
		// TODO Auto-generated method stub

	}
	/**
	 * Title: TestFilter.java Description: TODO(用一句话描述该文件做什么)
	 * 
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
}
