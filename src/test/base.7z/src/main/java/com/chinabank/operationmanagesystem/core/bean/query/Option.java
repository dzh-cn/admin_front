/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-1-8</li>
 * <li>3、开发时间：下午1:54:16</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.bean.query</li>
 * <li>6、文件名称：Option.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.bean.query;

import java.io.Serializable;

/**
 * <ul>
 * <li>1、开发日期：2014-1-8</li>
 * <li>2、开发时间：下午1:54:16</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：Option</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class Option implements Serializable{

	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：Option.java</li>
	 * </ul>
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * option的value
	 */
	private String value="";
	/**
	 * option的text
	 */
	private String text="";
	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2014-1-8</li>
	 * <li>2、开发时间：下午1:54:16</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 */
	public Option() {
		// TODO Auto-generated constructor stub
	}
	
	public Option(String value, String text) {
		super();
		this.value = value;
		this.text = text;
	}


	/**  
	 * Title: Option.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getText() {
		return text;
	}
	public void setText(String text) {
		this.text = text;
	}
	
}
