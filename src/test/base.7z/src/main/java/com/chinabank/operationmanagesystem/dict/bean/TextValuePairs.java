/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-3-27</li>
 * <li>3、开发时间：下午2:50:58</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.dict.bean</li>
 * <li>6、文件名称：TextValuePairs.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.dict.bean;

import java.io.Serializable;

/**
 * <ul>
 * <li>1、开发日期：2014-3-27</li>
 * <li>2、开发时间：下午2:50:58</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：TextValuePairs</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class TextValuePairs implements Serializable{

	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：TextValuePairs.java</li>
	 * <li>3、字段含义：</li>
	 * </ul>
	 */
	private static final long serialVersionUID = -8075178712042604939L;
	private String text = "";
	private String value="";
	/**  
	 * Title: TextValuePairs.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	
	public TextValuePairs(){}
	
	public TextValuePairs(String text, String value) {
		super();
		this.text = text;
		this.value = value;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午2:51:34</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“text”的值
	 */
	public String getText() {
		return text;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午2:51:34</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“text”的值将赋给字段“text”
	 */
	public void setText(String text) {
		this.text = text;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午2:51:34</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“value”的值
	 */
	public String getValue() {
		return value;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-3-27</li>
	 * <li>2、开发时间：下午2:51:34</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“value”的值将赋给字段“value”
	 */
	public void setValue(String value) {
		this.value = value;
	}
	
}
