/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-1-14</li>
 * <li>3、开发时间：下午7:40:43</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.util</li>
 * <li>6、文件名称：ViewUtil.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.util;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.net.URL;
import java.util.HashMap;

import com.chinabank.operationmanagesystem.core.bean.view.View;
import com.chinabank.operationmanagesystem.core.exception.NoSuchRendererException;
import com.wangyin.admin.frame.template.Template;
import com.wangyin.admin.frame.template.imp.FreeMarkRender;

/**
 * <ul>
 * <li>1、开发日期：2014-1-14</li>
 * <li>2、开发时间：下午7:40:43</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：ViewUtil</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class ViewUtil {

	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2014-1-14</li>
	 * <li>2、开发时间：下午7:40:43</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 */
	public ViewUtil() {
		// TODO Auto-generated constructor stub
	}
	/**  
	 * Title: ViewUtil.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @throws FileNotFoundException 
	 * @throws NoSuchRendererException 
	 * @history:
	 */
	
	public static void getView(View view,String ftlPath) {
		URL url = Thread.currentThread().getContextClassLoader().getResource("");
		FreeMarkRender render=new FreeMarkRender();
		HashMap<String, Object> mm=new HashMap<String, Object>();
		mm.put("view", view);
		Template t=new Template();
		t.setPath(url.getPath()+"/template/template.ftl");
		System.out.println(render.renderAsString(t, mm));
		File file = new File(ftlPath);
		if(!file.exists()) {
			String parent = file.getParent();
			File dir = new File(parent);
			dir.mkdirs();
		}
		FileOutputStream fos = null;
		PrintStream p = null;
		try {
			fos = new FileOutputStream(ftlPath);
			p = new PrintStream(fos);
			p.print(render.renderAsString(t, mm));
			p.flush();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			if(null != p) {
				p.close();
			}
			if(null != fos) {
				try {
					fos.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		/*ViewObject viewObject = new ViewObject();
		StringBuilder html = new StringBuilder();
		StringBuilder ready = new StringBuilder();
		StringBuilder function = new StringBuilder();
		html.append("<div class='ui-nav fn-clear pl15'><div class='fn-left ft-14 pt5'><strong>"+ view.getTitle() +"</strong></div></div>");
		List<ViewData> viewDatas = view.getViewDatas();
		for (ViewData viewData : viewDatas) {
			if(viewData instanceof QueryForm) {
				QueryForm queryForm = (QueryForm) viewData;
				viewObject = QueryFormUtil.getQueryForm(queryForm);
			} else if(viewData instanceof Grid) {
				Grid grid = (Grid) viewData;
				viewObject = GridUtil.getGrid(grid);
			} else if(viewData instanceof Form) {
				Form form = (Form) viewData;
				viewObject = FormUtil.getForm(form);
			}
			html.append(viewObject.getHtml());
			ready.append(viewObject.getReady());
			function.append(viewObject.getFunction());
		}
		viewObject.setHtml(html.toString());
		viewObject.setReady(ready.toString());
		viewObject.setFunction(function.toString());
		return viewObject;*/
	}
	
}
