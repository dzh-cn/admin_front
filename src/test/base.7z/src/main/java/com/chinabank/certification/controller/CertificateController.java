/**
 * <p>项目名称：certification<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2013-12-30</li>
 * <li>3、开发时间：上午10:03:19</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.certification.controller</li>
 * <li>6、文件名称：CertificationController.java</li>
 * </ul>
 */
package com.chinabank.certification.controller;

import java.net.MalformedURLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import com.caucho.hessian.client.HessianProxyFactory;
import com.chinabank.certification.entity.VerifyInfo;
import com.chinabank.certification.vo.Info;
import com.chinabank.cmcs.authentication.biz.AuthenticationBiz;
import com.chinabank.cmcs.authentication.entity.Authentication;
import com.chinabank.cmcs.authentication.entity.Verify;
import com.chinabank.cmcs.authentication.enums.CertifyEnum;
import com.chinabank.cmcs.customer.biz.AuditHistoryBiz;
import com.chinabank.cmcs.customer.biz.CompanyBiz;
import com.chinabank.cmcs.customer.biz.CustomerBiz;
import com.chinabank.cmcs.customer.biz.FileBiz;
import com.chinabank.cmcs.customer.biz.SettleAccountBiz;
import com.chinabank.cmcs.customer.biz.ShareholderBiz;
import com.chinabank.cmcs.customer.biz.SignBiz;
import com.chinabank.cmcs.customer.entity.AuditHistory;
import com.chinabank.cmcs.customer.entity.Certificate;
import com.chinabank.cmcs.customer.entity.CertificateFile;
import com.chinabank.cmcs.customer.entity.CertificateR;
import com.chinabank.cmcs.customer.entity.Company;
import com.chinabank.cmcs.customer.entity.Customer;
import com.chinabank.cmcs.customer.entity.SettleAccount;
import com.chinabank.cmcs.customer.entity.Shareholder;
import com.chinabank.cmcs.customer.enums.CustomerEnum;
import com.chinabank.cmcs.customer.enums.CustomerTypeEnum;
import com.chinabank.cmcs.customer.enums.ShareholderEnum;
import com.chinabank.operationmanagesystem.core.bean.UploadFile;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.utils.GsonUtil;
import com.wangyin.ssoclient.sso.model.User;

/**
 * <ul>
 * <li>1、开发日期：2013-12-30</li>
 * <li>2、开发时间：上午10:03:19</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：CertificationController</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class CertificateController {

	private static final Logger logger = LoggerFactory.getLogger(CertificateController.class);
	String tempry_home;
	public void setTempry_home(String tempry_home) {
		this.tempry_home = tempry_home;
	}
	HessianProxyFactory hessianProxyFactory;
	SignBiz signBiz;
	FileBiz fileBiz;
	CompanyBiz companyBiz;
	ShareholderBiz shareholderBiz;
	CustomerBiz customerBiz;
	SettleAccountBiz settleAccountBiz;
	AuthenticationBiz authenticationBiz;
	AuditHistoryBiz auditHistoryBiz;
	String hessianUrl;
	public CertificateController() {}
	
	public void setHessianUrl(String hessianUrl) {
		this.hessianUrl = hessianUrl;
		logger.info("实名认证接口HessianURL"+hessianUrl);
		hessianProxyFactory = new HessianProxyFactory();
		try {
			signBiz = (SignBiz) hessianProxyFactory.create(SignBiz.class, hessianUrl+"sign.hs");
			fileBiz = (FileBiz)hessianProxyFactory.create(FileBiz.class, hessianUrl+"file.hs");
			companyBiz = (CompanyBiz)hessianProxyFactory.create(CompanyBiz.class, hessianUrl+"company.hs");
			shareholderBiz = (ShareholderBiz)hessianProxyFactory.create(ShareholderBiz.class, hessianUrl+"shareholder.hs");
			customerBiz = (CustomerBiz)hessianProxyFactory.create(CustomerBiz.class, hessianUrl+"customer.hs");
			settleAccountBiz = (SettleAccountBiz)hessianProxyFactory.create(SettleAccountBiz.class, hessianUrl+"settleAccount.hs");
			authenticationBiz = (AuthenticationBiz) hessianProxyFactory.create(AuthenticationBiz.class, hessianUrl+"authentication.hs");
			auditHistoryBiz = (AuditHistoryBiz) hessianProxyFactory.create(AuditHistoryBiz.class, hessianUrl+"auditHistory.hs");
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
	}



	/**  
	 * Title: CertificationController.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	
	public Map<String,Object> certificateView(Map<String,Object> params,User user) {
		Map<String,Object> result = new HashMap<String,Object>();
		if(null != user) {
			boolean isShow = user.getUrlCollectionObject().invoke("/certification/certificate/verify.biz");
			boolean isPrivilege = user.getUrlCollectionObject().invoke("/certification/certificate/privilegeVerify.biz");
			result.put("isShow", isShow);
			result.put("isPrivilege", isPrivilege);
		}
		/*ManageInfoService mis = new ManageInfoService();
		List<ManagerInfoDataEntity> list=mis.queryManagerOfDictId("HANGYE");
		result.put("list", list);*/
		return result;
	}
	
	public Map<String,Object> queryCertificateBiz(Map<String,Object> params) {
		Map<String,Object> result = new HashMap<String,Object>();
		List<Info> list = new ArrayList<Info>();
		Map<String,Object> paraMap = new HashMap<String,Object>();
		paraMap.put("start", params.get("start"));//分页起始条数
		paraMap.put("limit", params.get("limit"));//页容量
		paraMap.put("companyName", params.get("companyName"));//公司名称（商户名称），为空查询所有
		paraMap.put("customer", params.get("customer"));
		paraMap.put("customerType", params.get("customerType"));//商户类型，为空查询全部
		paraMap.put("status", params.get("status"));//商户状态，为空查询全部
		Map<String, Object> map = customerBiz.loadAllInfo(paraMap);
		List<Map<String,Object>> objectList = (List<Map<String,Object>>) map.get("resultList");
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		for (Map<String,Object> object : objectList) {
			AuditHistory auditHistory = (AuditHistory) object.get("auditHistory");
			Company company = (Company) object.get("company");
			Customer customer = (Customer) object.get("customer");
			Shareholder corporater = (Shareholder) object.get("corporater");
			/*Shareholder shareholder = (Shareholder) object.get("shareholder");
			SettleAccount settleAccount = (SettleAccount) object.get("SettleAccount");*/
			Info info = new Info();
			if(null != customer) {
				info.setCustomer(customer.getCustomer());
				info.setRegisterDate(sdf.format(customer.getCreate()));
				info.setPhone(customer.getLinkPhone());
				info.setEmail(customer.getLinMail());
				info.setDomain(customer.getSiteUrl());
				info.setType(CustomerTypeEnum.getBycode(customer.getCustomerType()).getDesc());
				info.setIndustry(customer.getIndustryName());
				info.setLevel("实名认证");
				info.setSource(customer.getOriginName());
				info.setStatus(CustomerEnum.getBycode(customer.getStatus()).getDesc());
				
				//new
				if(null != auditHistory) {
					if(null != auditHistory.getCreate()) {
						info.setSubmitDate(sdf.format(auditHistory.getCreate()));
					}
					if(null != auditHistory.getAuditCount()) {
						info.setCount(String.valueOf(auditHistory.getAuditCount()));
					}
					if(null != auditHistory.getModify()) {
						info.setAudiDate(sdf.format(auditHistory.getModify()));//审核时间
					}
					info.setOperator(auditHistory.getOperatorCode());
				}
			}
			if(null != company) {
				info.setCustomerName(company.getCompanyName());
			}
			if(null != corporater) {
				info.setLegalName(corporater.getName());
			}
			list.add(info);
		}
/*		Info info = new Info();
		info.setCustomer("22315664");
		info.setCustomerName("网银在线");
		info.setDomain("http://www.wangyin.com");
		info.setEmail("wangyin@wangyin.com");
		info.setIndustry("金融");
		info.setLegalName("张三");
		info.setLevel("实名认证");
		info.setPhone("188888888888");
		info.setRegisterDate("2013-12-30");
		info.setSource("POP商户");
		info.setStatus("审核完成");
		info.setType("企业");
		list.add(info);*/
		result.put("rows", list);
		result.put("total", map.get("total"));
		return result;
	}
	
	public Map<String,Object> verifyView(Map<String,String> params) {
		Map<String,Object> result = new HashMap<String,Object>();
		String customerID = params.get("customer");
		logger.info("认证页面开始："+customerID);
		result.put("customerID", customerID);
		result.put("type", params.get("type"));
		CertificateR businessCertificateR = this.getFile(customerID, "0002", "00020001");
		CertificateR orgCertificateR = this.getFile(customerID, "0003", "00030001");
		CertificateR legalIdcardFront = this.getFile(customerID, "0004", "00040001");
		CertificateR legalIdcardBack = this.getFile(customerID, "0004", "00040002");
		CertificateR shareIdcardFront = this.getFile(customerID, "0005", "00050001");
		CertificateR shareIdcardBack = this.getFile(customerID, "0005", "00050002");
		CertificateR taxCertificateR = this.getFile(customerID, "0007", "00070001");
		
		CertificateR B_businessCertificateR = this.getFile(customerID, "0002", "11121111");
		CertificateR B_orgCertificateR = this.getFile(customerID, "0003", "11131111");
		CertificateR B_legalIdcardFront = this.getFile(customerID, "0004", "11141111");
		CertificateR B_legalIdcardBack = this.getFile(customerID, "0004", "11141112");
		CertificateR B_shareIdcardFront = this.getFile(customerID, "0005", "11151111");
		CertificateR B_shareIdcardBack = this.getFile(customerID, "0005", "11151112");
		CertificateR B_taxCertificateR = this.getFile(customerID, "0007", "11171111");
		
		result.put("B_business", B_businessCertificateR);
		result.put("B_org", B_orgCertificateR);
		result.put("B_legalfront", B_legalIdcardFront);
		result.put("B_legalback", B_legalIdcardBack);
		result.put("B_sharefront", B_shareIdcardFront);
		result.put("B_shareback", B_shareIdcardBack);
		result.put("B_tax", B_taxCertificateR);
		
		CertificateR example = new CertificateR();
		example.setFileName("example");
		example.setConentType(".gif");
		if(null == businessCertificateR) {
			businessCertificateR = example;
		} else {
			logger.info(businessCertificateR.toString());
		}
		if(null == orgCertificateR) {
			orgCertificateR = example;
		} else {
			logger.info(orgCertificateR.toString());
		}
		if(null == legalIdcardFront) {
			legalIdcardFront = example;
		} else {
			logger.info(legalIdcardFront.toString());
		}
		if(null == legalIdcardBack) {
			legalIdcardBack = example;
		} else {
			logger.info(legalIdcardBack.toString());
		}
		if(null == shareIdcardFront) {
			shareIdcardFront = example;
		} else {
			logger.info(shareIdcardFront.toString());
		}
		if(null == shareIdcardBack) {
			shareIdcardBack = example;
		} else {
			logger.info(shareIdcardBack.toString());
		}
		if(null == taxCertificateR) {
			taxCertificateR = example;
		} else {
			logger.info(taxCertificateR.toString());
		}
		result.put("business", businessCertificateR);
		result.put("org", orgCertificateR);
		result.put("legalfront", legalIdcardFront);
		result.put("legalback", legalIdcardBack);
		result.put("sharefront", shareIdcardFront);
		result.put("shareback", shareIdcardBack);
		result.put("tax", taxCertificateR);
		
		logger.info("result:"+GsonUtil.getInstance().toJson(result));
		
		//AuditHistory auditHistory = auditHistoryBiz.load(customerID);
		//目前没用到
		Customer customer = customerBiz.loadByCondition(customerID, null);
		result.put("customer", customer);
		Company company = companyBiz.loadByCondition(customerID);
		result.put("company", company);
		SettleAccount settleAccount = settleAccountBiz.loadByCondition(customerID);
		result.put("account", settleAccount);
		Shareholder legal = shareholderBiz.loadByCondition(customerID, ShareholderEnum.CORPORATION.getCode());
		result.put("legal", legal);
		Shareholder share = shareholderBiz.loadByCondition(customerID, ShareholderEnum.SHAREHOLDER.getCode());
		result.put("share", share);
		String failStr = null;
		try {
			failStr = "[";
			failStr += authenticationBiz.getFailAuditResult(customerID, null, null);
			failStr += "]";
			result.put("listVerify", failStr);
		} catch (Exception e) {
			e.printStackTrace();
		}
		if(logger.isDebugEnabled()) {
			logger.debug(GsonUtil.getInstance().toJson(result));
		}
/*		if(null != failStr) {
			JSONArray jsonArray = JSONArray.fromObject(failStr);
			List<Verify> listVerify = JSONArray.toList(jsonArray, Verify.class);
			result.put("listVerify", listVerify);
		}*/
		return result;
	}
	
	public UploadFile verifyDownload(Map<String,String> map) {
		String filename = map.get("filename");
		String pathname = tempry_home + filename;
		UploadFile uploadfile = new UploadFile();
		uploadfile.setPathname(pathname);
		return uploadfile;
	}
	
	public CertificateR getFile(String customer,String qualify,String qualifySubtype) {
		CertificateFile certificateFile = new CertificateFile();
		Certificate certificate = new Certificate();
		List<CertificateR> listCertificateR = new ArrayList<CertificateR>();
		CertificateR certificateR = new CertificateR();
		certificate.setCustomer(customer);
		certificate.setQualify(qualify);
		certificateR.setQualifySubtype(qualifySubtype);
		listCertificateR.add(certificateR);
		certificateFile.setCertificate(certificate);
		certificateFile.setListCertificateR(listCertificateR);
		CertificateR resultCertificateR = fileBiz.getFile(certificateFile);
		return resultCertificateR;
	}
	
	public Map<String,Object> verifyBiz(VerifyInfo verifyInfo,Map<String,String> map,User user) {
		boolean flag = true;
		String customerID = map.get("customer");
		Map<String,Object> result = new HashMap<String,Object>();
		Customer customer = customerBiz.loadByCondition(customerID, null);
		if(!CustomerEnum.WAITAUDIT.getCode().equals(customer.getStatus())) {
			if(null != user) {
				if(!user.getUrlCollectionObject().invoke("/certification/certificate/privilegeVerify.biz")) {
					result.put("result", false);
					result.put("message", "只有“待审核”状态的商户才能被审核！");
					return result;
				} else {
					if(CustomerEnum.NOTSUBMIT.getCode().equals(customer.getStatus())) {
						result.put("result", false);
						result.put("message", "“新建”状态的商户不能被审核！");
						return result;
					}
				}
			} else {
				result.put("result", false);
				result.put("message", "只有“待审核”状态的商户才能被审核！");
				return result;
			}
		}
		List<Verify> list = verifyInfo.getList();
		List<Verify> listNotPass = new ArrayList<Verify>();
		for (Verify verify : list) {
			if(null == verify.getStatus()) {
				listNotPass.add(verify);
			}
		}
		
		List<Authentication> listAuth = verifyInfo.getListAuth();
		for (Authentication authentication : listAuth) {
			authentication.setCustomer(customerID);
			String message = authentication.getMessage();
			if(authentication.getStatus().equals("on")) {
				authentication.setStatus(CertifyEnum.SUCCESS.getCode());
				message += "正确";
			} else {
				authentication.setStatus(CertifyEnum.FAIL.getCode());
				message += "错误";
			}
			authentication.setMessage(message);
		}
		Map<String,Object> operator = new HashMap<String,Object>();
		if(null != user) {
			operator.put("operator", user.getUsername());
		} else {
			flag = false;
			result.put("result", flag);
			result.put("message", "审核失败，请先登陆运营管理平台！");
			return result;
		}
		try {
			authenticationBiz.updateByAudit(listAuth, customerID, null, listNotPass, operator);
		} catch (Exception e) {
			flag = false;
			logger.error("调用认证接口失败",e.fillInStackTrace());
		}
		
		result.put("result", flag);
		result.put("message", "审核失败，请重试。如多次尝试无效，请记录当前时间并联系相关人员处理！");
		return result;
	}
	
}
