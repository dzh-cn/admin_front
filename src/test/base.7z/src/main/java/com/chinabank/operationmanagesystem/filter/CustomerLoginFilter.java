package com.chinabank.operationmanagesystem.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONObject;

import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.common.enums.ResponseMessage;
import com.wangyin.ssoclient.sso.model.Configuration;
import com.wangyin.ssoclient.sso.model.User;

/**
 * 定制登录过滤器，区别view和biz请求
 * @author dongzhihua
 *
 */
public class CustomerLoginFilter extends com.wangyin.ssoclient.sso.filter.LoginFilter {

	@Override
	public void doFilter(ServletRequest a1, ServletResponse a2,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) a1;
		if(UserLoginOnlyFilter.excludeUriRegex != null && request.getRequestURI().matches(UserLoginOnlyFilter.excludeUriRegex)) {
			chain.doFilter(a1, a2);
		} else {
			User user = (User)request.getSession().getAttribute(Configuration.userSession);
			if(request.getParameter("ticket") == null && user == null && UserLoginOnlyFilter.isJson(request)) {
				HttpServletResponse response = (HttpServletResponse) a2;
				Page<Object> page = new Page<Object>();
				page.setResponseMessage(ResponseMessage.BUSINESS_EXCEPTION);
				page.setMessage("会话超时，请重新登录!(Session timeout!)");
				response.getWriter().write(JSONObject.fromObject(page).toString());
				return;
			}

			super.doFilter(a1, a2, chain);
		}
	}
}
