/** 
 * Copyright: Copyright (c)2011
 * Company: 网银在线(ChinaPay) 
 */
package com.chinabank.operationmanagesystem.desktop.bean;

import java.io.Serializable;
import java.util.List;

/**  
 * Title: MenuBean.java
 * Description: TODO(用一句话描述该文件做什么)
 * @author: wywangjiaqi 
 * @version V1.0
 * @history:
 */

public class MenuBean implements Serializable{
	String id;
	String index1;
	String index2;
	String index3;
	String name;
	String url;
	String hidden;
	String single;
	List<MenuBean> list;
	/**    
	 * serialVersionUID:TODO（用一句话描述这个变量表示什么）    
	 */    
	private static final long serialVersionUID = 1L;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public String getHidden() {
		return hidden;
	}

	public void setHidden(String hidden) {
		this.hidden = hidden;
	}

	public String getSingle() {
		return single;
	}

	public void setSingle(String single) {
		this.single = single;
	}

	public List<MenuBean> getList() {
		return list;
	}

	public void setList(List<MenuBean> list) {
		this.list = list;
	}

	public String getIndex1() {
		return index1;
	}

	public void setIndex1(String index1) {
		this.index1 = index1;
	}

	public String getIndex2() {
		return index2;
	}

	public void setIndex2(String index2) {
		this.index2 = index2;
	}

	public String getIndex3() {
		return index3;
	}

	public void setIndex3(String index3) {
		this.index3 = index3;
	}

	/**    
	 * 创建一个新的实例 MenuBean.    
	 *        
	 */
	public MenuBean() {
		// TODO Auto-generated constructor stub
	}
	/**  
	 * Title: MenuBean.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wywangjiaqi 
	 * @version V1.0
	 * @history:
	 */
}
