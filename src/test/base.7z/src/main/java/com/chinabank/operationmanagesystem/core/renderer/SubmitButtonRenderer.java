/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-4-8</li>
 * <li>3、开发时间：上午11:08:21</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.renderer</li>
 * <li>6、文件名称：SubmitButtonRenderer.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.renderer;

import com.chinabank.operationmanagesystem.core.bean.form.renderer.FormRenderer;
import com.chinabank.operationmanagesystem.core.bean.query.QueryData;
import com.chinabank.operationmanagesystem.core.bean.query.SubmitButton;
import com.chinabank.operationmanagesystem.core.bean.query.ViewObject;
import com.chinabank.operationmanagesystem.core.bean.query.renderer.QueryRenderer;
import com.chinabank.operationmanagesystem.core.util.GridUtil;

/**
 * <ul>
 * <li>1、开发日期：2014-4-8</li>
 * <li>2、开发时间：上午11:08:21</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：SubmitButtonRenderer</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class SubmitButtonRenderer implements FormRenderer,QueryRenderer {
	private static final String formSearchButtonClass = "iconrept btn-large ml20";
	private static final String FORM_FormButtonReady = "$('#button${id}').click(function() {" +
															"$('form').attr('action','${url}');" +
															"$('form').submit();"+
														"});";
	private static final String FORM_AjaxButtonReady = "$('#button${id}').click(function() {" +
															"doAjax4Form2Jump('${url}','${back}',$('form'));" +
														"});";
	private static final String FORM_JumpButtonReady = "$('#button${id}').click(function() {" +
															"window.location = '${url}';" +
														"});";
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-8</li>
	 * <li>2、开发时间：上午11:08:21</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see com.chinabank.operationmanagesystem.core.bean.form.renderer.FormRenderer#renderForm(com.chinabank.operationmanagesystem.core.bean.query.QueryData)
	 */
	@Override
	public ViewObject renderForm(QueryData queryData) {
		SubmitButton submitButton = (SubmitButton) queryData;
		StringBuilder html = new StringBuilder();
		StringBuilder ready = new StringBuilder();
		html.append("<span id='button${id}' class='").append(formSearchButtonClass).append("'>").append(submitButton.getLabel()).append("</span>");
		String temp = "";
		switch(submitButton.getButtonEnum()) {
		case FORM:
			/*temp = GridUtil.filterDollarStr(FORM_FormButtonReady);*/
			temp = FORM_FormButtonReady;
			ready.append(temp.replaceAll("\\$\\{url\\}", submitButton.getUrl()));
			break;
		case AJAX:
			/*temp = GridUtil.filterDollarStr(FORM_AjaxButtonReady);*/
			temp = FORM_AjaxButtonReady;
			ready.append(temp.replaceAll("\\$\\{url\\}", submitButton.getUrl()).replaceAll("\\$\\{back\\}", submitButton.getBack()));
			break;
		case JUMP:
			/*temp = GridUtil.filterDollarStr(FORM_JumpButtonReady);*/
			temp = FORM_JumpButtonReady;
			ready.append(temp.replaceAll("\\$\\{url\\}", submitButton.getBack()));
			break;
		default:
			break;
		}
		return new ViewObject(html.toString(),"",ready.toString());
	}
	/**  
	 * Title: SubmitButtonRenderer.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-29</li>
	 * <li>2、开发时间：下午5:33:21</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see com.chinabank.operationmanagesystem.core.bean.query.renderer.QueryRenderer#renderQuery(com.chinabank.operationmanagesystem.core.bean.query.QueryData)
	 */
	@Override
	public ViewObject renderQuery(QueryData queryData) {
		SubmitButton submitButton = (SubmitButton) queryData;
		String buttonHtml = "<label> </label><span id='query' class='iconrept btn ml3'><span class='icon icon-ss mr5'></span>"+ submitButton.getLabel() +"</span>";
		return new ViewObject(buttonHtml.toString(),"","");
	}
}
