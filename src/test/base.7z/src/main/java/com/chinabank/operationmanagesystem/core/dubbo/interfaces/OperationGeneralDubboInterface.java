package com.chinabank.operationmanagesystem.core.dubbo.interfaces;
/**
 * <p>项目名称：js<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-6-24</li>
 * <li>3、开发时间：下午6:04:45</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.wangyin.operation.dubbo.interfaces</li>
 * <li>6、文件名称：DubboInterface.java</li>
 * </ul>
 */
import java.util.Map;

import com.chinabank.operationmanagesystem.core.bean.ModelAndView;
import com.chinabank.operationmanagesystem.core.bean.UploadFile;
import com.chinabank.operationmanagesystem.core.bean.UserModel;
import com.chinabank.operationmanagesystem.desktop.bean.UploadObject;

/**
 * <ul>
 * <li>1、开发日期：2014-6-24</li>
 * <li>2、开发时间：下午6:04:45</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：DubboInterface</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public interface OperationGeneralDubboInterface {
	public ModelAndView view(Map<String,Object> map, UserModel userModel, String from);
	
	public String biz(Map<String,Object> map, UserModel userModel, String from);
	
	public UploadObject upload(UploadObject uploadObject, UserModel userModel, String from);
	
	public String callback(UploadObject uploadObject, UserModel userModel, String from);
	
	public UploadFile download(Map<String,Object> map, UserModel userModel, String from);
}
