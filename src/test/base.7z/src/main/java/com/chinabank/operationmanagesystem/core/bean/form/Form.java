/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-4-8</li>
 * <li>3、开发时间：上午10:40:40</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.bean.form</li>
 * <li>6、文件名称：Form.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.bean.form;

import java.util.List;

import com.chinabank.operationmanagesystem.core.bean.query.QueryData;
import com.chinabank.operationmanagesystem.core.bean.view.ViewData;
import com.chinabank.operationmanagesystem.core.enums.FormTypeEnum;

/**
 * <ul>
 * <li>1、开发日期：2014-4-8</li>
 * <li>2、开发时间：上午10:40:40</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：Form</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class Form extends ViewData {

	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：Form.java</li>
	 * <li>3、字段含义：</li>
	 * </ul>
	 */
	private static final long serialVersionUID = -3683546853217682903L;
	/**
	 * 表单url
	 */
	private String url;
	/**
	 * 表单区每行显示的查询条件数量
	 * @Default 3
	 */
	private int numPerLine = 2;
	/**
	 * 表单元素
	 */
	private List<QueryData> queryDatas;
	private FormTypeEnum formTypeEnum = FormTypeEnum.FORM;
	/**  
	 * Title: Form.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-8</li>
	 * <li>2、开发时间：上午10:42:00</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“url”的值
	 */
	public String getUrl() {
		return url;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-8</li>
	 * <li>2、开发时间：上午10:42:00</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“url”的值将赋给字段“url”
	 */
	public void setUrl(String url) {
		this.url = url;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-8</li>
	 * <li>2、开发时间：上午10:42:00</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“numPerLine”的值
	 */
	public int getNumPerLine() {
		return numPerLine;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-8</li>
	 * <li>2、开发时间：上午10:42:00</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“numPerLine”的值将赋给字段“numPerLine”
	 */
	public void setNumPerLine(int numPerLine) {
		this.numPerLine = numPerLine;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-8</li>
	 * <li>2、开发时间：上午10:42:00</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“queryDatas”的值
	 */
	public List<QueryData> getQueryDatas() {
		return queryDatas;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-8</li>
	 * <li>2、开发时间：上午10:42:00</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“queryDatas”的值将赋给字段“queryDatas”
	 */
	public void setQueryDatas(List<QueryData> queryDatas) {
		this.queryDatas = queryDatas;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-9</li>
	 * <li>2、开发时间：下午6:29:47</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“formTypeEnum”的值
	 */
	public FormTypeEnum getFormTypeEnum() {
		return formTypeEnum;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-9</li>
	 * <li>2、开发时间：下午6:29:47</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“formTypeEnum”的值将赋给字段“formTypeEnum”
	 */
	public void setFormTypeEnum(FormTypeEnum formTypeEnum) {
		this.formTypeEnum = formTypeEnum;
	}
	
	
}
