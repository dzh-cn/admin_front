package com.chinabank.operationmanagesystem.filter;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.jboss.netty.util.internal.ConcurrentHashMap;

import com.chinabank.operationmanagesystem.desktop.util.ConfigUtil;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.common.beans.Page;
import com.wangyin.operation.common.enums.ResponseMessage;
import com.wangyin.ssoclient.json.JSONObject;
import com.wangyin.ssoclient.sso.common.Exception.SSOException;
import com.wangyin.ssoclient.sso.listener.SsoSessionListener;
import com.wangyin.ssoclient.sso.model.Configuration;
import com.wangyin.ssoclient.sso.model.User;
import com.wangyin.ssoclient.sso.util.HttpClient;

/**
 * 单个账号登录限制拦截
 * @author dongzhihua
 *
 */
public class UserLoginOnlyFilter implements Filter {

	/**
	 * userName:sessionId
	 */
	static Map<String, String> userMap = new ConcurrentHashMap<String, String>();
	static Set<String> sessionHistory = new HashSet<String>();
	static String excludeUriRegex = null; //"\\S+((error.view)|(\\.css)|(\\.ico)|(\\.js)|(\\.gif))";
	static boolean needLoginOnlylimit = false;

	private static Logger logger = LoggerFactory.getLogger();

	@Override
	public void destroy() {
	}

	@Override
	public void doFilter(ServletRequest arg0, ServletResponse arg1,
			FilterChain arg2) throws IOException, ServletException {
		logger.info("账号重复登陆限制过滤器，是否限制：", needLoginOnlylimit);
		HttpServletRequest request = (HttpServletRequest) arg0;
		if(!needLoginOnlylimit || (UserLoginOnlyFilter.excludeUriRegex != null && request.getRequestURI().matches(UserLoginOnlyFilter.excludeUriRegex))) {
			arg2.doFilter(arg0, arg1);
			return;
		}

		HttpServletResponse response = (HttpServletResponse) arg1;
		if (valid(request, response)) {
			arg2.doFilter(arg0, arg1);
		} else {
			doOut(request, response);
		}
	}

	private boolean valid(HttpServletRequest request, HttpServletResponse response) throws IOException {

		HttpSession session = request.getSession();
		User user = (User) session.getAttribute(Configuration.userSession);

		logger.info("sessionId:", session.getId());
		logger.info("user:", user);

		if(user == null) {
			sendRedirectErrorView(response, "对不起会话超时！（Session timeout!）");
			return false;
		}

		String currentSessionId = userMap.get(user.getUsername());

		if(currentSessionId == null) {
			userMap.put(user.getUsername(), session.getId());

			sessionHistory.add(session.getId());
			return true;
		}
		if(session.getId().equals(currentSessionId)) {
			return true;
		}

		if(!sessionHistory.contains(session.getId())) {
			userMap.put(user.getUsername(), session.getId());
			sessionHistory.add(session.getId());
			return true;
		}

		sessionHistory.remove(session.getId());
		return false;
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
		needLoginOnlylimit = ConfigUtil.getBoolean("sso.client.needLoginOnlylimit");
		logger.info("账号重复登陆限制过滤器#init,needLoginOnlylimit:", needLoginOnlylimit);
	}

	public void doOut(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		if(isJson(request)) {
			response.setContentType("text/json");
			// json 请求返回json数据
			Page<Object> res = new Page<Object>();
			res.setResponseMessage(ResponseMessage.BUSINESS_EXCEPTION);
			res.setMessage("对不起，您的账号已在别处登录！如果不是本人操作，建议您尽快修改密码！");
			response.getWriter().write(
					net.sf.json.JSONObject.fromObject(res).toString());
		} else {
			response.setContentType("text/html");
			sendRedirectErrorView(response, "对不起会话超时！（Session timeout!）");
		}

		HttpSession session = request.getSession();
		String sessionId = session.getId();

		logger.info("[LogoutServlet>logou out use sessionId : " + sessionId
				+ ",appName : " + Configuration.serviceName + "]");

		@SuppressWarnings("rawtypes")
		Map map = SsoSessionListener.sessionContextMap;
		map.remove(sessionId);
		session.invalidate();

		String logoutUrl = buildUrl(sessionId);
		if (logger.isDebugEnabled()) {
			logger.debug("[LogoutServlet>logout url : " + logoutUrl + "]");
		}
		boolean isValid = false;
		HttpClient client = new HttpClient();
		try {
			String result = client.URLGet(logoutUrl, null,
					Configuration.encoding);
			logger.info("[LogoutServlet>logout message from ssoServer : "
					+ result + "]");

			isValid = validateResult(result);

			if (!isValid) {
				throw new SSOException("100005", "logout failed");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private boolean validateResult(String result) throws Exception {
		if ((null == result) || ("".equals(result))) {
			throw new SSOException("100005",
					"invoke logout,get null from ssoServer");
		}
		JSONObject obj = new JSONObject(result);
		String errorCode = obj.getString("errorCode");
		if (!"00000".equals(errorCode)) {
			throw new SSOException("100005", errorCode);
		}
		return true;
	}

	private String buildUrl(String sessionId)
			throws UnsupportedEncodingException {
		StringBuffer jumpUrl = new StringBuffer(Configuration.logoutUrl);

		jumpUrl.append("?serverId=")
				.append(URLEncoder.encode(Configuration.serviceName,
						Configuration.encoding)).append("&sessionId=")
				.append(URLEncoder.encode(sessionId, Configuration.encoding));

		return jumpUrl.toString();
	}

	static boolean isJson(HttpServletRequest request) {

		return request.getRequestURI().endsWith(".biz");
	}

	static void sendRedirectErrorView(HttpServletResponse response, String message) throws IOException {

		response.sendRedirect("/");
//		Page<Object> res = new Page<Object>();
//		res.setResponseMessage(ResponseMessage.BUSINESS_EXCEPTION);
//		res.setMessage(message);
//		response.getWriter().write(
//				net.sf.json.JSONObject.fromObject(res).toString());
//		response.sendRedirect("/operationmanagesystem/desktop/error.view");
	}
}
