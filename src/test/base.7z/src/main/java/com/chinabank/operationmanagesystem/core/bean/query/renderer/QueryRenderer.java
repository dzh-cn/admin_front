/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-4-8</li>
 * <li>3、开发时间：下午2:41:08</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.bean.query.renderer</li>
 * <li>6、文件名称：QueryRenderer.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.bean.query.renderer;

import com.chinabank.operationmanagesystem.core.bean.query.QueryData;
import com.chinabank.operationmanagesystem.core.bean.query.ViewObject;

/**
 * <ul>
 * <li>1、开发日期：2014-4-8</li>
 * <li>2、开发时间：下午2:41:08</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：QueryRenderer</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public interface QueryRenderer {
	public ViewObject renderQuery(QueryData queryData);
}
