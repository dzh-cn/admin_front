/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2013-12-24</li>
 * <li>3、开发时间：下午5:17:07</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.desktop.annotation</li>
 * <li>6、文件名称：SqlMapper.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.desktop.annotation;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * <ul>
 * <li>1、开发日期：2013-12-24</li>
 * <li>2、开发时间：下午5:17:07</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：SqlMapper</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
/*@Target({ElementType.ANNOTATION_TYPE })*/  
@Retention(RetentionPolicy.RUNTIME)
public @interface SqlMapper {

}
