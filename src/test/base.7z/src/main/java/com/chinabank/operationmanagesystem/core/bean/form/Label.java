/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-5-15</li>
 * <li>3、开发时间：下午1:42:03</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.bean.form</li>
 * <li>6、文件名称：Label.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.bean.form;

import com.chinabank.operationmanagesystem.core.bean.query.QueryData;
import com.chinabank.operationmanagesystem.core.enums.LabelEnum;

/**
 * <ul>
 * <li>1、开发日期：2014-5-15</li>
 * <li>2、开发时间：下午1:42:03</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：Label</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class Label extends QueryData {
	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：Label.java</li>
	 * <li>3、字段含义：</li>
	 * </ul>
	 */
	private static final long serialVersionUID = 919458080400600892L;
	/**  
	 * Title: Label.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	private String defaultValue = "";
	private String bind;
	private LabelEnum labelEnum = LabelEnum.LABEL;
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-15</li>
	 * <li>2、开发时间：下午2:09:03</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“defaultValue”的值
	 */
	public String getDefaultValue() {
		return defaultValue;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-15</li>
	 * <li>2、开发时间：下午2:09:03</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“defaultValue”的值将赋给字段“defaultValue”
	 */
	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-15</li>
	 * <li>2、开发时间：下午2:09:03</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“labelEnum”的值
	 */
	public LabelEnum getLabelEnum() {
		return labelEnum;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-15</li>
	 * <li>2、开发时间：下午2:09:03</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“labelEnum”的值将赋给字段“labelEnum”
	 */
	public void setLabelEnum(LabelEnum labelEnum) {
		this.labelEnum = labelEnum;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-15</li>
	 * <li>2、开发时间：下午2:13:29</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“bind”的值
	 */
	public String getBind() {
		return bind;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-15</li>
	 * <li>2、开发时间：下午2:13:29</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“bind”的值将赋给字段“bind”
	 */
	public void setBind(String bind) {
		this.bind = bind;
	}
	
}
