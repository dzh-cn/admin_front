/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2013-12-23</li>
 * <li>3、开发时间：下午6:22:10</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.desktop.util</li>
 * <li>6、文件名称：ReadMenu.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.desktop.util;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.chinabank.operationmanagesystem.desktop.bean.Menu;

/**
 * <ul>
 * <li>1、开发日期：2013-12-23</li>
 * <li>2、开发时间：下午6:22:10</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：ReadMenu</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class ReadMenu {

	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2013-12-23</li>
	 * <li>2、开发时间：下午6:22:10</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 */
	public ReadMenu() {
		// TODO Auto-generated constructor stub
	}
	
	public static List<Menu> read(String json) {
		List<Menu> menuList = new ArrayList<Menu>();
		JSONArray jsonArray = JSONArray.fromObject(json);
		List<Object> arrayList = (List<Object>) JSONArray.toCollection(jsonArray);
		Map<String,Menu> map = new HashMap<String,Menu>();
		Menu root = new Menu();
		for (Object object : arrayList) {
			JSONObject jsonObject = JSONObject.fromObject( object );
			String ismenu = jsonObject.getString("ismenu");
			String parentid = jsonObject.getString("parentid");
			if(parentid.equals("-2147483648")) {
				String id = jsonObject.getString("id");
				String actionname = jsonObject.getString("actionname");
				String authvalue = jsonObject.getString("authvalue");
				Object obj = jsonObject.get("orderid");
				if(null != obj) {
					root.setOrderid(String.valueOf(obj));
				}
				root.setId(id);
				root.setActionname(actionname);
				root.setAuthvalue(authvalue);
			}
			if(ismenu.equals("1")) {
				String id = jsonObject.getString("id");
				String actionname = jsonObject.getString("actionname");
				String authvalue = jsonObject.getString("authvalue");
				Menu menu = new Menu();
				Object obj = jsonObject.get("orderid");
				if(null != obj) {
					menu.setOrderid(String.valueOf(obj));
				}
				menu.setId(id);
				menu.setActionname(actionname);
				menu.setAuthvalue(authvalue);
				menu.setParentid(parentid);
				map.put(menu.getId(), menu);
			}
		}
		Set<Entry<String,Menu>> sets = map.entrySet();
		for (Entry<String,Menu> entry : sets) {
			menuList.add(entry.getValue());
		}
		Collections.sort(menuList);
		List<Menu> list = new ArrayList<Menu>();
		String id = root.getId();
		Iterator<Menu> it = menuList.iterator();
		while(it.hasNext()) {
			Menu menu = it.next();
			String parentid = menu.getParentid();
			if(parentid.equals(id)) {
				list.add(menu);
				it.remove();
			}
		}
		for (Menu menu : list) {
			List<Menu> subList = new ArrayList<Menu>();
			id = menu.getId();
			it = menuList.iterator();
			while(it.hasNext()) {
				Menu subMenu = it.next();
				String parentid = subMenu.getParentid();
				if(parentid.equals(id)) {
					subList.add(subMenu);
					it.remove();
				}
			}
			menu.setList(subList);
		}
		for(Menu menu : list) {
			List<Menu> subList = menu.getList();
			for (Menu menu2 : subList) {
				List<Menu> subList2 = new ArrayList<Menu>();
				id = menu2.getId();
				it = menuList.iterator();
				while(it.hasNext()) {
					Menu subMenu = it.next();
					String parentid = subMenu.getParentid();
					if(parentid.equals(id)) {
						subList2.add(subMenu);
						it.remove();
					}
				}
				menu2.setList(subList2);
			}
		}
		for(Menu menu : list) {
			List<Menu> subList = menu.getList();
			for (Menu menu2 : subList) {
				List<Menu> subList2 = menu2.getList();
				for (Menu menu3 : subList2) {
					List<Menu> subList3 = new ArrayList<Menu>();
					id = menu3.getId();
					it = menuList.iterator();
					while(it.hasNext()) {
						Menu subMenu = it.next();
						String parentid = subMenu.getParentid();
						if(parentid.equals(id)) {
							subList3.add(subMenu);
							it.remove();
						}
					}
					menu3.setList(subList3);
				}
			}
		}
		return list;
	}
}
