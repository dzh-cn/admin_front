/** 
 * Copyright: Copyright (c)2013
 * Company: 网银在线(ChinaBank) 
 */
package com.chinabank.operationmanagesystem.desktop.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.SocketException;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPConnectionClosedException;
import org.apache.commons.net.ftp.FTPReply;

import com.chinabank.operationmanagesystem.core.bean.UploadFile;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;


/**  
 * Title: FtpUtil.java
 * Description: FTP工具，提供上传、下载功能
 * @author: wywangjiaqi 
 * @version V1.0
 * @history:
 */

public class FtpUtil implements DownloadUtil{

	private FTPClient ftp;
	private Logger logger = LoggerFactory.getLogger(FtpUtil.class);
	private String addr;
	private Integer port;
	private String username;
	private String password;
	
	public FtpUtil() {}
	
	private boolean connect(String path, String addr, int port,
			String username, String password,String uniqueID) {
		boolean result = false;
		ftp = new FTPClient();
		int reply;
		try {
			if(ftp.isConnected()) {
				result = true;
				return result;
			}
			ftp.connect(addr, port);
			ftp.login(username, password);
			ftp.setFileType(FTPClient.BINARY_FILE_TYPE);
			ftp.setControlEncoding("UTF-8");
			reply = ftp.getReplyCode();
			if (!FTPReply.isPositiveCompletion(reply)) {
				ftp.disconnect();
				return result;
			}
			/*ftp.changeWorkingDirectory(path);*/
			result = true;
		} catch (SocketException e) {
			logger.error("ID="+ uniqueID +","+"连接FTP服务器失败！FTP-"+addr+":"+port+"@"+username+":"+password,e.fillInStackTrace());
		} catch (IOException e) {
			logger.error("ID="+ uniqueID +","+"I/O异常",e.fillInStackTrace());
		}
		return result;
	}

	/**
	 * ftp进入pathname路径。如无对应目录，则创建。
	 * @param pathname
	 * @param uniqueID
	 * @return
	 */
	public boolean pathChange(String pathname,String uniqueID) {
		String path[] = pathname.split("/");
		try {
			for (int i = 0; i < path.length; i++) {
				if (!ftp.changeWorkingDirectory(path[i])) {
					if (ftp.makeDirectory(path[i])) {
						ftp.changeWorkingDirectory(path[i]);
					} else {
						logger.info("ID="+ uniqueID +","+"创建目录失败");
						return false;
					}
				}
			}
		} catch(FTPConnectionClosedException e) {
			logger.error("ID="+ uniqueID +","+"FTP连接断开！",e.fillInStackTrace());
		} catch (Exception e) {
			logger.error("ID="+ uniqueID +","+"",e.fillInStackTrace());
		}
		return true;
	}
	
	/**
	 * 格式化pathname为xxx/xxx/xxx的形式。
	 * @param pathname
	 * @return
	 */
	public static String formatPath(String pathname) {
		if(null != pathname){
			pathname = pathname.replaceAll("\\.\\.", "");
			pathname = pathname.replaceAll("[/|\\\\]+", "/");
			pathname = pathname.replaceAll("/*$", "");
			//pathname = pathname.replaceAll("/+", "/");
			pathname = pathname.replaceAll("^/*", "");
		}		
		return pathname;
	}

	/**
	 * 
	 */
	public boolean upload(InputStream local, UploadFile uploadfile,String uniqueID) {
		String filename = uploadfile.getName();
		String pathname = uploadfile.getPath();
		boolean result = false;
		try {
			if(true == connect("/",this.addr,this.port,this.username,this.password,uniqueID)) {
				pathname = formatPath(pathname);
				if(null != pathname) {
					if(pathChange(pathname,uniqueID)) {
						result = ftp.storeFile(filename, local);
					} else {
						logger.info("ID="+ uniqueID +","+"进入pathname="+pathname+"失败");
					}
				} else {
					logger.info("ID="+ uniqueID +","+"上传失败。原因：路径为null");
				}
			}
		} catch(FTPConnectionClosedException e) {
			logger.error("ID="+ uniqueID +","+"FTP服务器失去连接！",e.fillInStackTrace());
		} catch(org.apache.commons.net.io.CopyStreamException e) {
			logger.error("ID="+ uniqueID +","+"上传异常，可能为超出限制！",e.fillInStackTrace());
			try {
				if(ftp.deleteFile(filename)) {
					logger.info("ID="+ uniqueID +","+"删除异常文件"+filename+"成功");
				} else {
					logger.info("ID="+ uniqueID +","+"删除异常文件"+filename+"失败！");
				}
			} catch (IOException e1) {
				logger.error("ID="+ uniqueID +","+"删除异常文件" + filename +"时出现错误！",e1.fillInStackTrace());
			}
		} catch (IOException e) {
			logger.error("ID="+ uniqueID +","+"I/O异常！",e.fillInStackTrace());
		} finally {
			try {
				ftp.logout();
			} catch (IOException e) {
				logger.error("ID="+ uniqueID +","+"FTP注销异常！",e.fillInStackTrace());
			}
		}
		return result;
	}

	public boolean download(OutputStream local,UploadFile uploadfile,String uniqueID) {
		String pathname = uploadfile.getPath();
		String filename = uploadfile.getName();
		boolean result = false;
		try {
			if(true == connect("/",this.addr,this.port,this.username,this.password,uniqueID)) {
				pathname = formatPath(pathname);
				if(null != pathname) {
					if(pathChange(pathname,uniqueID)) {
						if(null != filename && !"".equals(filename.trim())) {
							result = ftp.retrieveFile(filename, local);
						} else {
							logger.info("ID="+ uniqueID +","+"文件名为null或空值");
						}
					} else {
						logger.info("ID="+ uniqueID +","+"进入pathname="+pathname+"失败，文件可能不存在！");
					}
				} else {
					logger.info("ID="+ uniqueID +","+"下载失败。原因：路径为null");
				}
			}
		} catch(FTPConnectionClosedException e) {
			logger.error("ID="+ uniqueID +","+"FTP服务器失去连接！",e.fillInStackTrace());
		} catch(org.apache.commons.net.io.CopyStreamException e) {
			logger.debug("ID="+ uniqueID +","+"上传异常，可能为超出最大限制或用户取消！",e.fillInStackTrace());
		} catch (IOException e) {
			logger.error("ID="+ uniqueID +","+"I/O异常！",e.fillInStackTrace());
		} finally {
			try {
				ftp.logout();
			} catch (IOException e) {
				logger.error("ID="+ uniqueID +","+"FTP注销异常！",e.fillInStackTrace());
			}
		}
		return result;
	}
	
	public FTPClient getFtp() {
		return ftp;
	}

	public static void main(String[] args) {
		String pathname = "/.././abc.jpg";
		pathname = pathname.replaceAll("\\.\\.", "");
		FtpUtil ftpUtil = new FtpUtil();
		ftpUtil.setAddr("10.45.26.61");
		ftpUtil.setPort(21);
		ftpUtil.setUsername("wywangjiaqi");
		ftpUtil.setPassword("root123");
		System.out.println(ftpUtil.connect("/", "10.45.246.61", 21, "wywangjiaqi", "root123","log4j20131205test"));
		FTPClient ftp = ftpUtil.getFtp();
		try {
			System.out.println(ftp.makeDirectory("abc"));
			System.out.println(ftp.changeWorkingDirectory("class"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void setAddr(String addr) {
		this.addr = addr;
	}

	public void setPort(Integer port) {
		this.port = port;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
}
