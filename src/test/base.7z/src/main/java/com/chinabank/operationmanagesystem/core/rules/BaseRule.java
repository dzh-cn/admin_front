/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-5-12</li>
 * <li>3、开发时间：下午6:17:14</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.rules</li>
 * <li>6、文件名称：BaseRule.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.rules;

import java.io.Serializable;

/**
 * <ul>
 * <li>1、开发日期：2014-5-12</li>
 * <li>2、开发时间：下午6:17:14</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：BaseRule</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
abstract public class BaseRule implements Serializable {
	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：BaseRule.java</li>
	 * <li>3、字段含义：</li>
	 * </ul>
	 */
	private static final long serialVersionUID = -8553524283151054605L;
	/**  
	 * Title: BaseRule.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	private String name;
	
	abstract public String getValue();

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-12</li>
	 * <li>2、开发时间：下午6:18:23</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“name”的值
	 */
	public String getName() {
		return name;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-12</li>
	 * <li>2、开发时间：下午6:18:23</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“name”的值将赋给字段“name”
	 */
	public void setName(String name) {
		this.name = name;
	}
	
}
