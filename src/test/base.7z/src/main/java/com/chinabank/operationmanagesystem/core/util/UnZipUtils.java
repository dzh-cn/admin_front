/**
 * <p>项目名称：oms-0.0.1<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-6-16</li>
 * <li>3、开发时间：下午1:45:45</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.util</li>
 * <li>6、文件名称：UnZipUtils.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.util;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Enumeration;

import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipFile;
import org.apache.commons.compress.utils.IOUtils;
import org.apache.commons.io.FileUtils;

import com.chinabank.operationmanagesystem.desktop.util.ConfigUtil;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;


/**
 * <ul>
 * <li>1、开发日期：2014-6-16</li>
 * <li>2、开发时间：下午1:45:45</li>
 * <li>3、作 者：wangjiaqi</li>
 * <li>4、类型名称：UnZipUtils</li>
 * <li>5、类型意图：</li>
 * </ul>
 * 
 */
public class UnZipUtils {
	private static final Logger logger = LoggerFactory.getLogger(UnZipUtils.class);
	private static String basePluginZipPath = ConfigUtil.getString("sys.plugins.zip.path");
	private static String basePluginPath = ConfigUtil.getString("sys.plugins.path");
	private static String baseTempPath = ConfigUtil.getString("sys.plugins.temp.path");
	/**
	 * Title: UnZipUtils.java Description: TODO(用一句话描述该文件做什么)
	 * 
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */

	/**
	 * 把一个zip文件解压到一个指定的目录中
	 * 
	 * @param zipfilename
	 *            zip文件抽象地址
	 * @param outputdir
	 *            目录绝对地址
	 * @throws IOException 
	 */
	private static void unZipToFolder(String zipfilename, String outputdir) throws IOException {
		File zipfile = null;
		ZipFile zf = null;
		FileOutputStream fos = null;
		try {
			zipfile = new File(zipfilename);
			if (zipfile.exists()) {
				outputdir = outputdir + File.separator;
				FileUtils.forceMkdir(new File(outputdir));
				zf = new ZipFile(zipfile, "GBK");
				Enumeration<ZipArchiveEntry> zipArchiveEntrys = zf.getEntries();
				while (zipArchiveEntrys.hasMoreElements()) {
					ZipArchiveEntry zipArchiveEntry = (ZipArchiveEntry) zipArchiveEntrys
							.nextElement();
					if (zipArchiveEntry.isDirectory()) {
						FileUtils.forceMkdir(new File(outputdir
								+ zipArchiveEntry.getName() + File.separator));
					} else {
						fos = FileUtils.openOutputStream(new File(outputdir + zipArchiveEntry.getName()));
						IOUtils.copy(zf.getInputStream(zipArchiveEntry),fos);
						fos.close();
					}
				}
			} else {
				throw new IOException("指定的解压文件不存在：\t" + zipfilename);
			}
		} catch (IOException e) {
			throw new IOException("指定的解压文件不存在：\t" + zipfilename);
		} finally {
			try {
				if(null != zf) {
					zf.close();
				}
				if(null != fos) {
					fos.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	private static void deleteFile(String targetPath) throws IOException {
		File targetFile = new File(targetPath);
		if (targetFile.isDirectory()) {
			try {
				FileUtils.deleteDirectory(targetFile);
			} catch (IOException e) {
				try {
					System.gc();
					System.out.println("gc");
					FileUtils.deleteDirectory(targetFile);
				} catch (IOException e1) {
					throw new IOException("文件夹"+targetPath+"删除失败！可能正在被占用，请稍后再试！");
				}
			}
		} else if (targetFile.isFile()) {
			if(!targetFile.delete()) {
				throw new IOException("文件"+targetPath+"删除失败！");
			}
		}
	}
	
	private static void copyFile(String resFilePath, String distFolder)
			throws IOException {
		File resFile = new File(resFilePath);
		File distFile = new File(distFolder);
		if (resFile.isDirectory()) {
			FileUtils.copyDirectoryToDirectory(resFile, distFile);
		} else if (resFile.isFile()) {
			FileUtils.copyFileToDirectory(resFile, distFile, true);
		}
	}
	
	private static void copyFiles(String pluginName,String tempPath, String branch) throws IOException {
		String tempHttpPath = tempPath + File.separator+ "http" + File.separator + pluginName + File.separator;
		String tempPagesPath = tempPath + File.separator+ "pages" + File.separator + pluginName + File.separator;
		String tempKeyPath = tempPath + File.separator+ "key" + File.separator + pluginName + File.separator;
		String tempStaticPath = tempPath + File.separator+ "static" + File.separator + pluginName + File.separator;
		File srcFile = null;
		File destFile = null;
		if(!"".equals(branch)) {
			srcFile = new File(tempHttpPath);
			tempHttpPath = tempPath + File.separator+ "http" + File.separator + pluginName + "_" + branch + File.separator;
			destFile = new File(tempHttpPath);
			if(srcFile.exists()) {
				srcFile.renameTo(destFile);
			}
			
			srcFile = new File(tempPagesPath);
			tempPagesPath = tempPath + File.separator+ "pages" + File.separator + pluginName + "_" + branch + File.separator;
			destFile = new File(tempPagesPath);
			if(srcFile.exists()) {
				srcFile.renameTo(destFile);
			}
			
			srcFile = new File(tempKeyPath);
			tempKeyPath = tempPath + File.separator+ "key" + File.separator + pluginName + "_" + branch + File.separator;
			destFile = new File(tempKeyPath);
			if(srcFile.exists()) {
				srcFile.renameTo(destFile);
			}
			
			srcFile = new File(tempStaticPath);
			tempStaticPath = tempPath + File.separator+ "static" + File.separator + pluginName + "_" + branch + File.separator;
			destFile = new File(tempStaticPath);
			if(srcFile.exists()) {
				srcFile.renameTo(destFile);
			}
			
		} else {
		}
		String httpPath = basePluginPath + File.separator + "http" + File.separator;
		String pagesPath = basePluginPath + File.separator + "pages" + File.separator;
		String keyPath = basePluginPath + File.separator + "key" + File.separator;
		String staticPath = basePluginPath + File.separator + "static" + File.separator;
		String pluginHttpPath = httpPath + pluginName + File.separator;
		String pluginPagesPath = pagesPath + pluginName + File.separator;
		String pluginKeyPath = keyPath + pluginName + File.separator;
		String pluginStaticPath = staticPath + pluginName + File.separator;
		if(!"".equals(branch)) {
			pluginHttpPath = httpPath + pluginName + "_" + branch + File.separator;
			pluginPagesPath = pagesPath + pluginName + "_" + branch + File.separator;
			pluginKeyPath = keyPath + pluginName + "_" + branch + File.separator;
			pluginStaticPath = staticPath + pluginName + "_" + branch + File.separator;
		}
		logger.info("插件解压临时http路径："+tempHttpPath);
		logger.info("插件解压临时pages路径："+tempPagesPath);
		logger.info("插件解压临时key路径："+tempKeyPath);
		logger.info("插件解压临时static路径："+tempStaticPath);
		logger.info("http根路径："+httpPath);
		logger.info("pages根路径："+pagesPath);
		logger.info("key根路径："+keyPath);
		logger.info("static根路径："+staticPath);
		logger.info("插件http路径："+pluginHttpPath);
		logger.info("插件pages路径："+pluginPagesPath);
		logger.info("插件key路径："+pluginKeyPath);
		logger.info("插件static路径："+pluginStaticPath);
		UnZipUtils.deleteFile(pluginHttpPath);
		logger.info("+++++++++删除插件原http路径完成++++++++");
		UnZipUtils.deleteFile(pluginPagesPath);
		logger.info("+++++++++删除插件原pages路径完成++++++++");
		UnZipUtils.deleteFile(pluginKeyPath);
		logger.info("+++++++++删除插件原key路径完成++++++++");
		UnZipUtils.copyFile(tempHttpPath, httpPath);
		logger.info("+++++++++拷贝插件http路径完成++++++++");
		UnZipUtils.copyFile(tempPagesPath, pagesPath);
		logger.info("+++++++++拷贝插件pages路径完成++++++++");
		UnZipUtils.copyFile(tempKeyPath, keyPath);
		logger.info("+++++++++拷贝插件key路径完成++++++++");
		UnZipUtils.copyFile(tempStaticPath, staticPath);
		logger.info("+++++++++拷贝插件static路径完成++++++++");
	}
	
	public static void unZipPlugin(String pluginName,String pluginZipFile, String branch) throws IOException {
		logger.info("============插件升级开始============");
		logger.info("插件名称："+pluginName+"，插件zip文件："+pluginZipFile);
		String zipFile = "";
		String tempPath = "";
		if("".equals(branch)) {
			zipFile = basePluginZipPath + File.separator + pluginName + File.separator + pluginZipFile + File.separator;
			tempPath = baseTempPath + File.separator + pluginName + File.separator;
		} else {
			zipFile = basePluginZipPath + File.separator + pluginName + "_" + branch + File.separator + pluginZipFile + File.separator;
			tempPath = baseTempPath + File.separator + pluginName + "_" + branch + File.separator;
		}
		logger.info("插件zip包绝对路径："+zipFile+"，插件解压缩临时路径："+tempPath);
		logger.info("------------删除临时路径开始------------");
		UnZipUtils.deleteFile(tempPath);
		logger.info("------------删除临时路径完成------------");
		logger.info("------------解压插件开始------------");
		UnZipUtils.unZipToFolder(zipFile, tempPath);
		logger.info("------------插件拷贝开始------------");
		UnZipUtils.copyFiles(pluginName, tempPath, branch);
		logger.info("------------插件拷贝结束------------");
		logger.info("============插件升级结束============");
	}
	
	public static Integer getMaxVersion(String pluginName) throws Exception {
		Integer maxVersion = -1;
		Integer temp = maxVersion;
		File dir = new File(basePluginZipPath + File.separator + pluginName + File.separator);
		if(dir.exists()) {
			if(dir.isDirectory()) {
				File[] zips = dir.listFiles();
				for (File file : zips) {
					temp = UnZipUtils.getVersion(file.getName());
					if(temp > maxVersion) {
						maxVersion = temp;
					}
				}
			}
		}
		return ++maxVersion;
	}
	
	private static Integer getVersion(String zipFile) throws Exception {
		String[] temp = zipFile.split("_");
		if(temp.length > 0) {
			temp = temp[temp.length - 1].split("\\.");
			if(temp.length != 2) {
				throw new Exception("插件文件"+zipFile+"格式不对，请查证！");
			}
		} else {
			throw new Exception("插件文件"+zipFile+"格式不对，请查证！");
		}
		return Integer.valueOf(temp[0]);
	}
	
	public static void main(String[] args) {
		/*File f1 = new File("E:\\nfs_workspace");
		File f2 = new File("E:\\nfs_workspace1");
		System.out.println(f1.renameTo(f2));*/
		File f1 = new File("E:\\nfs_workspace\\oms\\plugin\\plugins\\temp\\clearing_pre\\http\\clearing");
		File f2 = new File("E:\\nfs_workspace\\oms\\plugin\\plugins\\temp\\clearing_pre\\http\\clearing_pre");
		System.out.println(f1.renameTo(f2));
	}
}
