/**
 * <p>项目名称：oms_0.1.1<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2015-1-6</li>
 * <li>3、开发时间：下午2:28:55</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.book.bean</li>
 * <li>6、文件名称：BookResult.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.book.bean;

/**
 * <ul>
 * <li>1、开发日期：2015-1-6</li>
 * <li>2、开发时间：下午2:28:55</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：BookResult</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class BookResult {
	/**  
	 * Title: BookResult.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	/**
	 * 请求是否成功
	 */
	private boolean successful = true;
	/**
	 * 文件是否存在
	 */
	private boolean exist;
	/**
	 * 预约是否成功
	 */
	private boolean bookSuccessful;
	/**
	 * 预约文件信息
	 */
	private BookFileDTO bookFile;
	/**
	 * 不成功原因
	 */
	private String message;
	/**
	 * <ul>
	 * <li>1、开发日期：2015-1-6</li>
	 * <li>2、开发时间：下午2:31:44</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“exist”的值
	 */
	public boolean isExist() {
		return exist;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2015-1-6</li>
	 * <li>2、开发时间：下午2:31:44</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“exist”的值将赋给字段“exist”
	 */
	public void setExist(boolean exist) {
		this.exist = exist;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2015-1-6</li>
	 * <li>2、开发时间：下午2:31:44</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“bookSuccessful”的值
	 */
	public boolean isBookSuccessful() {
		return bookSuccessful;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2015-1-6</li>
	 * <li>2、开发时间：下午2:31:44</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“bookSuccessful”的值将赋给字段“bookSuccessful”
	 */
	public void setBookSuccessful(boolean bookSuccessful) {
		this.bookSuccessful = bookSuccessful;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2015-1-6</li>
	 * <li>2、开发时间：下午2:31:44</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“message”的值
	 */
	public String getMessage() {
		return message;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2015-1-6</li>
	 * <li>2、开发时间：下午2:31:44</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“message”的值将赋给字段“message”
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2015-1-6</li>
	 * <li>2、开发时间：下午2:31:44</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“bookFile”的值
	 */
	public BookFileDTO getBookFile() {
		return bookFile;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2015-1-6</li>
	 * <li>2、开发时间：下午2:31:44</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“bookFile”的值将赋给字段“bookFile”
	 */
	public void setBookFile(BookFileDTO bookFile) {
		this.bookFile = bookFile;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2015-1-6</li>
	 * <li>2、开发时间：下午2:40:41</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“successful”的值
	 */
	public boolean isSuccessful() {
		return successful;
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2015-1-6</li>
	 * <li>2、开发时间：下午2:40:41</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“successful”的值将赋给字段“successful”
	 */
	public void setSuccessful(boolean successful) {
		this.successful = successful;
	}
	
	
}
