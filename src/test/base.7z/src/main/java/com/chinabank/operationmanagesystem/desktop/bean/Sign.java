/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-3-11</li>
 * <li>3、开发时间：上午10:05:47</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.desktop.bean</li>
 * <li>6、文件名称：Sign.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.desktop.bean;

import java.io.Serializable;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.chinabank.operationmanagesystem.desktop.util.MD5Util;
import com.chinabank.operationmanagesystem.desktop.util.ReadProperties;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;

/**
 * <ul>
 * <li>1、开发日期：2014-3-11</li>
 * <li>2、开发时间：上午10:05:47</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：Sign</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class Sign implements Serializable{

	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：Sign.java</li>
	 * </ul>
	 */
	private static final long serialVersionUID = 1L;
	private String appCode = "operation";
	private String key = "";
	private String sign = "";
	private static final Logger logger = LoggerFactory.getLogger(Sign.class);
	/**  
	 * Title: Sign.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	
	
	public Sign(String projectName, String module, String action,Map<String,?> params) {
		this.key = ReadProperties.read("app."+projectName+".key", "/key/"+projectName+"/key.properties");
		StringBuilder paramStr = new StringBuilder();
		if(null == this.key) {
			logger.warn("项目"+projectName+"签名key不存在，请确保/key/"+projectName+"/key.properties文件中存在"+"app."+projectName+".key");
			this.key = "";
		} else {
			String encryptParamsNameStr = ReadProperties.read("app."+projectName+"."+module+"."+action+".params", "/key/"+projectName+"/key.properties");
			if(null == encryptParamsNameStr) {
				logger.warn("项目"+projectName+"加密参数params不存在，请确保/key/"+projectName+"/key.properties文件中存在"+"app."+projectName+"."+module+"."+action+".params");
			} else {
				if(logger.isDebugEnabled()) {
					logger.debug("签名数据："+encryptParamsNameStr);
				}
				String[] encryptParamsNames =  encryptParamsNameStr.split(",");
				for (String paramasName : encryptParamsNames) {
					if(!StringUtils.isEmpty(params.get(paramasName) == null?"":params.get(paramasName).toString())) {
						paramStr.append(params.get(paramasName));
						if(logger.isDebugEnabled()) {
							logger.debug("paramsName："+paramasName+"，value:"+params.get(paramasName));
						}
					} else {
						if(logger.isDebugEnabled()) {
							logger.debug("paramsName："+paramasName+"，值为空，放弃签名！");
						}
					}
				}
			}
		}
		this.sign = MD5Util.MD5(this.appCode + paramStr.toString() + this.key);
		logger.info("project:"+projectName+"，module:"+module+"，action:"+action+"，sign："+sign);
	}
	public void setAppCode(String appCode) {
		this.appCode = appCode;
	}
	public String getSign() {
		return sign;
	}
	public String getAppCode() {
		return appCode;
	}
	public String getKey() {
		return key;
	}
}
