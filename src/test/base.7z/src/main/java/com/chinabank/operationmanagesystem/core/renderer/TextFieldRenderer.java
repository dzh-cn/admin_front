/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-4-8</li>
 * <li>3、开发时间：上午10:59:30</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.renderer</li>
 * <li>6、文件名称：TextFieldRenderer.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.renderer;

import com.chinabank.operationmanagesystem.core.bean.form.renderer.FormRenderer;
import com.chinabank.operationmanagesystem.core.bean.query.QueryData;
import com.chinabank.operationmanagesystem.core.bean.query.TextField;
import com.chinabank.operationmanagesystem.core.bean.query.ViewObject;
import com.chinabank.operationmanagesystem.core.bean.query.renderer.QueryRenderer;
import com.chinabank.operationmanagesystem.core.util.FormUtil;

/**
 * <ul>
 * <li>1、开发日期：2014-4-8</li>
 * <li>2、开发时间：上午10:59:30</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：TextFieldRenderer</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class TextFieldRenderer implements FormRenderer, QueryRenderer {
	private static final String formInputClass = "iconrept";
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-8</li>
	 * <li>2、开发时间：上午11:01:52</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see com.chinabank.operationmanagesystem.core.bean.form.renderer.FormRenderer#renderForm(com.chinabank.operationmanagesystem.core.bean.query.QueryData)
	 */
	@Override
	public ViewObject renderForm(QueryData queryData) {
		TextField textField = (TextField) queryData;
		StringBuilder html = new StringBuilder();
		StringBuilder ready = new StringBuilder();
		StringBuilder function = new StringBuilder();
		html.append(FormUtil.CR).append(FormUtil.INDENT_SIX).append("<label>").append(textField.getLabel()).append("</label>");
		html.append(FormUtil.CR).append(FormUtil.INDENT_SIX).append("<input type='text' name='").append(textField.getName()).append("' class='").append(formInputClass).append("'>");
		return new ViewObject(html.toString(),function.toString(),ready.toString());
	}
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-29</li>
	 * <li>2、开发时间：下午5:24:44</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see com.chinabank.operationmanagesystem.core.bean.query.renderer.QueryRenderer#renderQuery(com.chinabank.operationmanagesystem.core.bean.query.QueryData)
	 */
	@Override
	public ViewObject renderQuery(QueryData queryData) {
		return this.renderForm(queryData);
	}


	/**  
	 * Title: TextFieldRenderer.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
}
