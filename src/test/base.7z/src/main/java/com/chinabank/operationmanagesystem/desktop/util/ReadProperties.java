/** 
 * Copyright: Copyright (c)2011
 * Company: 网银在线(ChinaPay) 
 */
package com.chinabank.operationmanagesystem.desktop.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Arrays;
import java.util.Properties;

import org.apache.commons.lang.StringUtils;

import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.common.exception.NormalBusinessRuntimeException;


/**  
 * Title: ReadProperties.java
 * Description: TODO(用一句话描述该文件做什么)
 * @author: wywangjiaqi 
 * @version V1.0
 * @history:
 */

public class ReadProperties {
	private static Logger logger = LoggerFactory.getLogger(ReadProperties.class);
	private static String httpPath = ConfigUtil.getString("sys.plugins.path");
	/**    
	 * 创建一个新的实例 ReadProperties.    
	 *        
	 */
	public ReadProperties() {
	}
	
	public static String read(String key,String pathfile) {
		File file = new File(httpPath+File.separator+pathfile);
		if(!file.exists()) {
			return null;
		}
		InputStream in = null;
		try {
			in = new FileInputStream(file);
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		/*InputStream in = ReadProperties.class.getResourceAsStream(pathfile);*/
		Properties properties = new Properties();
		try {
			if(null != in) {
				properties.load(new InputStreamReader(in));
				return properties.getProperty(key);
			} else {
				logger.info("文件"+pathfile+"不存在！");
				return null;
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if(null != in) {
				try {
					in.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		return null;
	}

	/**
	 * 按照顺序读取配置，取到配置则返回
	 * @author dongzhihua
	 * @time 2017年11月7日 上午9:15:39
	 * @param pathFile
	 * @param keys
	 * @return String
	 */
	public static String readIfExist(String pathFile, String... keys) {
		for(String key : keys) {
			String str = read(key, pathFile);
			if(str != null) {
				return str;
			}
		}
		return null;
	}

	/**
	 * 按照顺序读取数字配置，取到配置则返回
	 * @author dongzhihua
	 * @time 2017年11月7日 上午9:16:13
	 * @param defaultValue
	 * @param pathFile
	 * @param keys
	 * @return int
	 */
	public static int readIntIfExist(int defaultValue, String pathFile, String... keys) {
		String value = readIfExist(pathFile, keys);
		if(StringUtils.isEmpty(value)) {
			return defaultValue;
		}
		if(!StringUtils.isNumeric(value)) {
			throw new NormalBusinessRuntimeException("error", "配置不是数字：" + pathFile + Arrays.toString(keys));
		}
		return Integer.valueOf(value);
	}
}
