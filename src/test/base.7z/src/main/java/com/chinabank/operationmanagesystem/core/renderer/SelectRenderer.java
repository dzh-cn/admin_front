/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-4-8</li>
 * <li>3、开发时间：上午11:04:39</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.renderer</li>
 * <li>6、文件名称：SelectRenderer.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.renderer;

import java.util.List;

import com.chinabank.operationmanagesystem.core.bean.form.renderer.FormRenderer;
import com.chinabank.operationmanagesystem.core.bean.query.Option;
import com.chinabank.operationmanagesystem.core.bean.query.QueryData;
import com.chinabank.operationmanagesystem.core.bean.query.Select;
import com.chinabank.operationmanagesystem.core.bean.query.ViewObject;
import com.chinabank.operationmanagesystem.core.bean.query.renderer.QueryRenderer;
import com.chinabank.operationmanagesystem.core.util.FormUtil;

/**
 * <ul>
 * <li>1、开发日期：2014-4-8</li>
 * <li>2、开发时间：上午11:04:39</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：SelectRenderer</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class SelectRenderer implements FormRenderer, QueryRenderer {
	private static final String formSelectClass = "ui-forms-select";
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-8</li>
	 * <li>2、开发时间：上午11:04:39</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see com.chinabank.operationmanagesystem.core.bean.form.renderer.FormRenderer#renderForm(com.chinabank.operationmanagesystem.core.bean.query.QueryData)
	 */
	@Override
	public ViewObject renderForm(QueryData queryData) {
		Select select = (Select) queryData;
		String parentId = select.getParentId();
		StringBuilder html = new StringBuilder();
		StringBuilder function = new StringBuilder();
		html.append(FormUtil.JS_CR).append(FormUtil.INDENT_FIVE).append("<label>").append(select.getLabel()).append("</label>");
		StringBuilder ready = new StringBuilder();
		if(null == parentId || parentId.equals("")) {
			if(null != select.getId() && !"".equals(select.getId())) {
				html.append(FormUtil.JS_CR).append(FormUtil.INDENT_FIVE).append("<select id='").append(select.getId()).append("' class='").append(formSelectClass).append("' name='").append(select.getName()).append("'>");
			} else {
				html.append(FormUtil.JS_CR).append(FormUtil.INDENT_FIVE).append("<select class='").append(formSelectClass).append("' name='").append(select.getName()).append("'>");
			}
		} else {
			html.append(FormUtil.JS_CR).append(FormUtil.INDENT_FIVE).append("<select id='").append(select.getId()).append("' class='").append(formSelectClass).append("' name='").append(select.getName()).append("'>");
			ready.append(FormUtil.CR).append(FormUtil.JS_CR).append("$('#").append(parentId).append("').bind('change',function() {");
			ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("var query =$(this).find(':selected').val();");
			ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("$.post('").append(select.getUrl()).append("',");
			ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("{");
			ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_TWO).append(select.getQueryParamName()).append(" : query");
			ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("},function(data) {");
			/*function += FormUtil.JS_CR + FormUtil.INDENT_TWO +"data = eval('('+data+')');";*/
			ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_TWO).append("var child = $('#").append(select.getId()).append("');");
			ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_TWO).append("child.empty();");
			if(select.isShowDefault()) {
				ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_TWO).append("child.append(\"<option value=''>全部</option>\");");
			}
			ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_TWO).append("data.list.forEach(function(item) {");
			ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_TWO).append(FormUtil.INDENT_ONE).append("child.append(\"<option value='\"+ item.").append(select.getJsonValueName()).append(" +\"'>\"+ item.").append(select.getJsonTextName()).append(" +\"</option>\");");
			ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_TWO).append("});");
			ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_TWO).append("child.change();");
			ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("});");
			ready.append(FormUtil.JS_CR).append("});");
		}
		if(select.isShowDefault()) {
			html.append(FormUtil.JS_CR).append(FormUtil.INDENT_SIX).append("<option value='").append(select.getDefaultValue()).append("' selected='selected'>").append(select.getDefaultText()).append("</option>");
		}
		List<Option> optionList = select.getOptionList();
		if(null != optionList) {
			for (Option option : optionList) {
				html.append(FormUtil.JS_CR).append(FormUtil.INDENT_SIX).append("<option value='").append(option.getValue()).append("'>").append(option.getText()).append("</option>");
			}
		}
		if((null == parentId || parentId.equals("")) && null != select.getUrl() && !"".equals(select.getUrl())) {
			ready.append(FormUtil.CR).append(FormUtil.JS_CR).append("$.post('").append(select.getUrl()).append("',");
			if(select.getQueryValue() != null &&!"".equals(select.getQueryValue())) {
				ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("{");
				ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_TWO).append(select.getQueryParamName()).append(" : '").append(select.getQueryValue()).append("'");
				ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("},");
			}
			ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("function(data) {");
			ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_TWO).append("var _self = $('#").append(select.getId()).append("');");
			ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_TWO).append("data.list.forEach(function(item) {");
			ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_TWO).append("_self.append(\"<option value='\"+ item.").append(select.getJsonValueName()).append(" +\"'>\"+ item.").append(select.getJsonTextName()).append(" +\"</option>\");");
			ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_ONE).append("});");
			ready.append(FormUtil.JS_CR).append(FormUtil.INDENT_TWO).append("_self.change();");
			ready.append(FormUtil.JS_CR).append("});");
		}
		html.append(FormUtil.JS_CR).append(FormUtil.INDENT_FIVE).append("</select>");
		return new ViewObject(html.toString(),function.toString(),ready.toString());
	}
	/**  
	 * Title: SelectRenderer.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	/**
	 * <ul>
	 * <li>1、开发日期：2014-4-29</li>
	 * <li>2、开发时间：下午5:24:07</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * @see com.chinabank.operationmanagesystem.core.bean.query.renderer.QueryRenderer#renderQuery(com.chinabank.operationmanagesystem.core.bean.query.QueryData)
	 */
	@Override
	public ViewObject renderQuery(QueryData queryData) {
		return this.renderForm(queryData);
	}
}
