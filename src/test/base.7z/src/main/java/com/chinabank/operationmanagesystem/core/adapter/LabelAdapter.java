/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-5-15</li>
 * <li>3、开发时间：下午2:09:35</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.adapter</li>
 * <li>6、文件名称：LabelAdapter.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.adapter;

import com.chinabank.operationmanagesystem.core.bean.Element;
import com.chinabank.operationmanagesystem.core.bean.form.Label;
import com.chinabank.operationmanagesystem.core.bean.form.adapter.FormAdapter;
import com.chinabank.operationmanagesystem.core.bean.grid.adapter.BaseGridAdapter;
import com.chinabank.operationmanagesystem.core.bean.query.QueryData;
import com.chinabank.operationmanagesystem.core.bean.query.adapter.QueryAdapter;

/**
 * <ul>
 * <li>1、开发日期：2014-5-15</li>
 * <li>2、开发时间：下午2:09:35</li>
 * <li>3、作 者：wangjiaqi</li>
 * <li>4、类型名称：LabelAdapter</li>
 * <li>5、类型意图：</li>
 * </ul>
 * 
 */
public class LabelAdapter extends BaseGridAdapter implements FormAdapter,
		QueryAdapter {

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-15</li>
	 * <li>2、开发时间：下午2:09:35</li>
	 * <li>3、作 者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * 
	 * @see com.chinabank.operationmanagesystem.core.bean.query.adapter.QueryAdapter#adapter4Query(com.chinabank.operationmanagesystem.core.bean.Element)
	 */
	@Override
	public QueryData adapter4Query(Element element) {
		return this.adapter4Form(element);
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-15</li>
	 * <li>2、开发时间：下午2:09:35</li>
	 * <li>3、作 者：wangjiaqi</li>
	 * <li>4、方法含义：</li>
	 * <li>5、方法说明：</li>
	 * </ul>
	 * 
	 * @see com.chinabank.operationmanagesystem.core.bean.form.adapter.FormAdapter#adapter4Form(com.chinabank.operationmanagesystem.core.bean.Element)
	 */
	@Override
	public QueryData adapter4Form(Element element) {
		Label label = new Label();
		label.setName(element.getName());
		label.setLabel(element.getLabel());
		label.setDefaultValue(element.getValue());
		return label;
	}
	/**
	 * Title: LabelAdapter.java Description: TODO(用一句话描述该文件做什么)
	 * 
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
}
