/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-3-26</li>
 * <li>3、开发时间：下午12:03:02</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.bean.query.element</li>
 * <li>6、文件名称：TypeAdapterManager.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.adapter;

import java.io.Serializable;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;

import com.chinabank.operationmanagesystem.core.bean.Element;
import com.chinabank.operationmanagesystem.core.bean.form.DatePicker;
import com.chinabank.operationmanagesystem.core.bean.form.TextArea;
import com.chinabank.operationmanagesystem.core.bean.form.adapter.FormAdapter;
import com.chinabank.operationmanagesystem.core.bean.grid.ColModel;
import com.chinabank.operationmanagesystem.core.bean.grid.Renderer;
import com.chinabank.operationmanagesystem.core.bean.grid.adapter.GridAdapter;
import com.chinabank.operationmanagesystem.core.bean.query.DatePairs;
import com.chinabank.operationmanagesystem.core.bean.query.QueryData;
import com.chinabank.operationmanagesystem.core.bean.query.Select;
import com.chinabank.operationmanagesystem.core.bean.query.SubmitButton;
import com.chinabank.operationmanagesystem.core.bean.query.TextField;
import com.chinabank.operationmanagesystem.core.bean.query.adapter.QueryAdapter;
import com.chinabank.operationmanagesystem.core.enums.ButtonEnum;
import com.chinabank.operationmanagesystem.core.exception.NoSuchAdapterException;
import com.chinabank.operationmanagesystem.core.rules.Rule;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.utils.GsonUtil;

/**
 * <ul>
 * <li>1、开发日期：2014-3-26</li>
 * <li>2、开发时间：下午12:03:02</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：TypeAdapterManager</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class TypeAdapterManager implements Serializable {

	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：TypeAdapterManager.java</li>
	 * <li>3、字段含义：</li>
	 * </ul>
	 */
	private static final Map<String,FormAdapter> formFactory = new HashMap<String,FormAdapter>();
	private static final Map<String,GridAdapter> gridFactory = new HashMap<String,GridAdapter>();
	private static final Map<String,QueryAdapter> queryFactory = new HashMap<String,QueryAdapter>();
	private static final long serialVersionUID = -6875795841326474347L;
	private static final Logger logger = LoggerFactory.getLogger(TypeAdapterManager.class);
	private static int selectCount = 0;
	static {
		TypeAdapterManager.registerForm("button", new ButtonAdapter());
		TypeAdapterManager.registerQuery("button", new ButtonAdapter());
		TypeAdapterManager.registerQuery("date", new DateAdapter());
		TypeAdapterManager.registerForm("date", new DateAdapter());
		TypeAdapterManager.registerGrid("date", new DateAdapter());
		TypeAdapterManager.registerQuery("datetime", new DateTimeAdapter());
		TypeAdapterManager.registerForm("datetime", new DateTimeAdapter());
		TypeAdapterManager.registerGrid("datetime", new DateTimeAdapter());
		TypeAdapterManager.registerQuery("datePairs", new DatePairsAdapter());
		TypeAdapterManager.registerForm("datePairs", new DatePairsAdapter());
		TypeAdapterManager.registerGrid("datePairs", new DatePairsAdapter());
		TypeAdapterManager.registerQuery("datetimePairs", new DatetimePairsAdapter());
		TypeAdapterManager.registerForm("datetimePairs", new DatetimePairsAdapter());
		TypeAdapterManager.registerGrid("datetimePairs", new DatetimePairsAdapter());
		TypeAdapterManager.registerQuery("dict", new DictAdapter());
		TypeAdapterManager.registerForm("dict", new DictAdapter());
		TypeAdapterManager.registerGrid("dict", new DictAdapter());
		TypeAdapterManager.registerQuery("customerDict", new CustomerDictAdapter());
		TypeAdapterManager.registerForm("customerDict", new CustomerDictAdapter());
		TypeAdapterManager.registerGrid("customerDict", new CustomerDictAdapter());
		TypeAdapterManager.registerGrid("operation", new OperationAdapter());
		TypeAdapterManager.registerForm("remark", new RemarkAdapter());
		TypeAdapterManager.registerQuery("text", new TextAdapter());
		TypeAdapterManager.registerForm("text", new TextAdapter());
		TypeAdapterManager.registerGrid("text", new TextAdapter());
		TypeAdapterManager.registerGrid("jump", new JumpActionAdapter());
		TypeAdapterManager.registerGrid("view", new ViewActionAdapter());
		TypeAdapterManager.registerGrid("single", new SingleAjaxActionAdapter());
		TypeAdapterManager.registerGrid("multi", new MultiAjaxActionAdapter());
		
		TypeAdapterManager.registerGrid("link", new LinkAdapter());
		TypeAdapterManager.registerGrid("header", new ColModelAdapter());
		
		TypeAdapterManager.registerGrid("singleConfirm", new SingleConfirmActionAdapter());
		TypeAdapterManager.registerGrid("multiConfirm", new MultiConfirmActionAdapter());
		TypeAdapterManager.registerGrid("singleMessage", new SingleMessageActionAdapter());
		TypeAdapterManager.registerGrid("multiMessage", new MultiMessageActionAdapter());
		TypeAdapterManager.registerGrid("singleDialog", new SingleDialogActionAdapter());
		TypeAdapterManager.registerGrid("multiDialog", new MultiDialogActionAdapter());
		TypeAdapterManager.registerGrid("dialog", new DialogActionAdapter());
		
		TypeAdapterManager.registerForm("jump", new JumpButtonAdapter());
		TypeAdapterManager.registerForm("view", new ViewButtonAdapter());
		TypeAdapterManager.registerForm("ajax", new AjaxButtonAdapter());
		
		TypeAdapterManager.registerQuery("placeholder", new PlaceholderAdapter());
		TypeAdapterManager.registerForm("placeholder", new PlaceholderAdapter());
		
		TypeAdapterManager.registerQuery("hidden", new HiddenAdapter());
		TypeAdapterManager.registerForm("hidden", new HiddenAdapter());
		
		TypeAdapterManager.registerForm("desc", new LabelAdapter());
		
		TypeAdapterManager.registerQuery("bindtext", new BindTextAdapter());
		TypeAdapterManager.registerForm("bindtext", new BindTextAdapter());
		TypeAdapterManager.registerGrid("bindtext", new BindTextAdapter());
		
		TypeAdapterManager.registerQuery("bindbutton", new BindButtonAdapter());
		TypeAdapterManager.registerForm("bindbutton", new BindButtonAdapter());
		TypeAdapterManager.registerQuery("bindlabel", new BindLabelAdapter());
		TypeAdapterManager.registerForm("bindlabel", new BindLabelAdapter());
	}
	public TypeAdapterManager() {}
	
	/**
	 * 
	 * <ul>
	 * <li>1、开发日期：2014-4-8</li>
	 * <li>2、开发时间：上午11:42:35</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、返回类型：void</li>
	 * <li>5、方法含义：注册表单渲染器</li>
	 * <li>6、方法说明：以name作为渲染器名称，注册渲染器。</li>
	 * </ul>
	 * @param name
	 * @param formRenderer
	 */
	public static void registerForm(String name, FormAdapter formAdapter) {
		formFactory.put(name, formAdapter);
	}
	public static void registerQuery(String name, QueryAdapter queryAdapter) {
		queryFactory.put(name, queryAdapter);
	}
	public static void registerGrid(String name, GridAdapter gridAdapter) {
		gridFactory.put(name, gridAdapter);
	}
	
	private static FormAdapter getFomRenderer(Element element) throws NoSuchAdapterException {
		FormAdapter formAdapter = formFactory.get(element.getType());
		if(null == formAdapter) {
			throw new NoSuchAdapterException("没有这种适配器："+element.getType()+"，请确保已经在TypeAdapterManager中registerForm。");
		}
		return formAdapter;
	}
	private static GridAdapter getGridRenderer(Element element) throws NoSuchAdapterException {
		GridAdapter gridAdapter = gridFactory.get(element.getType());
		if(null == gridAdapter) {
			throw new NoSuchAdapterException("没有这种适配器："+element.getType()+"，请确保已经在TypeAdapterManager中registerGrid。");
		}
		return gridAdapter;
	}
	private static QueryAdapter getQueryRenderer(Element element) throws NoSuchAdapterException {
		QueryAdapter queryAdapter = queryFactory.get(element.getType());
		if(null == queryAdapter) {
			throw new NoSuchAdapterException("没有这种适配器："+element.getType()+"，请确保已经在TypeAdapterManager中registerQuery。");
		}
		return queryAdapter;
	}
	
	public static Rule getRule(String ruleStr,String label) {
		Rule rule = new Rule();
		if(null != ruleStr) {
			try {
				String[] ruleSplit = ruleStr.split(";");
				for (String ruleEntryStr : ruleSplit) {
					String[] ruleEntry = ruleEntryStr.split(":");
					if(ruleEntry.length == 1) {
							BeanUtils.setProperty(rule, ruleEntry[0], true);
					} else if(ruleEntry.length == 2) {
						BeanUtils.setProperty(rule, ruleEntry[0], ruleEntry[1]);
					}
				}
			} catch (IllegalAccessException e) {
				logger.warn("表单校验元素初始化失败",e.fillInStackTrace());
			} catch (InvocationTargetException e) {
				logger.warn("表单校验元素初始化失败",e.fillInStackTrace());
			}
		}
		rule.buildRule();
		rule.buildMessage(label);
		return rule;
	}
	
	public static String replaceRule(String rule) {
		return rule.replaceAll("'", "\\\\'");
	}
	
	public static QueryData queryTypeAdapter(Element element) {
		QueryData queryData = null;
		try {
			QueryAdapter queryAdapter;
			queryAdapter = TypeAdapterManager.getQueryRenderer(element);
			queryData = queryAdapter.adapter4Query(element);
		} catch (NoSuchAdapterException e) {
			logger.error(e.getMessage(),e.fillInStackTrace());
		}
		return queryData;
	}
	
	public static ColModel gridTypeAdapter(Element element) {
		ColModel colModel = null;
		try {
			GridAdapter gridAdapter;
			gridAdapter = TypeAdapterManager.getGridRenderer(element);
			colModel = gridAdapter.adapter4Grid(element);
		} catch (NoSuchAdapterException e) {
			logger.error(e.getMessage(),e.fillInStackTrace());
		}
		return colModel;
	}
	
	public static QueryData formTypeAdapter(Element element) {
		QueryData queryData = null;
		try {
			FormAdapter formAdapter;
			formAdapter = TypeAdapterManager.getFomRenderer(element);
			queryData = formAdapter.adapter4Form(element);
		} catch (NoSuchAdapterException e) {
			logger.error(e.getMessage(),e.fillInStackTrace());
		}
		return queryData;
	}
	
	public static QueryData datePairsAdapter4Query(Element element) {
		DatePairs datePairs = new DatePairs();
		datePairs.setLabel(element.getLabel());
		datePairs.setStartName(element.getName()+"Start");
		datePairs.setEndName(element.getName()+"End");
		datePairs.setInterval(Integer.valueOf(element.getValue()));
		return datePairs;
	}
	
	public static ColModel datePairsAdapter4Grid(Element element) {
		return TypeAdapterManager.getColModel(element);
	}
	
	public static QueryData datePairsAdapter4Form(Element element) {
		return TypeAdapterManager.datePairsAdapter4Query(element);
	}
	
	public static QueryData datetimePairsAdapter4Query(Element element) {
		DatePairs datePairs = new DatePairs();
		datePairs.setLabel(element.getLabel());
		datePairs.setStartName(element.getName()+"Start");
		datePairs.setEndName(element.getName()+"End");
		datePairs.setInterval(Integer.valueOf(element.getValue()));
		datePairs.setShowTime(true);
		return datePairs;
	}
	
	public static QueryData datetimePairsAdapter4Form(Element element) {
		return TypeAdapterManager.datetimePairsAdapter4Query(element);
	}
	
	public static ColModel datetimePairsAdapter4Grid(Element element) {
		return TypeAdapterManager.getColModel(element);
	}
	
	public static QueryData dateAdapter4Form(Element element) {
		DatePicker datePicker = new DatePicker();
		datePicker.setLabel(element.getLabel());
		datePicker.setName(element.getName());
		datePicker.setTimeDiff(Integer.valueOf(element.getValue()));
		return datePicker;
	}
	
	public static QueryData dateAdapter4Query(Element element) {
		return TypeAdapterManager.dateAdapter4Form(element);
	}
	
	public static ColModel dateAdapter4Grid(Element element) {
		return TypeAdapterManager.getColModel(element);
	}
	
	public static QueryData datetimeAdapter4Form(Element element) {
		DatePicker datePicker = (DatePicker) TypeAdapterManager.dateAdapter4Form(element);
		datePicker.setShowTime(true);
		return datePicker;
	}
	
	public static QueryData datetimeAdapter4Query(Element element) {
		return TypeAdapterManager.datetimeAdapter4Form(element);
	}
	
	public static ColModel datetimeAdapter4Grid(Element element) {
		return TypeAdapterManager.getColModel(element);
	}
	
	public static QueryData dictAdapter4Query(Element element) {
		if(selectCount > 1000) {
			selectCount = 0;
		}
		Select select = new Select();
		select.setId("select"+selectCount++);
		select.setLabel(element.getLabel());
		select.setName(element.getName());
		select.setUrl("/dict/dict/queryDict.biz");
		select.setQueryValue(element.getValue());
		select.setShowDefault(false);
		return select;
	}
	
	public static ColModel dictAdapter4Grid(Element element) {
		return TypeAdapterManager.getColModel(element);
	}
	
	public static QueryData dictAdapter4Form(Element element) {
		return TypeAdapterManager.dictAdapter4Query(element);
	}
	
	public static ColModel operationAdapter4Grid(Element element) {
		ColModel colModel = TypeAdapterManager.getColModel(element);
		Renderer renderer = GsonUtil.getInstance().fromJson(element.getValue(), Renderer.class);
		colModel.setRenderer(renderer);
		return colModel;
	}
	
	public static QueryData textAdapter4Query(Element element) {
		TextField textField = new TextField();
		textField.setLabel(element.getLabel());
		textField.setName(element.getName());
		return textField;
	}
	
	public static ColModel textAdapter4Grid(Element element) {
		return TypeAdapterManager.getColModel(element);
	}
	
	public static QueryData textAdapter4Form(Element element) {
		return TypeAdapterManager.textAdapter4Query(element);
	}
	
	public static QueryData buttonAdapter4Query(Element element) {
		SubmitButton submitButton = new SubmitButton();
		submitButton.setLabel(element.getLabel());
		submitButton.setName(element.getName());
		submitButton.setButtonEnum(ButtonEnum.valueOf(element.getValue()));
		return submitButton;
	}
	
	public static QueryData buttonAdapter4Form(Element element) {
		return TypeAdapterManager.buttonAdapter4Query(element);
	}
	
	public static ColModel getColModel(Element element) {
		ColModel colModel = new ColModel();
		colModel.setHeader(element.getLabel());
		colModel.setName(element.getName());
		return colModel;
	}
	
	public static QueryData remarkAdapter4Form(Element element) {
		TextArea textArea = new TextArea();
		textArea.setLabel(element.getLabel());
		textArea.setName(element.getName());
		textArea.setPlaceholder(element.getValue());
		return textArea;
	}
	
	public static ColModel remarkAdapter4Grid(Element element) {
		return TypeAdapterManager.getColModel(element);
	}
	
	/**  
	 * Title: DateType.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	
}
