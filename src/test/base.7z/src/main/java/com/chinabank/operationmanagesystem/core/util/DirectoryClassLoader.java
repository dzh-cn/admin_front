package com.chinabank.operationmanagesystem.core.util;


import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.ArrayList;
import java.util.List;

//import com.wangyin.admin.frame.utils.Log;

/**
 * ???????????????classloader
 * @author xiongxiaopeng
 *
 */
public class DirectoryClassLoader extends URLClassLoader {
//	private static final Log log=Log.getLog(DirectoryClassLoader.class);
	private File root;

	public DirectoryClassLoader(File directory){
		super(new URL[]{});
		this.root = directory;
		init();
	}
	
	public DirectoryClassLoader(String directory) {
		this(new File(directory));
	}

	private void init() {
		List<File> files = new ArrayList<File>();
		loopFiles(root, files);
		for(File f:files){
			try {
				this.addURL(f.toURI().toURL());
			} catch (MalformedURLException e) {
				//log.error(e);
			}
		}
	}

	private static final void loopFiles(File file, List<File> files) {
		if (file.isDirectory()) {
			File[] tmps = file.listFiles();
			for (File tmp : tmps) {
				loopFiles(tmp, files);
			}
		} else {
			if (file.getAbsolutePath().endsWith(".jar") || file.getAbsolutePath().endsWith(".zip")) {
				files.add(file);
			}
		}
	}

}
