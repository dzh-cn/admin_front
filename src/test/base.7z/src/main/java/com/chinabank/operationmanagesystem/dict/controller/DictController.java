/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-3-27</li>
 * <li>3、开发时间：下午2:52:08</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.dict.controller</li>
 * <li>6、文件名称：DictController.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.dict.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import com.chinabank.cmcs.api.regtable.vo.RegTableDicVO;
import com.chinabank.operationmanagesystem.desktop.util.DictServiceUtil;
import com.chinabank.operationmanagesystem.dict.bean.TestBean;
import com.chinabank.operationmanagesystem.dict.bean.TestVO;
import com.chinabank.operationmanagesystem.dict.bean.TextValuePairs;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.beans.ErrorMessage;

/**
 * <ul>
 * <li>1、开发日期：2014-3-27</li>
 * <li>2、开发时间：下午2:52:08</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：DictController</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class DictController {
	
	private static Logger logger = LoggerFactory.getLogger(DictController.class);
	
	public static Map<String, Object> queryBiz(Map<String,Object> params) {
		String owner = String.valueOf(params.get("owner"));
		String category = String.valueOf(params.get("category"));
		List<TextValuePairs> list = new ArrayList<TextValuePairs>();
		try {
			List<RegTableDicVO> dataList = DictServiceUtil.getDictService().queryRegDataInfoByOwnerAndCataid(owner, category);
			String regValue = null;
			for (RegTableDicVO regTableDicVO : dataList) {
				Object object = regTableDicVO.getRegvaule();
				if(object instanceof String) {
					regValue = (String)object;
				} else {
					regValue = "";
				}
				list.add(new TextValuePairs(regTableDicVO.getRegkey(),regValue));
			}
		} catch (Exception e) {
			logger.error(e);
			ErrorMessage.getErrorMessage("查询数据字典故障！");
		}
		Map<String, Object> result = new HashMap<String,Object>();
		result.put("list", list);
		return result;
	}
	/**  
	 * Title: DictController.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	
	public Map<String, Object> queryDictBiz(Map<String,Object> params) {
		String code = String.valueOf(params.get("code"));
		System.out.println(code);
		Map<String, Object> result = new HashMap<String,Object>();
		List<TextValuePairs> list = new ArrayList<TextValuePairs>();
		list.add(new TextValuePairs("网关","1"));
		list.add(new TextValuePairs("快捷","2"));
		list.add(new TextValuePairs("小金库","3"));
		list.add(new TextValuePairs("白条","4"));
		result.put("list", list);
		return result;
	}
	
	public Map<String,Object> queryTestBiz(Map<String, Object> params) {
		Map<String, Object> result = new HashMap<String,Object>();
		List<TestVO> list = new ArrayList<TestVO>();
		list.add(new TestVO("1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1","1"));
		list.add(new TestVO("2","2","2","2","2","2","2","2","2","2","2","2","2","2","2","2","2"));
		list.add(new TestVO("3","3","待审核","3","3","3","3","3","3","3","3","3","3","3","3","3","3"));
		list.add(new TestVO("4","4","4","4","4","4","4","4","4","4","4","4","4","4","4","4","4"));
		list.add(new TestVO("5","5","5","5","5","5","5","5","5","5","5","5","5","5","5","5","5"));
		result.put("rows", list);
		result.put("total", 5);
		/*result.put("success", false);
		result.put("message", "错误信息");*/
		return result;
	}
	
	public Map<String,Object> testMultiBiz(Map<String,String> map,TestBean testBean) {
		Map<String,Object> resultMap = new HashMap<String,Object>();
		resultMap.put("success", true);
		resultMap.put("message", "批量审核成功！");
		return resultMap;
	}
	
	public Map<String,Object> testBiz(Map<String,String> map,TestVO testVO) {
		Map<String,Object> resultMap = new HashMap<String,Object>();
		resultMap.put("success", true);
		resultMap.put("message", "审核成功！");
		return resultMap;
	}
}
