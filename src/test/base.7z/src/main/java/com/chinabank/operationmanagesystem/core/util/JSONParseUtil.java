/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-1-10</li>
 * <li>3、开发时间：下午1:02:49</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.util</li>
 * <li>6、文件名称：JSONParseUtil.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import net.sf.ezmorph.object.DateMorpher;
import net.sf.json.JSONArray;
import net.sf.json.JSONException;
import net.sf.json.JSONObject;
import net.sf.json.util.JSONUtils;

import com.chinabank.operationmanagesystem.core.bean.grid.Action;
import com.chinabank.operationmanagesystem.core.bean.grid.ColModel;
import com.chinabank.operationmanagesystem.core.bean.grid.Grid;
import com.chinabank.operationmanagesystem.core.bean.grid.Renderer;
import com.chinabank.operationmanagesystem.core.bean.query.DatePairs;
import com.chinabank.operationmanagesystem.core.bean.query.Option;
import com.chinabank.operationmanagesystem.core.bean.query.Placeholder;
import com.chinabank.operationmanagesystem.core.bean.query.QueryData;
import com.chinabank.operationmanagesystem.core.bean.query.QueryForm;
import com.chinabank.operationmanagesystem.core.bean.query.Select;
import com.chinabank.operationmanagesystem.core.bean.query.SubmitButton;
import com.chinabank.operationmanagesystem.core.bean.query.TextField;
import com.chinabank.operationmanagesystem.core.bean.view.View;
import com.chinabank.operationmanagesystem.core.bean.view.ViewData;
import com.chinabank.operationmanagesystem.core.enums.ElementTypeEnum;
import com.chinabank.operationmanagesystem.core.enums.TextTypeEnum;
import com.chinabank.operationmanagesystem.core.enums.ViewTypeEnum;
import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;

/**
 * <ul>
 * <li>1、开发日期：2014-1-10</li>
 * <li>2、开发时间：下午1:02:49</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：JSONParseUtil</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class JSONParseUtil {

	private static Logger logger = LoggerFactory.getLogger(JSONParseUtil.class);
	private static int selectId = 0;
	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2014-1-10</li>
	 * <li>2、开发时间：下午1:02:49</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 */
	public JSONParseUtil() {
		// TODO Auto-generated constructor stub
	}
	/**  
	 * Title: JSONParseUtil.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	
	public static View getView(String jsonStr) {
		View view = new View();
		JSONObject jsonObject = JSONObject.fromObject(jsonStr);
		String title = jsonObject.getString("title");
		String strViewDatas = jsonObject.getString("viewDatas");
		List<ViewData> viewDatas = getViewDatas(strViewDatas);
		view.setTitle(title);
		view.setViewDatas(viewDatas);
		return view;
	}
	
	public static List<ViewData> getViewDatas(String jsonStr) {
		List<ViewData> viewDatas = new ArrayList<ViewData>();
		JSONArray jsonArray = JSONArray.fromObject(jsonStr);
		for (int i = 0; i < jsonArray.size(); i++) {
			JSONObject jsonObject = jsonArray.getJSONObject(i);
			String type = jsonObject.getString("type");
			String data = jsonObject.getString("data");
			ViewData viewData = null;
			if(type.equals(ViewTypeEnum.GRID.getName())) {
				viewData = getGrid(data);
			} else if(type.equals(ViewTypeEnum.QUERYFORM.getName())) {
				viewData = getQueryForm(data);
			}
			viewDatas.add(viewData);
		}
		return viewDatas;
	}
	
	public static Grid getGrid(String jsonStr) {
		JSONObject jsonObject = JSONObject.fromObject(jsonStr);
		String strColModels = jsonObject.getString("colModels");
		jsonObject.remove("colModels");
		List<ColModel> listColModels = getColModel(strColModels);
		Grid grid = (Grid) JSONObject.toBean(jsonObject, Grid.class);
		grid.setColModels(listColModels);
		return grid;
	}
	
	public static List<ColModel> getColModel(String jsonStr) {
		List<ColModel> list = new ArrayList<ColModel>();
		JSONArray jsonArray = JSONArray.fromObject(jsonStr);
		for (int i = 0; i < jsonArray.size(); i++) {
			JSONObject jsonObject = jsonArray.getJSONObject(i);
			Map<String,Class<?>> classMap = new HashMap<String,Class<?>>();
			classMap.put("renderer", Renderer.class);
			classMap.put("actions", Action.class);
			ColModel colModel = (ColModel) JSONObject.toBean(jsonObject, ColModel.class,classMap);
			list.add(colModel);
		}
		return list;
	}
	
	public static QueryForm getQueryForm(String jsonStr) {
		JSONObject jsonObject = JSONObject.fromObject(jsonStr);
		String strQueryDatas = jsonObject.getString("queryDatas");
		jsonObject.remove("queryDatas");
		List<QueryData> listQueryDatas = getQueryData(strQueryDatas);
		QueryForm queryForm = (QueryForm) JSONObject.toBean(jsonObject, QueryForm.class);
		queryForm.setQueryDatas(listQueryDatas);
		return queryForm;
	}
	
	public static List<QueryData> getQueryData(String jsonStr) {
		List<QueryData> list = new ArrayList<QueryData>();
		JSONArray jsonArray = JSONArray.fromObject(jsonStr);
		for (int i = 0; i < jsonArray.size(); i++) {
			JSONObject jsonObject = jsonArray.getJSONObject(i);
			String type = jsonObject.getString("type");
			String data = null;
			try {
				data = jsonObject.getString("data");
			} catch (JSONException e) {
				data = "{}";
				logger.warn("类型："+type + "，参数data不存在，请检查对应json字符串。");
			}
			JSONObject object = null;
			JSONArray array = null;
			if(selectId > 1000) {//约定页面中含有ajax的select元素不会多于1000个
				selectId = 0;
			}
			if(type.equals(ElementTypeEnum.TEXTFIELD.getName())) {
				object = JSONObject.fromObject(data);
				TextField textFiled = (TextField) JSONObject.toBean(object, TextField.class);
				list.add(textFiled);
			} else if(type.equals(ElementTypeEnum.AJAX_SELECT.getName())) {
				array = JSONArray.fromObject(data);
				String nextParentId = "";
				for (int j = 0; j < array.size(); j++) {
					JSONObject selectObject = array.getJSONObject(j);
					Select select = (Select) JSONObject.toBean(selectObject, Select.class);
					select.setParentId(nextParentId);
					nextParentId = "select" + selectId;
					select.setId(nextParentId);
					selectId ++;
					list.add(select);
				}
			} else if(type.equals(ElementTypeEnum.SELECT.getName())) {
				object = JSONObject.fromObject(data);
				Map<String,Class<?>> classMap = new HashMap<String,Class<?>>();
				classMap.put("optionList", Option.class);
				Select select = (Select) JSONObject.toBean(object, Select.class,classMap);
				if(null != select.getUrl() && !"".equals(select.getUrl())) {
					select.setId("select" + selectId);
					selectId ++;
				}
				list.add(select);
			} else if(type.equals(ElementTypeEnum.HIDDEN_TEXT.getName())) {
				object = JSONObject.fromObject(data);
				TextField textField = (TextField) JSONObject.toBean(object, TextField.class);
				textField.setType(TextTypeEnum.HIDDEN);
				list.add(textField);
			} else if(type.equals(ElementTypeEnum.SUBMIT_BUTTON.getName())) {
				object = JSONObject.fromObject(data);
				SubmitButton submitButton = (SubmitButton) JSONObject.toBean(object, SubmitButton.class);
				list.add(submitButton);
			} else if(type.equals(ElementTypeEnum.DATEPAIRS.getName())) {
				JSONUtils.getMorpherRegistry().registerMorpher(new DateMorpher(new String[]{"yyyy-MM-dd","yyyy-MM-dd HH:mm:ss"}));
				object = JSONObject.fromObject(data);
				DatePairs datePairs = (DatePairs) JSONObject.toBean(object, DatePairs.class);
				list.add(datePairs);
			} else if(type.equals(ElementTypeEnum.PLACEHOLDER.getName())) {
				Placeholder placeholder = new Placeholder();
				list.add(placeholder);
			}
		}
		return list;
	}
	
	/*public static void main(String[] args) {
		
		String jsonStr = "{'url':'/certification/certificate/certificate.biz','numPerLine':3,'queryDatas':[{'type':'textfield','data':{'label':'商户号','name':'customer'}},{'type':'textfield','data':{'label':'商户类型','name':'type'}},{'type':'ajax','data':[{'label':'省','name':'province','url':'/operationmanagesystem/desktop/province.biz'},{'label':'市','name':'city','url':'/operatiionmanagesystem/desktop/query.biz'}]},{'type':'select','data':{'label':'银行','name':'bankCode','url':'/operationmanagesystem/desktop/query.biz'}},{'type':'select','data':{'label':'银行2','name':'bankCode','optionList':[{'text':'广发银行','value':'0001'},{'text':'招商银行','value':'0002'}]}},{'type':'hidden','data':{'name':'customerId','defaultValue':'010101'}},{'type':'datepairs','data':{'startTime':'2013-12-12 10:10:10','endTime':'2013-12-13 12:12:12'}},{'type':'submit','data':{}}]}";
		JSONParseUtil jsonParseUtil = new JSONParseUtil();
		QueryForm queryForm = jsonParseUtil.getQueryForm(jsonStr);
		jsonStr = "{'singleSelect':'false','colModels':[{'header':'商户号','name':'customer'},{'header':'客户名称','name':'customerName'},{'header':'法人姓名','name':'legalName'},{'header':'操作','width':100,'renderer':{'actions':[{'text':'审核','url':'/certification/certificate/verify.biz','fixedParam':'type=1','params':['customer']}]}}]}";
		Grid grid = jsonParseUtil.getGrid(jsonStr);
		jsonStr = "{'title':'审核管理','viewDatas':[{'type':'queryForm','data':{'url':'/certification/certificate/certificate.biz','numPerLine':3,'queryDatas':[{'type':'textfield','data':{'label':'商户号','name':'customer'}},{'type':'textfield','data':{'label':'商户类型','name':'type'}},{'type':'ajax','data':[{'label':'省','name':'province','url':'/operationmanagesystem/desktop/province.biz'},{'label':'市','name':'city','url':'/operatiionmanagesystem/desktop/query.biz'}]},{'type':'select','data':{'label':'银行','name':'bankCode','url':'/operationmanagesystem/desktop/query.biz'}},{'type':'select','data':{'label':'银行2','name':'bankCode','optionList':[{'text':'广发银行','value':'0001'},{'text':'招商银行','value':'0002'}]}},{'type':'hidden','data':{'name':'customerId','defaultValue':'010101'}},{'type':'datepairs','data':{}},{'type':'submit','data':{}}]}},{'type':'grid','data':{'singleSelect':'false','colModels':[{'header':'商户号','name':'customer'},{'header':'客户名称','name':'customerName'},{'header':'法人姓名','name':'legalName'},{'header':'操作','width':100,'renderer':{'actions':[{'text':'审核','url':'/certification/certificate/verify.biz','fixedParam':'type=1','params':['customer']}]}}]}}]}";
		View view = jsonParseUtil.getView(jsonStr);
	}*/
}
