/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-1-8</li>
 * <li>3、开发时间：上午9:31:06</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.bean</li>
 * <li>6、文件名称：colModel.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.bean.grid;

import java.io.Serializable;

import com.chinabank.operationmanagesystem.core.enums.AlignEnum;
import com.chinabank.operationmanagesystem.core.enums.ColumnTypeEnum;
import com.chinabank.operationmanagesystem.core.enums.SortTypeEnum;

/**
 * <ul>
 * <li>1、开发日期：2014-1-8</li>
 * <li>2、开发时间：上午9:31:06</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：colModel</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class ColModel implements Serializable{

	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：colModel.java</li>
	 * </ul>
	 */
	private static final long serialVersionUID = 1L;
	private String id = "";
	private String header = "";
	private String name = "operation";
	private AlignEnum align = AlignEnum.CENTER;
	private int width = 80;
	private boolean wrap = true;
	private Renderer renderer = null;
	private ColumnTypeEnum columnTypeEnum = ColumnTypeEnum.COLUMN;
	private Action action = null;
	private String url = null;
	private SortTypeEnum sortTypeEnum = null;
	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2014-1-8</li>
	 * <li>2、开发时间：上午9:31:06</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 */
	public ColModel() {}
	
	public ColModel(String header, String name) {
		super();
		this.header = header;
		this.name = name;
	}

	public ColModel(String header, String name, int width) {
		super();
		this.header = header;
		this.name = name;
		this.width = width;
	}
	
	public ColModel(String header, int width, Renderer renderer) {
		super();
		this.header = header;
		this.width = width;
		this.renderer = renderer;
	}

	public ColModel(String header, String name, AlignEnum align, int width,
			boolean wrap, Renderer renderer) {
		super();
		this.header = header;
		this.name = name;
		this.align = align;
		this.width = width;
		this.wrap = wrap;
		this.renderer = renderer;
	}

	/**  
	 * Title: colModel.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	public String getHeader() {
		return header;
	}
	public void setHeader(String header) {
		this.header = header;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public AlignEnum getAlign() {
		return align;
	}
	public void setAlign(AlignEnum align) {
		this.align = align;
	}
	public int getWidth() {
		return width;
	}
	public void setWidth(int width) {
		this.width = width;
	}
	public boolean isWrap() {
		return wrap;
	}
	public void setWrap(boolean wrap) {
		this.wrap = wrap;
	}
	public Renderer getRenderer() {
		return renderer;
	}
	public void setRenderer(Renderer renderer) {
		this.renderer = renderer;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-4</li>
	 * <li>2、开发时间：下午3:54:36</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“columnTypeEnum”的值
	 */
	public ColumnTypeEnum getColumnTypeEnum() {
		return columnTypeEnum;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-4</li>
	 * <li>2、开发时间：下午3:54:36</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“columnTypeEnum”的值将赋给字段“columnTypeEnum”
	 */
	public void setColumnTypeEnum(ColumnTypeEnum columnTypeEnum) {
		this.columnTypeEnum = columnTypeEnum;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-4</li>
	 * <li>2、开发时间：下午3:55:13</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“action”的值
	 */
	public Action getAction() {
		return action;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-4</li>
	 * <li>2、开发时间：下午3:55:13</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“action”的值将赋给字段“action”
	 */
	public void setAction(Action action) {
		this.action = action;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-9</li>
	 * <li>2、开发时间：上午11:21:53</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“url”的值
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-9</li>
	 * <li>2、开发时间：上午11:21:53</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“url”的值将赋给字段“url”
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-12</li>
	 * <li>2、开发时间：上午11:36:23</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“id”的值
	 */
	public String getId() {
		return id;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-12</li>
	 * <li>2、开发时间：上午11:36:23</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“id”的值将赋给字段“id”
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-23</li>
	 * <li>2、开发时间：下午5:09:55</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“sortTypeEnum”的值
	 */
	public SortTypeEnum getSortTypeEnum() {
		return sortTypeEnum;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-23</li>
	 * <li>2、开发时间：下午5:09:55</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“sortTypeEnum”的值将赋给字段“sortTypeEnum”
	 */
	public void setSortTypeEnum(SortTypeEnum sortTypeEnum) {
		this.sortTypeEnum = sortTypeEnum;
	}
	
}
