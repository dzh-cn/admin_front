/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-2-20</li>
 * <li>3、开发时间：下午1:41:49</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.desktop.util</li>
 * <li>6、文件名称：HttpUtils.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.desktop.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.SocketTimeoutException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.httpclient.ConnectTimeoutException;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.methods.PostMethod;

import com.wangyin.commons.util.Logger;
import com.wangyin.commons.util.LoggerFactory;
import com.wangyin.operation.utils.GsonUtil;

/**
 * <ul>
 * <li>1、开发日期：2014-2-20</li>
 * <li>2、开发时间：下午1:41:49</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：HttpUtils</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class HttpUtils {

	private static Logger logger = LoggerFactory.getLogger(HttpUtils.class);
	private static final int CONNECT_TIMEOUT = ConfigUtil.getInt("sys.http.connectionTimeOut");
	private static final int READ_TIMEOUT = ConfigUtil.getInt("sys.http.readTimeOut");
	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2014-2-20</li>
	 * <li>2、开发时间：下午1:41:49</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 */
	public HttpUtils() {
		// TODO Auto-generated constructor stub
	}

	public static String doPost(String url ,Map<String,?> params) {
		String result = null;
		HttpClient httpClient = new HttpClient();
		PostMethod postMethod = new PostMethod(url);
		//设置连接超时时间(单位毫秒)
		httpClient.getHttpConnectionManager().getParams().setConnectionTimeout(HttpUtils.CONNECT_TIMEOUT);
		//设置读数据超时时间(单位毫秒)
		httpClient.getHttpConnectionManager().getParams().setSoTimeout(HttpUtils.READ_TIMEOUT);
		httpClient.getParams().setContentCharset("utf-8");
		if(logger.isDebugEnabled()) {
			logger.debug("URL:"+url+",请求参数："+GsonUtil.getInstance().toJson(params));
		}
		Set<?> keySet = params.entrySet();
		for (Iterator<Entry<String,?>> iterator = (Iterator<Entry<String, ?>>) keySet.iterator(); iterator.hasNext();) {
			Entry<String,?> entry = iterator.next();
			if(null == entry.getValue()) {
				continue;
			}
			postMethod.addParameter(entry.getKey(),entry.getValue().toString());
		}
		BufferedReader br = null;
		InputStream is = null;
		try {
			int status = httpClient.executeMethod(postMethod);
			if(200 != status) {
				logger.error("URL:"+url+"访问出错，http状态码："+status);
			}
			is = postMethod.getResponseBodyAsStream();
			br = new BufferedReader(new InputStreamReader(is));
			StringBuilder sb = new StringBuilder();   
			String line = null;
			while ((line = br.readLine()) != null) {
				sb.append(line);
			}
			result = sb.toString();
			logger.debug("URL:"+url+",返回结果："+result);
		} catch (ConnectTimeoutException e) {
			logger.error("URL:"+url+"连接超时，超时时间："+HttpUtils.CONNECT_TIMEOUT+"ms",e.fillInStackTrace());
		} catch (SocketTimeoutException e) {
			logger.error("URL:"+url+"长时间没有返回数据，读取超时，超时时间："+HttpUtils.READ_TIMEOUT+"ms",e.fillInStackTrace());
		} catch (HttpException e) {
			logger.error("URL:"+url,e.fillInStackTrace());
		} catch (IOException e) {
			logger.error("URL:"+url,e.fillInStackTrace());
		} finally {
			if(null != postMethod) {
				postMethod.releaseConnection();
			}
			try {
				if(null != br) {
					br.close();
				}
				if(null != is) {
					is.close();
				}
			} catch (IOException e) {
				logger.error("",e.fillInStackTrace());
			}
		}
		return result;
	}

	/**
	 * Title: HttpUtils.java Description: TODO(用一句话描述该文件做什么)
	 * 
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */

	/**
	 * <ul>
	 * <li>1、开发日期：2014-2-20</li>
	 * <li>2、开发时间：下午1:41:49</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、返回类型：void</li>
	 * <li>5、方法含义：</li>
	 * <li>6、方法说明：</li>
	 * </ul>
	 * @param args
	 */
	public static void main(String[] args) {
		Map<String,Object> params = new HashMap<String,Object>();
		params.put("abc", "中文");
		params.put("start", "0");
		params.put("limit", "10");
		HttpUtils.doPost("http://10.45.246.60:8080/certification/certificate/certificate.biz", params);

	}
}
