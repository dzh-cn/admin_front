/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-1-8</li>
 * <li>3、开发时间：下午1:49:22</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.bean.query</li>
 * <li>6、文件名称：TextField.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.bean.query;

import com.chinabank.operationmanagesystem.core.enums.TextTypeEnum;

/**
 * <ul>
 * <li>1、开发日期：2014-1-8</li>
 * <li>2、开发时间：下午1:49:22</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：TextField</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class TextField extends QueryData {

	/**
	 * <ul>
	 * <li>1、字段类型：long</li>
	 * <li>2、字段名称：TextField.java</li>
	 * </ul>
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * 默认值
	 * @Default ""
	 */
	private String defaultValue="";
	/**
	 * 文本域类型
	 * @Default TextTypeEnum.TEXT
	 */
	private TextTypeEnum type = TextTypeEnum.TEXT;
	private String bind;
	/**
	 * <p>
	 * 构造函数
	 * </p>
	 * <ul>
	 * <li>1、开发日期：2014-1-8</li>
	 * <li>2、开发时间：下午1:49:22</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * </ul>
	 */
	public TextField() {
		// TODO Auto-generated constructor stub
	}
	
	public TextField(String label, String name) {
		super(label, name);
	}

	public TextField(String label, String name, TextTypeEnum type,
			String defaultValue) {
		super(label, name);
		this.type = type;
		this.defaultValue = defaultValue;
	}

	/**  
	 * Title: TextField.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	public TextTypeEnum getType() {
		return type;
	}
	public void setType(TextTypeEnum type) {
		this.type = type;
	}

	public String getDefaultValue() {
		return defaultValue;
	}

	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-14</li>
	 * <li>2、开发时间：下午5:54:24</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：获取</li>
	 * </ul>
	 * @return 返回字段“bind”的值
	 */
	public String getBind() {
		return bind;
	}

	/**
	 * <ul>
	 * <li>1、开发日期：2014-5-14</li>
	 * <li>2、开发时间：下午5:54:24</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、方法含义：设置</li>
	 * </ul>
	 * @param 参数“bind”的值将赋给字段“bind”
	 */
	public void setBind(String bind) {
		this.bind = bind;
	}
	
}
