/**
 * <p>项目名称：boss-enter<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-10-21</li>
 * <li>3、开发时间：下午1:07:31</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.wangyin.boss.enter.util</li>
 * <li>6、文件名称：DictServiceUtil.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.desktop.util;

import java.net.MalformedURLException;

import com.caucho.hessian.client.HessianProxyFactory;
import com.chinabank.cmcs.api.regtable.api.IOperateRegTableInfoService;
import com.chinabank.cmcs.api.regtable.api.IQueryRegTableInfoService;

/**
 * <ul>
 * <li>1、开发日期：2014-10-21</li>
 * <li>2、开发时间：下午1:07:31</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：DictServiceUtil</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public class DictServiceUtil {
	/**  
	 * Title: DictServiceUtil.java
	 * Description: TODO(用一句话描述该文件做什么)
	 * @author: wangjiaqi
	 * @version V1.0
	 * @history:
	 */
	private static String hessianUrl = ConfigUtil.getString("app.dict.hessianUrl");
	
	private static HessianProxyFactory hessianProxyFactory = new HessianProxyFactory();
	
	private static IQueryRegTableInfoService iQueryRegTableInfoService;
	
	private static IOperateRegTableInfoService iOperateRegTableInfoService;
	
	public static IQueryRegTableInfoService getDictService() throws MalformedURLException {
		if(null == iQueryRegTableInfoService) {
			synchronized (DictServiceUtil.class) {
				if(iQueryRegTableInfoService == null) {
					iQueryRegTableInfoService = (IQueryRegTableInfoService) hessianProxyFactory.create(IQueryRegTableInfoService.class, hessianUrl+"api/regtableqry.hs");
				}
			}
		}
		return iQueryRegTableInfoService;
	}
	
	public static IOperateRegTableInfoService getOperationDictService() throws MalformedURLException {
		if(null == iOperateRegTableInfoService) {
			synchronized (DictServiceUtil.class) {
				if(iOperateRegTableInfoService == null) {
					iOperateRegTableInfoService = (IOperateRegTableInfoService) hessianProxyFactory.create(IOperateRegTableInfoService.class, hessianUrl+"api/regtableopt.hs");
				}
			}
		}
		return iOperateRegTableInfoService;
	}
}
