/**
 * <p>项目名称：operationmanagesystem<p>
 * <ul>
 * <li>1、版权所有：网银在线</li>
 * <li>2、开发日期：2014-1-10</li>
 * <li>3、开发时间：下午4:00:56</li>
 * <li>4、作          者：wangjiaqi</li>
 * <li>5、包路径名：com.chinabank.operationmanagesystem.core.enums</li>
 * <li>6、文件名称：FormType.java</li>
 * </ul>
 */
package com.chinabank.operationmanagesystem.core.enums;

/**
 * <ul>
 * <li>1、开发日期：2014-1-10</li>
 * <li>2、开发时间：下午4:00:56</li>
 * <li>3、作          者：wangjiaqi</li>
 * <li>4、类型名称：FormType</li>
 * <li>5、类型意图：</li>
 * </ul>
 *
 */
public enum ColumnTypeEnum {
	COLUMN(0,"C","col","表头"),
	ACTION(1,"A","act","动作"),
	LINK(2,"L","link","链接");
	
	private int order;
	private String code;
	private String name;
	private String desc;
	private ColumnTypeEnum(int order,String code,String name,String desc) {
		this.order = order;
		this.code = code;
		this.name = name;
		this.desc = desc;
	}
	/**
	 * 
	 * <ul>
	 * <li>1、开发日期：2014-1-8</li>
	 * <li>2、开发时间：上午9:39:30</li>
	 * <li>3、作          者：wangjiaqi</li>
	 * <li>4、返回类型：AlignEnum</li>
	 * <li>5、方法含义：根据code找到对应枚举类型</li>
	 * <li>6、方法说明：找不到时返回null</li>
	 * </ul>
	 * @param code
	 * @return
	 */
	public static ColumnTypeEnum getByCode(String code) {
		ColumnTypeEnum formTypeenum = null;
		for(ColumnTypeEnum ele : ColumnTypeEnum.values()) {
			if(ele.getCode().equals(code)) {
				formTypeenum = ele;
				break;
			}
		}
		return formTypeenum;
	}
	public int getOrder() {
		return order;
	}
	public void setOrder(int order) {
		this.order = order;
	}
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDesc() {
		return desc;
	}
	public void setDesc(String desc) {
		this.desc = desc;
	}
	
	public boolean equals(ColumnTypeEnum envm) {
		if(null != envm) {
			if(this.code.equals(envm.code)) {
				return true;
			} 
		}
		return false;
	}
}
