download = function(url,params,showRebuild) {
	showRebuild = arguments[2]?arguments[2]:false; 
	if ( $('#downloadDialog').length === 0 ) {
		$('body').append('<div id="downloadDialog"></div>');
		var downloadButton = '<button id="_downloadDialog_download" type="button" class="iconrept btn ml3">下载</button>';
		var rebuildButton = '<button id="_downloadDialog_rebuild" type="button" class="iconrept btn ml3">重新生成</button>';
		$('#downloadDialog').append(downloadButton);
		$('#downloadDialog').append(rebuildButton);
		$('#downloadDialog').omDialog({
			title : "文件下载",
			modal : true,
			autoOpen : false,
			resizable : false,
			height : 75,
			width : 180
		});
	}
	doBuild(url,params,showRebuild);
}

function doBuild(url,params,showRebuild) {
	var form = getForm(params);
	var paramsJson = form.serialize();
	form.remove();
	$.ajax({
		type : "post",
		url : url,
		data : paramsJson,
		dataType : "json",
		success : function(data) {
			if(data.successful) {
				if(data.exist) {
					$("#_downloadDialog_download").unbind("click");
					$("#_downloadDialog_rebuild").unbind("click");
					if(data.bookFile.status === "PROCESSING") {
						alert("文件正在处理中请稍后再试！");
						return;
					} else if(data.bookFile.status === "DELETE") {
						alert("文件已被删除！");
						if(showRebuild === true) {
							$("#_downloadDialog_download").hide();
							$("#_downloadDialog_rebuild").show();
						} else {
							return;
						}
					} else if(data.bookFile.status === "FAILED") {
						alert("文件处理失败！");
						if(showRebuild === true) {
							$("#_downloadDialog_download").hide();
							$("#_downloadDialog_rebuild").show();
						} else {
							return;
						}
					} else if(data.bookFile.status === "DONE") {
						$("#_downloadDialog_download").show();
						if(showRebuild === true) {
							$("#_downloadDialog_rebuild").show();
						} else {
							$("#_downloadDialog_rebuild").hide();
						}
					}
					$("#_downloadDialog_download").bind("click",function () {
						window.location="/operationmanagesystem/desktop/download.download?fileDir="+encodeURIComponent(data.bookFile.fileDir)+"&fileName="+encodeURIComponent(data.bookFile.fileName);
						//alert("下载window.location=/http/download?fileDir="+encodeURIComponent(data.bookFile.fileDir)+"&fileName="+encodeURIComponent(data.bookFile.fileName));
					});
					$("#_downloadDialog_rebuild").bind("click",function () {
						params.rebuild = true;
						doBuild(url,params,showRebuild);
						delete params.rebuild;
						$('#downloadDialog').omDialog("close");
					});
					$('#downloadDialog').omDialog('open');
				} else {//不存在，则进行了预约下载
					if(data.bookSuccessful) {//预约是否成功
						alert("预约成功，请稍后尝试下载！");
					} else {
						alert("预约失败，原因可能是："+data.message);
					}
				}
			} else {
				alert("预约请求失败，原因可能是："+data.message);
			}
			result = data;
		}
	});
}

function getForm(obj) {
	// 创建Form
	var form = $('<form></form>');
	$.each(obj,function(name,value){
		if(null != value) {
			// 创建Input
			var my_input = $('<input type="text" />');
			my_input.attr('name', name);
			my_input.attr('value', value);
			// 附加到Form
			form.append(my_input);
		}
	});
	$(form).hide();
	$(form).appendTo("body");
	return form;
}

